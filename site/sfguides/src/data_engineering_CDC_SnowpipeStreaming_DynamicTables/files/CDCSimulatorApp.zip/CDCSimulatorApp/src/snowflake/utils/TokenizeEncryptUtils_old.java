package snowflake.utils;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.OAEPParameterSpec;
import javax.crypto.spec.PSource;
import javax.crypto.spec.SecretKeySpec;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.security.interfaces.RSAPrivateKey;
import java.security.spec.MGF1ParameterSpec;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.Arrays;
import java.util.Base64;

public class TokenizeEncryptUtils_old {
// Helper Utility for AES256 encryption/decryption(Simple demonstration)
  private static final String DEFAULT_SECRET_KEY = "F374A97A71490437AA024E4FAED5B497FDGF1A8EA6FF12F6FB65AF2720B59CCF";  // should be using from a Key Vault, not defaults
  private static final String DEFAULT_SALT = "8A892873A52C57B3";// should be using from a Key Vault, not defaults
  private static final int DEFAULT_TOKEN_KEY = 11;// should be using from a Key Vault, not defaults
  private Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
  private Cipher d_cipher = Cipher.getInstance("AES/CBC/PKCS5PADDING");
  private int TOKEN_KEY;


  public String encode64(String s) throws Exception {
    if (s == null || s.isEmpty())  return s;
    return Base64.getEncoder().encodeToString(s.getBytes());
  }

  public String decode64(String s) throws Exception {
    if (s==null) return null;
    byte[] decodedBytes = Base64.getDecoder().decode(s);
    return new String(decodedBytes);
  }

  public TokenizeEncryptUtils_old() throws Exception {
    this(DEFAULT_SECRET_KEY,DEFAULT_SALT,DEFAULT_TOKEN_KEY);
  }
  public TokenizeEncryptUtils_old(String encryptionKey,String initVector,int token) throws Exception {
    // Initialize Cipher
    IvParameterSpec ivspec = createIvParameterSpec(initVector.toCharArray());
    SecretKeySpec secretKey = createSecretKeySpec(encryptionKey.toCharArray());
    cipher.init(Cipher.ENCRYPT_MODE,secretKey,ivspec);
    d_cipher.init(Cipher.DECRYPT_MODE,secretKey,ivspec);
    TOKEN_KEY=token;
  }
  public String encrypt(String s) throws Exception {
    if (s == null || s.isEmpty())  return s;
    final byte[] bytes = s.getBytes(StandardCharsets.UTF_8);
    final byte[] cipherBytes = cipher.doFinal(bytes);
    return Base64.getEncoder().encodeToString(cipherBytes);
  }

  public String decrypt(String s) throws Exception {
    if (s==null) return null;
    byte[] bytes = Base64.getDecoder().decode(s);
    byte[] decodedBytes = d_cipher.doFinal(bytes);
    return new String(decodedBytes,StandardCharsets.UTF_8);
  }

  public String tokenize(long id){
    return Long.toHexString(id*TOKEN_KEY).toString();
  }
  private static IvParameterSpec createIvParameterSpec(char[] initVector) {
    byte[] key = String.valueOf(initVector).getBytes(StandardCharsets.UTF_8);
    return new IvParameterSpec(key);
  }

  private static SecretKeySpec createSecretKeySpec(char[] encryptionkey)
          throws NoSuchAlgorithmException {
    byte[] key = new String(encryptionkey).getBytes(StandardCharsets.UTF_8);
    MessageDigest sha = MessageDigest.getInstance("SHA-1");
    key = sha.digest(key);
    key = Arrays.copyOf(key, 16);
    return new SecretKeySpec(key, "AES");
  }
}
