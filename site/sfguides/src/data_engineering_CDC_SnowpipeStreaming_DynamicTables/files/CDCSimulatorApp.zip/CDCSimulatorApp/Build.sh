#!/bin/sh
 javac -cp lib/snowflake-ingest-sdk.jar:lib/slf4j-api-2.0.6.jar:lib/slf4j-simple-2.0.6.jar:classes -d classes src/snowflake/demo/samples/*.java
 javac -cp lib/snowflake-ingest-sdk.jar:lib/slf4j-api-2.0.6.jar:lib/slf4j-simple-2.0.6.jar:classes -d classes src/snowflake/utils/*.java
 javac -cp lib/snowflake-ingest-sdk.jar:lib/slf4j-api-2.0.6.jar:lib/slf4j-simple-2.0.6.jar:classes -d classes src/snowflake/demo/*.java


jar cfm CDCSimulatorClient.jar manifest.txt -C classes snowflake src snowflake.properties

