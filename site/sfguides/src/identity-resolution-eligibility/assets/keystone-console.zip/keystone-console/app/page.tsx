import KeystoneApp from "@/ui/KeystoneApp"

// Required: Snowflake is not reachable during the build.
export const dynamic = "force-dynamic"

export default function Home() {
  return <KeystoneApp />
}
