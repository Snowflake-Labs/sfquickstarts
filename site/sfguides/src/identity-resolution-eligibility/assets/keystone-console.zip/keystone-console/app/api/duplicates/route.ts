import { DB, errorResponse, pageParam, run } from "@/lib/keystone"

export const dynamic = "force-dynamic"

export async function GET(request: Request) {
  const page = pageParam(new URL(request.url).searchParams.get("page"))
  try {
    // Planted SNP-D duplicate cases that sit alongside a regular SNAP case for the same master ID.
    const rows = await run(
      `SELECT m.MASTER_ID, 'SNAP_FOOD_ASSISTANCE' AS AFFECTED_PROGRAM, COUNT(*) AS ENROLLMENT_RECORDS,
              LISTAGG(m.SYSTEM_ID, ', ') AS SYSTEM_RECORD_IDS, MIN(m.FIRST_NAME || ' ' || m.LAST_NAME) AS RECORD_NAME, MAX(m.DOB) AS DOB
       FROM ${DB}.CORE.MATCH_LINK m
       WHERE m.MASTER_ID IN (
         SELECT m2.MASTER_ID FROM ${DB}.CORE.MATCH_LINK m2
         WHERE m2.SOURCE_SYSTEM = 'SNAP_FOOD_ASSISTANCE' AND m2.SYSTEM_ID LIKE 'SNP-D%'
           AND EXISTS (SELECT 1 FROM ${DB}.CORE.MATCH_LINK x WHERE x.MASTER_ID = m2.MASTER_ID AND x.SOURCE_SYSTEM = 'SNAP_FOOD_ASSISTANCE' AND x.SYSTEM_ID LIKE 'SNP-%' AND x.SYSTEM_ID NOT LIKE 'SNP-D%')
         ORDER BY m2.MASTER_ID LIMIT 26 OFFSET ${(page - 1) * 25})
         AND m.SOURCE_SYSTEM = 'SNAP_FOOD_ASSISTANCE'
       GROUP BY m.MASTER_ID HAVING COUNT(*) > 1 ORDER BY m.MASTER_ID`,
    )
    return Response.json({ rows: rows.slice(0, 25), page, hasMore: rows.length > 25 })
  } catch (error) {
    return errorResponse(error)
  }
}
