import { DB, errorResponse, run, runLong } from "@/lib/keystone"

export const dynamic = "force-dynamic"

const BATCH_ID = /^[a-f0-9-]{36}$/i
const SIZE = 10

export async function POST(request: Request) {
  const body = await request.json().catch(() => ({}))
  const batchId = body?.batchId
  if (typeof batchId !== "string" || !BATCH_ID.test(batchId)) {
    return Response.json({ error: "Invalid batch identifier." }, { status: 400 })
  }
  const prefix = `PORTAL-${batchId}-%`
  try {
    const existing = await run(`SELECT COUNT(*) AS N FROM ${DB}.RAW.LIVE_INTAKE WHERE SOURCE_RECORD_ID LIKE ?`, [prefix])
    const inserted = Number(existing[0].N) === 0
    if (inserted) {
      await run(
        `INSERT INTO ${DB}.RAW.LIVE_INTAKE (EVENT_ID, SOURCE_SYSTEM, SOURCE_RECORD_ID, MASTER_ID, CITY, ELIGIBILITY_RESULT, RECEIVED_AT)
         SELECT UUID_STRING(), 'BENEFITS_PORTAL', ? || ROW_NUMBER() OVER (ORDER BY e.MASTER_ID), e.MASTER_ID, e.CITY, NULL, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ
         FROM ${DB}.MART.V_SNAP_ELIGIBILITY e ORDER BY e.MASTER_ID LIMIT ${SIZE}`,
        [`PORTAL-${batchId}-`],
      )
    }
    // Refresh both leaves at one consistent data timestamp; their shared
    // LIVE_INTAKE_RESOLVED upstream refreshes once as part of this graph.
    await runLong(`ALTER DYNAMIC TABLE ${DB}.MART.LIVE_INTAKE_ELIGIBILITY, ${DB}.MART.LIVE_INTAKE_METRICS REFRESH`)
    const [refresh, raw, eligibility, total] = await Promise.all([
      run(`SELECT QUERY_ID FROM TABLE(${DB}.INFORMATION_SCHEMA.QUERY_HISTORY_BY_USER(RESULT_LIMIT => 50)) WHERE QUERY_TEXT ILIKE 'ALTER DYNAMIC TABLE ${DB}.MART.LIVE_INTAKE_ELIGIBILITY%REFRESH' ORDER BY START_TIME DESC LIMIT 1`),
      run(`SELECT COUNT(*) AS N FROM ${DB}.RAW.LIVE_INTAKE WHERE SOURCE_RECORD_ID LIKE ?`, [prefix]),
      run(`SELECT COUNT(*) AS N FROM ${DB}.MART.LIVE_INTAKE_ELIGIBILITY WHERE SOURCE_RECORD_ID LIKE ?`, [prefix]),
      run(`SELECT COUNT(*) AS RAW_EVENT_COUNT FROM ${DB}.RAW.LIVE_INTAKE`),
    ])
    const batchSize = Number(raw[0].N)
    const eligibilityProcessed = Number(eligibility[0].N)
    if (eligibilityProcessed !== batchSize) throw new Error("Eligibility refresh finished but the batch counts do not match")
    return Response.json({
      batchId,
      inserted,
      batchSize,
      eligibilityProcessed,
      refreshQueryId: refresh[0]?.QUERY_ID ?? null,
      rawCount: Number(total[0].RAW_EVENT_COUNT),
    })
  } catch (error) {
    return errorResponse(error)
  }
}
