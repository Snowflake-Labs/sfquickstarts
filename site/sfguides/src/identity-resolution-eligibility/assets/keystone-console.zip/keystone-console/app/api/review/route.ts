import { DB, errorResponse, pageParam, run } from "@/lib/keystone"

export const dynamic = "force-dynamic"

export async function GET(request: Request) {
  const page = pageParam(new URL(request.url).searchParams.get("page"))
  try {
    const rows = await run(
      `SELECT MASTER_ID, FIRST_NAME, LAST_NAME, DOB, ZIP, SUGGESTED_MATCH_MASTER_ID, SUGGESTED_FIRST_NAME, SUGGESTED_LAST_NAME, SUGGESTED_MATCH_SCORE
       FROM ${DB}.MART.V_MATCH_REVIEW_QUEUE ORDER BY SUGGESTED_MATCH_SCORE DESC, MASTER_ID LIMIT 25 OFFSET ${(page - 1) * 25}`,
    )
    return Response.json({ rows, page, hasMore: rows.length === 25 })
  } catch (error) {
    return errorResponse(error)
  }
}
