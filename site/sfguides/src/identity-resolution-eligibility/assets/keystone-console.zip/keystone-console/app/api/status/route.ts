import { SEMANTIC_VIEW } from "@/lib/keystone"

export const dynamic = "force-dynamic"

export async function GET() {
  return Response.json({ mode: "live", semanticView: SEMANTIC_VIEW })
}
