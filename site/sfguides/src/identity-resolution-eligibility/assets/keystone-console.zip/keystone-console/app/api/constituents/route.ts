import { DB, errorResponse, pageParam, run } from "@/lib/keystone"

export const dynamic = "force-dynamic"

const PROGRAM_FLAGS: Record<string, string> = {
  SNAP: "ENROLLED_SNAP",
  MEDICAID: "ENROLLED_MEDICAID",
  CHILDCARE: "ENROLLED_CHILDCARE",
  WORKFORCE: "ENROLLED_WORKFORCE",
}

export async function GET(request: Request) {
  const params = new URL(request.url).searchParams
  const search = (params.get("q") || "").trim().slice(0, 80)
  const elig = (params.get("elig") || "").toUpperCase()
  const city = (params.get("city") || "").toUpperCase()
  const systems = Number.parseInt(params.get("systems") || "0", 10) || 0
  const page = pageParam(params.get("page"))
  const programs = (params.get("programs") || "").toUpperCase().split(",").filter((value) => value in PROGRAM_FLAGS)

  const filters: string[] = []
  const binds: unknown[] = []
  if (search) {
    filters.push("(c.MASTER_ID ILIKE ? OR c.FIRST_NAME ILIKE ? OR c.LAST_NAME ILIKE ?)")
    binds.push(`%${search}%`, `%${search}%`, `%${search}%`)
  }
  if (["PASS", "FAIL", "MANUAL_REVIEW"].includes(elig)) {
    filters.push("e.ELIGIBILITY_RESULT = ?")
    binds.push(elig)
  }
  if (city && /^[A-Z ]+$/.test(city)) {
    filters.push("c.CITY = ?")
    binds.push(city)
  }
  if (systems >= 1 && systems <= 5) {
    filters.push("c.SYSTEMS_FOUND_IN >= ?")
    binds.push(systems)
  }
  for (const program of programs) filters.push(`p.${PROGRAM_FLAGS[program]} = TRUE`)
  const where = filters.length ? `WHERE ${filters.join(" AND ")}` : ""

  try {
    const rows = await run(
      `SELECT c.MASTER_ID, c.FIRST_NAME, c.LAST_NAME, c.DOB, c.CITY, c.ZIP, c.SYSTEMS_FOUND_IN, c.SOURCE_RECORD_COUNT, e.ELIGIBILITY_RESULT
       FROM ${DB}.CORE.CONSTITUENT_MASTER c
       JOIN ${DB}.MART.V_SNAP_ELIGIBILITY e ON c.MASTER_ID = e.MASTER_ID
       JOIN ${DB}.MART.V_CROSS_PROGRAM_ENROLLMENT p ON c.MASTER_ID = p.MASTER_ID
       ${where} ORDER BY c.MASTER_ID LIMIT 25 OFFSET ${(page - 1) * 25}`,
      binds,
    )
    return Response.json({ rows, page, hasMore: rows.length === 25 })
  } catch (error) {
    return errorResponse(error)
  }
}
