import type { Metadata } from "next"
import type React from "react"
import { APP_TITLE, LOGO_SRC } from "@/lib/constants"
import "./globals.css"

export const metadata: Metadata = {
  title: APP_TITLE,
  description: "Identity resolution, eligibility, and governed sharing for a fictional state benefits agency (synthetic data).",
  icons: { icon: LOGO_SRC },
}

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  )
}
