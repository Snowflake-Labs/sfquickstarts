import { DB, errorResponse, run } from "@/lib/keystone"

export const dynamic = "force-dynamic"

export async function GET(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  const masterId = (await params).id.toUpperCase()
  if (!/^KM-\d{6}$/.test(masterId)) return Response.json({ error: "Invalid master ID" }, { status: 400 })
  try {
    const [people, programs, links] = await Promise.all([
      run(
        `SELECT c.MASTER_ID, c.FIRST_NAME, c.LAST_NAME, c.DOB, c.CITY, c.ZIP, c.HOUSEHOLD_SIZE, c.SOURCE_RECORD_COUNT, c.SYSTEMS_FOUND_IN,
                e.MONTHLY_INCOME, e.GROSS_MONTHLY_LIMIT, e.ELIGIBILITY_RESULT, e.DETERMINATION_REASON, e.CURRENTLY_ENROLLED_SNAP
         FROM ${DB}.CORE.CONSTITUENT_MASTER c JOIN ${DB}.MART.V_SNAP_ELIGIBILITY e ON c.MASTER_ID = e.MASTER_ID
         WHERE c.MASTER_ID = ?`,
        [masterId],
      ),
      run(`SELECT ENROLLED_SNAP, ENROLLED_MEDICAID, ENROLLED_CHILDCARE, ENROLLED_WORKFORCE FROM ${DB}.MART.V_CROSS_PROGRAM_ENROLLMENT WHERE MASTER_ID = ?`, [masterId]),
      run(`SELECT SOURCE_SYSTEM, SYSTEM_ID, FIRST_NAME, LAST_NAME, DOB, CITY, MATCH_TYPE, MATCH_SCORE FROM ${DB}.CORE.MATCH_LINK WHERE MASTER_ID = ? ORDER BY SOURCE_SYSTEM LIMIT 20`, [masterId]),
    ])
    if (!people.length) return Response.json({ error: "Constituent not found" }, { status: 404 })
    return Response.json({ person: people[0], programs: programs[0] ?? {}, links })
  } catch (error) {
    return errorResponse(error)
  }
}
