import { DB, errorResponse, run } from "@/lib/keystone"

export const dynamic = "force-dynamic"

export async function GET() {
  try {
    const rows = await run(
      `SELECT MASTER_ID, CITY, ZIP, ENROLLED_SNAP, ENROLLED_MEDICAID, ENROLLED_CHILDCARE, PROGRAM_COUNT FROM ${DB}.GOVERNANCE.PUBLIC_HEALTH_SHARE_V WHERE MASTER_ID = 'KM-000013'`,
    )
    return Response.json({
      view: `${DB}.GOVERNANCE.PUBLIC_HEALTH_SHARE_V`,
      share: "KEYSTONE_PUBLIC_HEALTH_SHARE",
      rows,
      consumerConfigured: false,
    })
  } catch (error) {
    return errorResponse(error)
  }
}
