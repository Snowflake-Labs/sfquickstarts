import { AGENT, SEMANTIC_VIEW, errorResponse, runLong } from "@/lib/keystone"

export const dynamic = "force-dynamic"

// Only these result columns are safe to echo back as table rows (no names, SSNs, or income).
const SAFE_COLUMNS = new Set(["CITY", "ZIP", "ELIGIBILITY_RESULT", "CONSTITUENTS", "ELIGIBLE_NOT_ENROLLED", "COUNT", "COUNT_STAR", "TOTAL", "HOUSEHOLD_SIZE", "PROGRAM_ENROLLMENT_COUNT", "AFFECTED_PROGRAM", "DUP_COUNT", "ENROLLMENT_RECORDS", "RAW_EVENT_COUNT", "RESOLVED_EVENT_COUNT", "MATERIALIZED_EVENT_COUNT", "LATEST_RAW_AT", "LATEST_MATERIALIZED_AT", "SOURCE_RECORDS", "MULTI_SYSTEM", "DUPLICATES", "ELIG_PASS", "ELIG_FAIL", "ELIG_REVIEW"])

let busy = false

function decodeAgent(result: any) {
  const trace: any[] = result?.content || []
  const toolJson = trace.flatMap((event) => (event.tool_result?.content || []).map((entry: any) => entry.json).filter(Boolean))
  const executed = toolJson.filter((entry) => entry?.sql && entry?.result_set).at(-1)
  const semanticContext = toolJson.filter((entry) => entry?.semantic_view_fqn || entry?.semantic_model_path).at(-1)
  const evidence = {
    semanticView: semanticContext?.semantic_view_fqn || SEMANTIC_VIEW,
    tool: executed ? "system_execute_sql" : null,
    verifiedQueryUsed: executed?.verified_query_used === true,
  }
  const columns: string[] = executed?.result_set?.resultSetMetaData?.rowType?.map((column: any) => column.name) || []
  const data: any[][] = executed?.result_set?.data || []
  const singleCase = columns.includes("MASTER_ID") && columns.includes("ELIGIBILITY_RESULT") && data.length === 1
  const c: Record<string, any> | null = singleCase ? Object.fromEntries(columns.map((column, index) => [column, data[0][index]])) : null
  const monthlyIncome = c?.MONTHLY_INCOME == null ? "unverified" : Number(c.MONTHLY_INCOME).toFixed(2)
  const recap = c
    ? `${c.FIRST_NAME} ${c.LAST_NAME} (${c.MASTER_ID}) has ${c.SOURCE_RECORD_COUNT || "?"} source records across ${c.SYSTEMS_FOUND_IN || "?"} systems; ${c.DETERMINISTIC_MATCHES || 0} deterministic and ${c.PROBABILISTIC_MATCHES || 0} probabilistic matches (best score ${c.BEST_MATCH_SCORE || "?"}). SNAP determination: ${c.ELIGIBILITY_RESULT} — ${c.DETERMINATION_REASON}. Monthly income $${monthlyIncome} against the $${c.GROSS_MONTHLY_LIMIT || "?"} limit for household size ${c.HOUSEHOLD_SIZE || "?"}. SNAP enrolled: ${c.CURRENTLY_ENROLLED_SNAP}; Medicaid: ${c.ENROLLED_MEDICAID}; childcare: ${c.ENROLLED_CHILDCARE}; workforce: ${c.ENROLLED_WORKFORCE}. This is a determination and a match audit, not a fraud conclusion.`
    : null
  const text = trace.filter((event) => event.type === "text").map((event) => event.text).join("\n\n")
  return {
    answer: recap || text || "No answer returned.",
    sql: executed?.sql || null,
    columns,
    rows: columns.length && columns.every((column) => SAFE_COLUMNS.has(column.toUpperCase())) ? data.slice(0, 50) : [],
    rowCount: executed?.result_set?.resultSetMetaData?.numRows ?? null,
    queryId: executed?.query_id || null,
    evidence: { ...evidence, caseEvidence: c },
    suggestions: trace.flatMap((event) => (event.suggested_queries || []).map((item: any) => item.query)),
  }
}

export async function POST(request: Request) {
  const body = await request.json().catch(() => ({}))
  const question = body?.question
  if (typeof question !== "string" || !question.trim() || question.length > 500) {
    return Response.json({ error: "Enter a question of 1–500 characters." }, { status: 400 })
  }
  if (busy) return Response.json({ error: "A question is already running. Please wait." }, { status: 429 })
  busy = true
  try {
    const requestBody = JSON.stringify({ messages: [{ role: "user", content: [{ type: "text", text: question.trim() }] }] })
    const rows = await runLong("SELECT SNOWFLAKE.CORTEX.DATA_AGENT_RUN(?, ?) AS RESPONSE", [AGENT, requestBody])
    const result = JSON.parse(rows[0].RESPONSE)
    if (result.status && result.status !== "completed" && !result.content) throw new Error(result.message || "Agent request failed")
    return Response.json(decodeAgent(result))
  } catch (error) {
    return errorResponse(error)
  } finally {
    busy = false
  }
}
