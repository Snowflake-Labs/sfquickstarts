import { DB, errorResponse, run, runLong } from "@/lib/keystone"

export const dynamic = "force-dynamic"

// Baseline metrics scan ~913K rows, so cache them for 5 minutes; live pipeline data is always fresh.
let baseline: Record<string, any> | null = null
let baselineCachedAt: Date | null = null

async function loadBaseline() {
  if (baseline && baselineCachedAt && Date.now() - baselineCachedAt.getTime() < 300_000) return
  const [totals, sources, matches, cities, income] = await Promise.all([
    runLong(`SELECT SOURCE_RECORDS, CONSTITUENTS, MULTI_SYSTEM, DUPLICATES, ELIG_PASS, ELIG_FAIL, ELIG_REVIEW, ELIGIBLE_NOT_ENROLLED FROM ${DB}.MART.V_LIVE_DASHBOARD`),
    run(`SELECT SOURCE_SYSTEM, COUNT(*) AS RECORD_COUNT FROM ${DB}.CORE.MATCH_LINK GROUP BY SOURCE_SYSTEM ORDER BY RECORD_COUNT DESC`),
    run(`SELECT MATCH_TYPE, COUNT(*) AS RECORD_COUNT FROM ${DB}.CORE.MATCH_LINK GROUP BY MATCH_TYPE`),
    run(`SELECT CITY, COUNT(*) AS CONSTITUENTS FROM ${DB}.CORE.CONSTITUENT_MASTER GROUP BY CITY ORDER BY CONSTITUENTS DESC`),
    run(`SELECT FLOOR(MONTHLY_INCOME / 1000) * 1000 AS INCOME_BUCKET, COUNT(*) AS CNT FROM ${DB}.CORE.CONSTITUENT_MASTER WHERE MONTHLY_INCOME IS NOT NULL GROUP BY INCOME_BUCKET ORDER BY INCOME_BUCKET`),
  ])
  baseline = { totals: totals[0], sources, matches, cities, income }
  baselineCachedAt = new Date()
}

export async function GET() {
  try {
    await loadBaseline()
    const [pipeline, recent, latestDecisions, refreshes] = await Promise.all([
      run(`SELECT RAW_EVENT_COUNT, RESOLVED_EVENT_COUNT, MATERIALIZED_EVENT_COUNT, ELIGIBILITY_EVENT_COUNT, ELIGIBILITY_PASS_COUNT, ELIGIBILITY_FAIL_COUNT, ELIGIBILITY_REVIEW_COUNT, LATEST_RAW_AT, LATEST_ELIGIBILITY_AT, LATEST_MATERIALIZED_AT FROM ${DB}.MART.V_LIVE_PIPELINE_STATUS`),
      run(`SELECT EVENT_ID, SOURCE_SYSTEM, SOURCE_RECORD_ID, MASTER_ID, CITY, RECEIVED_AT FROM ${DB}.RAW.LIVE_INTAKE ORDER BY RECEIVED_AT DESC LIMIT 8`),
      run(`SELECT SOURCE_RECORD_ID, MASTER_ID, ELIGIBILITY_RESULT, MONTHLY_INCOME, HOUSEHOLD_SIZE, GROSS_MONTHLY_LIMIT, RECEIVED_AT FROM ${DB}.MART.LIVE_INTAKE_ELIGIBILITY ORDER BY RECEIVED_AT DESC LIMIT 8`),
      // Refresh history timestamps are TIMESTAMP_LTZ: format them with their offset so the browser shows local time.
      run(`SELECT NAME, STATE, REFRESH_ACTION, REFRESH_TRIGGER, TO_VARCHAR(REFRESH_START_TIME, 'YYYY-MM-DD"T"HH24:MI:SS.FF3TZH:TZM') AS REFRESH_START_TIME, TO_VARCHAR(DATA_TIMESTAMP, 'YYYY-MM-DD"T"HH24:MI:SS.FF3TZH:TZM') AS DATA_TIMESTAMP, STATISTICS:"numInsertedRows"::INT AS ROWS_INSERTED FROM TABLE(${DB}.INFORMATION_SCHEMA.DYNAMIC_TABLE_REFRESH_HISTORY(NAME_PREFIX => '${DB}', RESULT_LIMIT => 8)) WHERE NAME IN ('LIVE_INTAKE_RESOLVED', 'LIVE_INTAKE_METRICS', 'LIVE_INTAKE_ELIGIBILITY') ORDER BY REFRESH_START_TIME DESC LIMIT 8`),
    ])
    return Response.json({
      ...baseline,
      totals: { ...baseline!.totals, ...pipeline[0] },
      recent,
      latestDecisions,
      refreshes,
      polledAt: new Date().toISOString(),
      baselineCachedAt: baselineCachedAt!.toISOString(),
    })
  } catch (error) {
    return errorResponse(error)
  }
}
