import React, { useEffect, useState } from "react";

export default function Duplicates() {
  const [page, setPage] = useState(1);
  const [result, setResult] = useState({ rows: [], hasMore: false });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  useEffect(() => {
    const controller = new AbortController();
    setLoading(true);
    fetch(`/api/duplicates?page=${page}`, { signal: controller.signal })
      .then(async (response) => { const result = await response.json(); if (!response.ok) throw new Error(result.error); return result; })
      .then((value) => { setResult(value); setError(""); })
      .catch((reason) => { if (reason.name !== "AbortError") setError(reason.message); })
      .finally(() => { if (!controller.signal.aborted) setLoading(false); });
    return () => controller.abort();
  }, [page]);
  return <section><h2>Duplicate enrollment watchlist</h2><p>Live results from Snowflake. These are potential duplicate case records for investigation—not confirmed fraud or a quantified savings estimate.</p>
    {error && <p role="alert" className="error">{error}</p>}{loading && <p role="status">Loading duplicate cases…</p>}
    <div className="live-table-wrap"><table className="table"><thead><tr><th>Master ID</th><th>Program</th><th>Recorded name</th><th>Records</th><th>Source IDs</th><th>DOB</th></tr></thead><tbody>{result.rows.map((row) => <tr key={`${row.MASTER_ID}:${row.AFFECTED_PROGRAM}`}><td className="mono">{row.MASTER_ID}</td><td>{row.AFFECTED_PROGRAM}</td><td>{row.RECORD_NAME}</td><td>{row.ENROLLMENT_RECORDS}</td><td className="mono">{row.SYSTEM_RECORD_IDS}</td><td>{row.DOB}</td></tr>)}</tbody></table></div>
    <div className="pagination"><button type="button" className="btn-sm" disabled={page === 1} onClick={() => setPage((value) => value - 1)}>Previous</button><span style={{ padding: "8px" }}>Page {page}</span><button type="button" className="btn-sm" disabled={!result.hasMore} onClick={() => setPage((value) => value + 1)}>Next</button></div>
  </section>;
}
