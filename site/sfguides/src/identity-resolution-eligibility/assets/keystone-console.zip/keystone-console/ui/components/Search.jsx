import React, { useEffect, useState } from "react";

const PROGRAMS = ["SNAP", "MEDICAID", "CHILDCARE", "WORKFORCE"];

export default function Search({ selectedId, onAsk }) {
  const [search, setSearch] = useState("");
  const [elig, setElig] = useState("");
  const [city, setCity] = useState("");
  const [systems, setSystems] = useState("");
  const [programs, setPrograms] = useState([]);
  const [page, setPage] = useState(1);
  const [result, setResult] = useState({ rows: [], hasMore: false });
  const [detail, setDetail] = useState(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => { setPage(1); }, [search, elig, city, systems, programs]);
  useEffect(() => {
    const controller = new AbortController();
    const params = new URLSearchParams({ q: search, elig, city, systems, programs: programs.join(","), page: String(page) });
    setLoading(true);
    fetch(`/api/constituents?${params}`, { signal: controller.signal })
      .then(async (response) => { const payload = await response.json(); if (!response.ok) throw new Error(payload.error); return payload; })
      .then((payload) => { setResult(payload); setError(""); })
      .catch((reason) => { if (reason.name !== "AbortError") setError(reason.message); })
      .finally(() => { if (!controller.signal.aborted) setLoading(false); });
    return () => controller.abort();
  }, [search, elig, city, systems, page, programs]);
  useEffect(() => { if (selectedId) showDetail(selectedId); }, [selectedId]);

  async function showDetail(id) {
    try {
      const response = await fetch(`/api/constituents/${encodeURIComponent(id)}`);
      const payload = await response.json();
      if (!response.ok) throw new Error(payload.error);
      setDetail(payload);
    } catch (reason) { setError(reason.message); }
  }

  return <div className="search-layout">
    <aside className="search-sidebar">
      <div className="filter-group"><h4>Eligibility</h4><select value={elig} onChange={(event) => setElig(event.target.value)}><option value="">All decisions</option><option value="PASS">Pass</option><option value="FAIL">Fail</option><option value="MANUAL_REVIEW">Manual review</option></select></div>
      <div className="filter-group"><h4>Systems</h4><select value={systems} onChange={(event) => setSystems(event.target.value)}><option value="">All</option>{[2, 3, 4, 5].map((count) => <option key={count} value={count}>{count}+ systems</option>)}</select></div>
      <div className="filter-group"><h4>Programs</h4>{PROGRAMS.map((name) => <label key={name}><input type="checkbox" checked={programs.includes(name)} onChange={() => setPrograms((current) => current.includes(name) ? current.filter((value) => value !== name) : [...current, name])} />{name}</label>)}</div>
      <div className="filter-group"><h4>City</h4><input value={city} onChange={(event) => setCity(event.target.value)} placeholder="e.g. RIVERTON" style={{ width: "100%" }} /></div>
    </aside>
    <div className="search-main">
      <h2>Constituent & eligibility</h2>
      <p>Live search across the full Snowflake population. Select a constituent to trace matching evidence, program enrollment, and the exact SNAP income rule.</p>
      <div className="searchbar"><input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search by master ID, first or last name" /></div>
      {error && <div className="error" role="alert">{error}</div>}{loading && <p role="status">Searching Snowflake…</p>}
      <div className="live-table-wrap"><table className="table"><thead><tr><th>Master ID</th><th>Name</th><th>City</th><th>DOB</th><th>Systems</th><th>SNAP</th><th>Details</th></tr></thead><tbody>{result.rows.map((person) => <tr key={person.MASTER_ID}><td className="mono">{person.MASTER_ID}</td><td>{person.FIRST_NAME} {person.LAST_NAME}</td><td>{person.CITY}</td><td>{person.DOB}</td><td>{person.SYSTEMS_FOUND_IN}</td><td><span className={`badge ${(person.ELIGIBILITY_RESULT || "").toLowerCase()}`}>{person.ELIGIBILITY_RESULT}</span></td><td><button type="button" className="link" onClick={() => showDetail(person.MASTER_ID)}>Inspect</button></td></tr>)}</tbody></table></div>
      <div className="pagination"><button type="button" className="btn-sm" disabled={page === 1} onClick={() => setPage((current) => current - 1)}>Previous</button><span style={{ padding: "8px" }}>Page {page}</span><button type="button" className="btn-sm" disabled={!result.hasMore} onClick={() => setPage((current) => current + 1)}>Next</button></div>
      {detail && <section className="detail">
        <h3>{detail.person.FIRST_NAME} {detail.person.LAST_NAME} · {detail.person.MASTER_ID}</h3>
        <div className="detail-grid">
          <div className="detail-card"><h4>Eligibility determination</h4><p><span className={`badge ${detail.person.ELIGIBILITY_RESULT.toLowerCase()}`}>{detail.person.ELIGIBILITY_RESULT}</span> {detail.person.DETERMINATION_REASON}</p><div className="detail-fields"><div className="field"><span className="field-label">Monthly income</span>{detail.person.MONTHLY_INCOME == null ? "Unverified" : `$${Number(detail.person.MONTHLY_INCOME).toLocaleString()}`}</div><div className="field"><span className="field-label">Gross limit · household {detail.person.HOUSEHOLD_SIZE}</span>${Number(detail.person.GROSS_MONTHLY_LIMIT).toLocaleString()}</div><div className="field"><span className="field-label">Already in SNAP?</span>{detail.person.CURRENTLY_ENROLLED_SNAP ? "Yes" : "No"}</div><div className="field"><span className="field-label">Demo policy</span>$1,579 + $550 × (household size − 1); missing income → manual review</div></div></div>
          <div className="detail-card"><h4>Unified identity & program evidence</h4><p>{detail.person.SOURCE_RECORD_COUNT} linked source records across {detail.person.SYSTEMS_FOUND_IN} systems</p><div className="program-grid">{PROGRAMS.map((name) => <span className={`program-chip${detail.programs[`ENROLLED_${name}`] ? " enrolled" : ""}`} key={name}>{name}: {detail.programs[`ENROLLED_${name}`] ? "Enrolled" : "Not enrolled"}</span>)}</div><p>Data is synthetic. Source match types and scores appear below.</p></div>
        </div>
        <div className="detail-card"><h4>Matching audit trail</h4><div className="live-table-wrap"><table className="table"><thead><tr><th>Source</th><th>Source ID</th><th>Recorded name</th><th>DOB</th><th>Match</th><th>Score</th></tr></thead><tbody>{detail.links.map((link) => <tr key={link.SYSTEM_ID}><td>{link.SOURCE_SYSTEM}</td><td className="mono">{link.SYSTEM_ID}</td><td>{link.FIRST_NAME} {link.LAST_NAME}</td><td>{link.DOB}</td><td>{link.MATCH_TYPE}</td><td>{link.MATCH_SCORE}</td></tr>)}</tbody></table></div><button type="button" className="btn-primary" onClick={() => onAsk(detail.person.MASTER_ID)}>Ask agent to recap this case</button></div>
      </section>}
    </div>
  </div>;
}
