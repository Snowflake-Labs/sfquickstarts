"use client"

// The console is the original React UI (ui/App.jsx). It uses browser-only APIs such as
// localStorage and crypto.randomUUID, so it renders on the client only.
import dynamic from "next/dynamic"

const App = dynamic(() => import("./App.jsx"), { ssr: false })

export default function KeystoneApp() {
  return <App />
}
