import React, { useEffect, useState } from "react";

const STORAGE_KEY = "keystone-review-decisions-v1";
const keyFor = (row) => `${row.MASTER_ID}:${row.SUGGESTED_MATCH_MASTER_ID}`;
function savedDecisions() { try { return JSON.parse(localStorage.getItem(STORAGE_KEY) || "{}"); } catch { return {}; } }

export default function Review() {
  const [page, setPage] = useState(1);
  const [queue, setQueue] = useState({ rows: [], hasMore: false });
  const [decisions, setDecisions] = useState(savedDecisions);
  const [tab, setTab] = useState("pending");
  const [error, setError] = useState("");
  useEffect(() => {
    const controller = new AbortController();
    fetch(`/api/review?page=${page}`, { signal: controller.signal })
      .then(async (response) => { const result = await response.json(); if (!response.ok) throw new Error(result.error); return result; })
      .then((value) => { setQueue(value); setError(""); })
      .catch((reason) => { if (reason.name !== "AbortError") setError(reason.message); });
    return () => controller.abort();
  }, [page]);
  useEffect(() => { try { localStorage.setItem(STORAGE_KEY, JSON.stringify(decisions)); } catch {} }, [decisions]);
  function decide(row, outcome) { setDecisions((current) => ({ ...current, [keyFor(row)]: outcome })); }
  function undo(row) { setDecisions((current) => { const next = { ...current }; delete next[keyFor(row)]; return next; }); }
  const rows = queue.rows.filter((row) => tab === "pending" ? !decisions[keyFor(row)] : decisions[keyFor(row)] === tab);
  const pendingCount = queue.rows.filter((row) => !decisions[keyFor(row)]).length;
  return <section><h2>Match review queue</h2><p>Fresh candidates from Snowflake, scored for caseworker review. Approve/reject notes are saved only in this browser; they do not merge identities in Snowflake.</p>
    <div className="tab-pills">{["pending", "approved", "rejected"].map((value) => <button type="button" className={`tab-pill${tab === value ? " active" : ""}`} onClick={() => setTab(value)} key={value}>{value} <span className="count">{value === "pending" ? pendingCount : Object.values(decisions).filter((item) => item === value).length}</span></button>)}</div>
    {error && <p role="alert" className="error">{error}</p>}
    <div className="live-table-wrap"><table className="table"><thead><tr><th>Record A</th><th>Recorded name</th><th>DOB</th><th>ZIP</th><th>Suggested record</th><th>Suggested name</th><th>Score</th><th>Decision</th></tr></thead><tbody>{rows.map((row) => <tr key={keyFor(row)}><td className="mono">{row.MASTER_ID}</td><td>{row.FIRST_NAME} {row.LAST_NAME}</td><td>{row.DOB}</td><td>{row.ZIP}</td><td className="mono">{row.SUGGESTED_MATCH_MASTER_ID}</td><td>{row.SUGGESTED_FIRST_NAME} {row.SUGGESTED_LAST_NAME}</td><td>{row.SUGGESTED_MATCH_SCORE}</td><td><div className="review-actions">{tab === "pending" ? <><button type="button" className="review-action approve" onClick={() => decide(row, "approved")}>Approve</button><button type="button" className="review-action reject" onClick={() => decide(row, "rejected")}>Reject</button></> : <button type="button" className="review-action undo" onClick={() => undo(row)}>Undo</button>}</div></td></tr>)}</tbody></table></div>
    <div className="pagination"><button type="button" className="btn-sm" disabled={page === 1} onClick={() => setPage((value) => value - 1)}>Previous</button><span style={{ padding: "8px" }}>Page {page}</span><button type="button" className="btn-sm" disabled={!queue.hasMore} onClick={() => setPage((value) => value + 1)}>Next</button></div>
  </section>;
}
