import React, { useState, useEffect } from "react";

const STARTERS = [
  "For constituent KM-000013, recap the matching evidence, other program enrollment, and SNAP eligibility determination without disclosing an SSN.",
  "What is the current live intake pipeline status?",
  "How many constituents are eligible for SNAP but not enrolled?",
  "Show SNAP eligibility outcomes by city",
  "Which programs have duplicate enrollments?",
];

export default function CoWork({ initialQuestion, onQuestionConsumed }) {
  const [question, setQuestion] = useState("");
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(false);
  useEffect(() => {
    if (initialQuestion) {
      setQuestion(initialQuestion);
      onQuestionConsumed();
    }
  }, [initialQuestion, onQuestionConsumed]);

  async function ask(text) {
    const prompt = text.trim();
    if (!prompt || loading) return;
    setQuestion("");
    setMessages((current) => [...current, { role: "user", text: prompt }]);
    setLoading(true);
    try {
      const response = await fetch("/api/ask", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ question: prompt }),
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || "The live request failed.");
      setMessages((current) => [...current, { role: "assistant", text: result.answer, result }]);
    } catch (error) {
      setMessages((current) => [...current, { role: "error", text: error.message }]);
    } finally {
      setLoading(false);
    }
  }

  return (
    <section className="live-panel">
      <h2>Ask Keystone data · inspect the SQL</h2>
      <p>Ask in natural language; the live Cortex Agent uses <code>KEYSTONE_DEMO.MART.KEYSTONE_CASEWORKER</code> and returns an answer, SQL, result rows where safe, and a Snowflake query ID. Open the evidence panel for the semantic view and observable tool/query steps. This is not native CoWork, and we do not display hidden model reasoning.</p>
      <div className="live-starters">
        {STARTERS.map((item) => <button type="button" key={item} onClick={() => ask(item)} disabled={loading}>{item}</button>)}
      </div>
      <div className="live-chat" aria-live="polite">
        {messages.length === 0 && <p>Ask a question in your own words. No answer is preloaded.</p>}
        {messages.map((message, index) => (
          <article className={`live-message ${message.role}`} key={index}>
            <strong>{message.role === "user" ? "You" : message.role === "error" ? "Request failed" : "Live agent"}</strong>
            <p>{message.text}</p>
            {message.result?.sql && <details open><summary>SQL executed in Snowflake</summary><pre>{message.result.sql}</pre></details>}
            {message.result?.columns?.length > 0 && (message.result.rows?.length ? <div className="live-table-wrap"><table className="table"><thead><tr>{message.result.columns.map((column) => <th key={column}>{column}</th>)}</tr></thead><tbody>{message.result.rows.map((row, rowIndex) => <tr key={rowIndex}>{row.map((value, columnIndex) => <td key={columnIndex}>{String(value ?? "")}</td>)}</tr>)}</tbody></table></div> : <p>Row-level values are hidden in this local demo. Use the query ID to inspect them in Snowsight under your Snowflake role.</p>)}
            {message.result?.queryId && <small>Snowflake query ID: {message.result.queryId}</small>}
            {message.result?.evidence && <details><summary>Agent evidence and data context</summary><p>Semantic view: <code>{message.result.evidence.semanticView}</code></p><p>Executed tool: {message.result.evidence.tool || "No SQL tool used"}</p><p>Verified query used: {message.result.evidence.verifiedQueryUsed ? "Yes" : "No"}</p>{message.result.evidence.caseEvidence && <div className="detail-fields">{Object.entries(message.result.evidence.caseEvidence).filter(([key]) => key !== "MONTHLY_INCOME" && key !== "FIRST_NAME" && key !== "LAST_NAME").map(([key, value]) => <div className="field" key={key}><span className="field-label">{key.replaceAll("_", " ")}</span>{String(value ?? "Not recorded")}</div>)}</div>}<p>Snowflake query ID: {message.result.queryId || "No SQL executed"}</p></details>}
            {message.result?.suggestions?.length > 0 && <div className="live-starters">{message.result.suggestions.slice(0, 3).map((item) => <button key={item} type="button" onClick={() => ask(item)} disabled={loading}>{item}</button>)}</div>}
          </article>
        ))}
        {loading && <p role="status">Cortex Agent is generating SQL and querying Snowflake…</p>}
      </div>
      <form onSubmit={(event) => { event.preventDefault(); ask(question); }} className="live-form">
        <label htmlFor="caseworker-question">Your question</label>
        <div><input id="caseworker-question" value={question} maxLength={500} onChange={(event) => setQuestion(event.target.value)} placeholder="Ask about eligibility, programs or duplicate enrollments" /><button disabled={loading || !question.trim()}>Ask live</button></div>
      </form>
      <p className="live-status">Answers are live. The prompts above are optional starters; enter any supported Keystone question.</p>
    </section>
  );
}
