import React, { useState, useCallback } from "react";
import Overview from "./components/Overview.jsx";
import Search from "./components/Search.jsx";
import Duplicates from "./components/Duplicates.jsx";
import Review from "./components/Review.jsx";
import CoWork from "./components/CoWork.jsx";
import Sharing from "./components/Sharing.jsx";

const TABS = [
  { id: "overview", label: "Live Overview" },
  { id: "search", label: "Constituent & Eligibility" },
  { id: "duplicates", label: "Duplicate Watchlist" },
  { id: "review", label: "Match Review Queue" },
  { id: "assistant", label: "Ask Data + SQL" },
  { id: "sharing", label: "Partner Sharing" },
];

export default function App() {
  const [tab, setTab] = useState("overview");
  const [selectedId, setSelectedId] = useState(null);
  const [agentPrompt, setAgentPrompt] = useState("");
  const clearAgentPrompt = useCallback(() => setAgentPrompt(""), []);

  function askAboutConstituent(masterId) {
    setSelectedId(masterId);
    setAgentPrompt(`For constituent ${masterId}, recap the matching evidence, other program enrollment, and SNAP eligibility determination without disclosing an SSN.`);
    setTab("assistant");
  }

  return (
    <div className="app">
      <header className="topbar">
        <div className="brand">
          <div className="logo">&#10052;</div>
          <div>
            <div className="app-name">Keystone Caseworker Console</div>
            <div className="app-sub">SYNTHETIC DEMO · SNOWFLAKE-BACKED INTAKE & ELIGIBILITY</div>
          </div>
        </div>
        <div className="role-switch">
          <span className="role-label">SNOWFLAKE ROLE: SYSADMIN</span>
          <span className="pill active">Live queries</span>
        </div>
      </header>
      <nav className="tabs" aria-label="Demo sections">
        {TABS.map((item) => <button key={item.id} type="button" className={tab === item.id ? "tab active" : "tab"} onClick={() => setTab(item.id)}>{item.label}</button>)}
      </nav>
      <main className="content">
        {tab === "overview" && <Overview />}
        {tab === "search" && <Search selectedId={selectedId} onAsk={askAboutConstituent} />}
        {tab === "duplicates" && <Duplicates />}
        {tab === "review" && <Review />}
        {tab === "assistant" && <CoWork initialQuestion={agentPrompt} onQuestionConsumed={clearAgentPrompt} />}
        {tab === "sharing" && <Sharing />}
      </main>
    </div>
  );
}
