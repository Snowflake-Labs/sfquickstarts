import React, { useState, useEffect, useCallback } from "react";

const n = (v) => Number(v || 0).toLocaleString();
const pct = (a, b) => b ? ((a / b) * 100).toFixed(1) + "%" : "0%";

function Bar({ label, value, max, color }) {
  const w = max ? (value / max) * 100 : 0;
  return (
    <div className="bar-row">
      <span className="bar-label">{label}</span>
      <div className="bar-track">
        <div className="bar-fill" style={{ width: `${w}%`, background: color || "var(--accent)" }} />
      </div>
      <span className="bar-value">{n(value)}</span>
    </div>
  );
}

export default function Overview() {
  const [live, setLive] = useState(null);
  const [loadError, setLoadError] = useState("");
  const [inserting, setInserting] = useState(false);
  const [batchResult, setBatchResult] = useState(null);
  const [pendingBatchId, setPendingBatchId] = useState(null);
  const reload = useCallback(async () => {
    try {
      const response = await fetch("/api/overview");
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || "Snowflake dashboard request failed");
      setLive(result);
      setLoadError("");
    } catch (error) { setLoadError(error.message); }
  }, []);
  useEffect(() => {
    reload();
    const timer = setInterval(reload, 15000);
    return () => clearInterval(timer);
  }, [reload]);
  async function addBatch() {
    if (inserting) return;
    setInserting(true);
    const batchId = pendingBatchId || crypto.randomUUID();
    setPendingBatchId(batchId);
    try {
      const response = await fetch("/api/intake-batch", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ batchId }),
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || "Unable to refresh intake eligibility");
      setBatchResult(result);
      setPendingBatchId(null);
      await reload();
    } catch (error) { setLoadError(error.message); }
    finally { setInserting(false); }
  }
  const s = live?.totals || {};
  const totalSource = Number(s.SOURCE_RECORDS || 0);
  const totalConstituents = Number(s.CONSTITUENTS || 0);
  const multiSystem = Number(s.MULTI_SYSTEM || 0);
  const avgRecords = totalConstituents ? (totalSource / totalConstituents).toFixed(1) : "—";

  const sources = (live?.sources || []).map((source) => ({ label: source.SOURCE_SYSTEM.replaceAll("_", " "), value: Number(source.RECORD_COUNT), color: "#4f8cff" }));
  const sourceMax = Math.max(1, ...sources.map((source) => source.value));

  const pipeline = (live?.matches || []).map((match) => ({
    step: match.MATCH_TYPE === "DETERMINISTIC" ? "1" : match.MATCH_TYPE === "PROBABILISTIC" ? "2" : "3",
    title: match.MATCH_TYPE === "DETERMINISTIC" ? "Deterministic Match" : match.MATCH_TYPE === "PROBABILISTIC" ? "Probabilistic Match" : "Single-system records",
    count: Number(match.RECORD_COUNT),
    desc: match.MATCH_TYPE === "UNRESOLVED" ? "Unlinked source record (not automatically a review case)" : "Matched source records",
    color: match.MATCH_TYPE === "DETERMINISTIC" ? "#36b37e" : match.MATCH_TYPE === "PROBABILISTIC" ? "#ff9f43" : "#8993a4",
  }));

  const income = live?.income || [];
  const incomeMax = Math.max(1, ...income.map((row) => Number(row.CNT || 0)));
  const cities = live?.cities || [];
  const cityMax = Math.max(1, ...cities.map((row) => Number(row.CONSTITUENTS || 0)));
  const eligible = Number(s.ELIG_PASS || 0);
  const ineligible = Number(s.ELIG_FAIL || 0);
  const review = Number(s.ELIG_REVIEW || 0);
  const missedElig = Number(s.ELIGIBLE_NOT_ENROLLED || 0);
  const dupCount = Number(s.DUPLICATES || 0);
  const total = totalConstituents;
  if (!live) return <div className="loading">Loading current Snowflake dashboard… {loadError && <span role="alert">{loadError}</span>}</div>;

  return (
    <div>
      <div className="section">
        <div className="section-title">Summary — Resolution at a Glance</div>
        <div className="section-sub">Unified view of cross-system identity resolution across 5 state programs</div>
        <div className="tiles four">
          <div className="tile accent">
            <div className="tile-icon">📊</div>
            <div className="tile-number">{n(totalSource)}</div>
            <div className="tile-label">Source Records Ingested</div>
            <div className="tile-sub">Across Tax, Medicaid, SNAP, Workforce &amp; Childcare</div>
          </div>
          <div className="tile accent">
            <div className="tile-icon">👤</div>
            <div className="tile-number">{n(totalConstituents)}</div>
            <div className="tile-label">Unique Constituents</div>
            <div className="tile-sub">{pct(totalConstituents, totalSource)} deduplication rate</div>
          </div>
          <div className="tile accent">
            <div className="tile-icon">🔗</div>
            <div className="tile-number">{n(multiSystem)}</div>
            <div className="tile-label">Multi-System Residents</div>
            <div className="tile-sub">{pct(multiSystem, totalConstituents)} appear in 2+ systems</div>
          </div>
          <div className="tile accent">
            <div className="tile-icon">📈</div>
            <div className="tile-number">{avgRecords}</div>
            <div className="tile-label">Avg Records / Person</div>
            <div className="tile-sub">Higher values indicate more cross-system linkage</div>
          </div>
        </div>
      </div>

      <div className="section">
        <div className="section-title">Automated Eligibility Determination</div>
        <div className="section-sub">Illustrative demo policy: monthly income versus a household-size-adjusted limit; not an official benefit determination.</div>
        <div className="tiles four">
          <div className="tile">
            <div className="tile-number" style={{ color: "#36b37e" }}>{n(eligible)}</div>
            <div className="tile-label">Eligible (Pass)</div>
            <div className="tile-sub">{pct(eligible, total)} of constituents</div>
            <span className="badge pass">PASS</span>
          </div>
          <div className="tile">
            <div className="tile-number" style={{ color: "#ff6b6b" }}>{n(ineligible)}</div>
            <div className="tile-label">Ineligible (Fail)</div>
            <div className="tile-sub">{pct(ineligible, total)} of constituents</div>
            <span className="badge fail">FAIL</span>
          </div>
          <div className="tile">
            <div className="tile-number" style={{ color: "#ff9f43" }}>{n(review)}</div>
            <div className="tile-label">Needs Review</div>
            <div className="tile-sub">{pct(review, total)} flagged for manual review</div>
            <span className="badge review">REVIEW</span>
          </div>
          <div className="tile">
                <div className="tile-number" style={{ color: "#8993a4" }}>{n(missedElig)}</div>
                <div className="tile-label">Eligible, Not Enrolled</div>
                <div className="tile-sub">{pct(missedElig, total)} of constituents</div>
                <span className="badge muted">OUTREACH</span>
          </div>
        </div>
      </div>

      <div className="section pipeline-section">
        <div className="section-header-row">
          <div>
            <div className="section-title">Live Intake → Incremental Dynamic Tables</div>
            <div className="section-sub" style={{ marginBottom: 0 }}>New synthetic arrivals land in RAW, join to existing master IDs, and incremental dynamic tables compute eligibility and mart totals. Polled every 15 seconds.</div>
          </div>
          <div className="pipeline-actions">
            <button type="button" className="btn-primary" disabled={inserting} onClick={addBatch}>{inserting ? "Refreshing eligibility…" : pendingBatchId ? "Retry same intake batch" : "Insert 10 synthetic arrivals"}</button>
            <button type="button" className="btn-sm" onClick={reload}>Refresh now</button>
          </div>
        </div>
        {loadError && <div role="alert" className="error">Last refresh failed: {loadError}</div>}
        {batchResult && <div role="status" className="batch-banner">Batch {batchResult.batchId.slice(0, 8)}: {batchResult.inserted ? "inserted" : "already present"} · <strong>{batchResult.eligibilityProcessed}/{batchResult.batchSize} eligibility decisions computed</strong> · refresh query {batchResult.refreshQueryId || "not returned"}</div>}
        <div className="flow">
          {[
            ["1", "RAW INTAKE EVENTS", s.RAW_EVENT_COUNT, "Synthetic portal rows"],
            ["2", "MATCHED TO MASTER ID", s.RESOLVED_EVENT_COUNT, `Backlog ${n(Number(s.RAW_EVENT_COUNT) - Number(s.RESOLVED_EVENT_COUNT))}`],
            ["3", "ELIGIBILITY CALCULATED", s.ELIGIBILITY_EVENT_COUNT, `${n(s.ELIGIBILITY_PASS_COUNT)} PASS · ${n(s.ELIGIBILITY_FAIL_COUNT)} FAIL · ${n(s.ELIGIBILITY_REVIEW_COUNT)} REVIEW`],
            ["4", "MART METRICS MATERIALIZED", s.MATERIALIZED_EVENT_COUNT, `Backlog ${n(Number(s.RESOLVED_EVENT_COUNT) - Number(s.MATERIALIZED_EVENT_COUNT))}`],
          ].map(([step, label, value, sub], i, arr) => (
            <React.Fragment key={step}>
              <div className="tile flow-step"><div className="flow-step-num">STEP {step}</div><div className="tile-number">{n(value)}</div><div className="tile-label">{label}</div><div className="tile-sub">{sub}</div></div>
              {i < arr.length - 1 && <div className="flow-arrow">→</div>}
            </React.Fragment>
          ))}
        </div>
        <div className="card" style={{ marginTop: 16 }}><strong>Actual incremental refresh history</strong>
          <div className="live-table-wrap"><table className="table"><thead><tr><th>Dynamic table</th><th>State</th><th>Refresh action</th><th>Trigger</th><th>Rows inserted</th><th>Finished</th></tr></thead><tbody>{(live.refreshes || []).map((refresh, index) => <tr key={`${refresh.NAME}:${refresh.REFRESH_START_TIME}:${index}`}><td>{refresh.NAME}</td><td>{refresh.STATE}</td><td>{refresh.REFRESH_ACTION}</td><td>{refresh.REFRESH_TRIGGER}</td><td>{n(refresh.ROWS_INSERTED)}</td><td>{new Date(refresh.REFRESH_START_TIME).toLocaleTimeString()}</td></tr>)}</tbody></table></div>
        </div>
        <div className="tiles two" style={{ marginTop: 16 }}>
          <div className="card"><strong>Computed eligibility outcomes for recent arrivals</strong>
            <div className="live-table-wrap"><table className="table"><thead><tr><th>Record</th><th>Master ID</th><th>Monthly income</th><th>Household</th><th>Limit</th><th>Decision</th></tr></thead><tbody>{(live.latestDecisions || []).map((item) => <tr key={item.SOURCE_RECORD_ID}><td className="mono">{item.SOURCE_RECORD_ID}</td><td className="mono">{item.MASTER_ID}</td><td>{item.MONTHLY_INCOME == null ? "Unverified" : `$${Number(item.MONTHLY_INCOME).toFixed(2)}`}</td><td>{item.HOUSEHOLD_SIZE || "—"}</td><td>${n(item.GROSS_MONTHLY_LIMIT)}</td><td><span className={`badge ${(item.ELIGIBILITY_RESULT || "").toLowerCase()}`}>{item.ELIGIBILITY_RESULT}</span></td></tr>)}</tbody></table></div>
          </div>
          <div className="card"><strong>Recent arrivals from Snowflake</strong>
            <div className="live-table-wrap"><table className="table"><thead><tr><th>Source</th><th>Record</th><th>Master ID</th><th>City</th><th>Received</th></tr></thead><tbody>{(live.recent || []).map((event) => <tr key={event.EVENT_ID}><td>{event.SOURCE_SYSTEM}</td><td className="mono">{event.SOURCE_RECORD_ID}</td><td className="mono">{event.MASTER_ID}</td><td>{event.CITY}</td><td>{new Date(event.RECEIVED_AT).toLocaleTimeString()}</td></tr>)}</tbody></table></div>
          </div>
        </div>
        <div className="footnote">Last checked {new Date(live.polledAt).toLocaleTimeString()} · last decision {s.LATEST_ELIGIBILITY_AT ? new Date(s.LATEST_ELIGIBILITY_AT).toLocaleString() : "waiting"} · baseline metrics cached at {live.baselineCachedAt ? new Date(live.baselineCachedAt).toLocaleTimeString() : "unknown"} (up to 5 min). Arrivals reuse existing master IDs; the {n(totalSource)}-record baseline is unchanged. Scheduled refreshes remain active.</div>
      </div>

      <div className="section-divider">Detail breakdowns</div>

      <div className="section">
        <div className="section-title">Key Findings</div>
        <div className="findings">
          <div className="finding">
            <div className="finding-icon">⚠️</div>
            <div className="stat-callout">
              <div className="stat-callout-number">{n(dupCount)}</div>
              <div className="stat-callout-label">Duplicate Enrollments Detected</div>
            </div>
            <div className="tile-sub">Residents enrolled multiple times in the same program across systems</div>
          </div>
          <div className="finding">
            <div className="finding-icon">🎯</div>
            <div className="stat-callout">
              <div className="stat-callout-number">{n(missedElig)}</div>
              <div className="stat-callout-label">Missed Eligibility Opportunities</div>
            </div>
            <div className="tile-sub">Eligible residents not currently enrolled in SNAP benefits</div>
          </div>
          <div className="finding">
            <div className="finding-icon">🔍</div>
            <div className="stat-callout">
              <div className="stat-callout-number">{n(Number(s.RAW_EVENT_COUNT || 0) - Number(s.MATERIALIZED_EVENT_COUNT || 0))}</div>
              <div className="stat-callout-label">Intake Events Awaiting Materialization</div>
            </div>
            <div className="tile-sub">Follow raw arrivals as incremental dynamic tables refresh.</div>
          </div>
          <div className="finding">
            <div className="finding-icon">✓</div>
            <div className="stat-callout"><div className="stat-callout-number">{n(Number(s.RESOLVED_EVENT_COUNT || 0))}</div><div className="stat-callout-label">Live Intake Records Linked</div></div>
            <div className="tile-sub">Master IDs are joined from the existing population. A link is not a fresh identity-resolution model run.</div>
          </div>
        </div>
      </div>
      <div className="section">
        <div className="section-title">Source Systems Ingested</div>
        <div className="section-sub">Record volume by originating state program</div>
        {sources.map((s) => (
          <Bar key={s.label} label={s.label} value={s.value} max={sourceMax} color={s.color} />
        ))}
      </div>

      <div className="section">
        <div className="section-title">Entity Resolution Pipeline</div>
        <div className="section-sub">Two-pass matching strategy: deterministic first, then probabilistic</div>
        <div className="tiles three">
          {pipeline.map((p) => (
            <div className="card" key={p.step} style={{ borderTop: `3px solid ${p.color}` }}>
              <div style={{ fontSize: "0.75rem", color: p.color, fontWeight: 700, marginBottom: 4 }}>STEP {p.step}</div>
              <div style={{ fontSize: "1.1rem", fontWeight: 700 }}>{p.title}</div>
              <div className="tile-number" style={{ color: p.color }}>{n(p.count)}</div>
              <div className="tile-sub">{p.desc}</div>
            </div>
          ))}
        </div>
      </div>

      <div className="section">
        <div className="section-title">Income Distribution</div>
        <div className="section-sub">Current population, grouped by $1,000 monthly income bands. Eligibility outcomes appear in the live cards below.</div>
        {income.map((row) => {
          const total = Number(row.CNT || 0);
          const width = incomeMax ? (total / incomeMax) * 100 : 0;
          return (
            <div className="bar-row" key={row.INCOME_BUCKET}>
              <span className="bar-label">${n(row.INCOME_BUCKET)}–${n(Number(row.INCOME_BUCKET) + 999)}</span>
              <div className="bar-track"><div className="bar-fill" style={{ width: `${width}%`, background: "#4f8cff" }} /></div>
              <span className="bar-value">{n(total)}</span>
            </div>
          );
        })}
      </div>

      <div className="section">
        <div className="section-title">City Breakdown</div>
        <div className="section-sub">Constituent count by city of residence</div>
        {[...cities].sort((a, b) => Number(b.CONSTITUENTS) - Number(a.CONSTITUENTS)).map((row) => (
          <Bar key={row.CITY} label={row.CITY} value={Number(row.CONSTITUENTS)} max={cityMax} color="#4f8cff" />
        ))}
      </div>

    </div>
  );
}
