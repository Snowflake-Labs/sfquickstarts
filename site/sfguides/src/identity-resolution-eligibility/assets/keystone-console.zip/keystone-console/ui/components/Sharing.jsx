import React, { useEffect, useState } from "react";

export default function Sharing() {
  const [result, setResult] = useState(null);
  const [error, setError] = useState("");
  useEffect(() => {
    fetch("/api/sharing")
      .then(async (response) => { const payload = await response.json(); if (!response.ok) throw new Error(payload.error); return payload; })
      .then((payload) => { setResult(payload); setError(""); })
      .catch((reason) => setError(reason.message));
  }, []);
  return <section className="live-panel"><h2>Governed partner sharing</h2>
    <p>Live read-only preview of the secure view intended for a partner health agency. This view excludes SSN and income. Publishing it to an actual partner account requires a separately configured consumer.</p>
    {error && <div role="alert" className="error">{error}</div>}
    {!result && !error && <p role="status">Checking Snowflake sharing view…</p>}
    {result && <><div className="card"><p><strong>Secure view:</strong> <code>{result.view}</code></p><p><strong>Share:</strong> <code>{result.share}</code></p><p><strong>Consumer account:</strong> {result.consumerConfigured ? "Configured" : "Not configured — no cross-account delivery claimed"}</p><p>The sample below is read directly from the secure view, not generated from browser JSON.</p></div>
      <div className="live-table-wrap" style={{ marginTop: 16 }}><table className="table"><thead><tr><th>Master ID</th><th>City</th><th>ZIP</th><th>SNAP</th><th>Medicaid</th><th>Childcare</th><th>Sources</th></tr></thead><tbody>{result.rows.map((row) => <tr key={row.MASTER_ID}><td className="mono">{row.MASTER_ID}</td><td>{row.CITY}</td><td>{row.ZIP}</td><td>{row.ENROLLED_SNAP ? "Enrolled" : "No"}</td><td>{row.ENROLLED_MEDICAID ? "Enrolled" : "No"}</td><td>{row.ENROLLED_CHILDCARE ? "Enrolled" : "No"}</td><td>{row.PROGRAM_COUNT}</td></tr>)}</tbody></table></div></>}
  </section>;
}
