/**
 * Shared server-side helpers for the Keystone API routes.
 *
 * Every query runs with owner's rights through the App Runtime SDK, so the service
 * identity (not the browser) talks to Snowflake. Rows are normalized to the same JSON
 * shape the original Python worker returned: DATE -> "YYYY-MM-DD",
 * TIMESTAMP_NTZ -> ISO without a zone, numbers and booleans as-is.
 */
import { querySnowflake, querySnowflakeLongRunning } from "@/lib/snowflake"

export const DB = "KEYSTONE_DEMO"
export const SEMANTIC_VIEW = `${DB}.MART.KEYSTONE_CASEWORKER`
export const AGENT = `${DB}.MART.KEYSTONE_CASEWORKER_AGENT`

function normalize(value: unknown): unknown {
  if (value instanceof Date) {
    const iso = value.toISOString()
    return iso.endsWith("T00:00:00.000Z") ? iso.slice(0, 10) : iso.replace(/Z$/, "")
  }
  return value
}

function normalizeRows(rows: Record<string, any>[]): Record<string, any>[] {
  return rows.map((row) => Object.fromEntries(Object.entries(row).map(([key, value]) => [key, normalize(value)])))
}

export async function run(sql: string, binds: unknown[] = []): Promise<Record<string, any>[]> {
  return normalizeRows(await querySnowflake(sql, { binds: binds as any[] }))
}

export async function runLong(sql: string, binds: unknown[] = []): Promise<Record<string, any>[]> {
  return normalizeRows(await querySnowflakeLongRunning(sql, { binds: binds as any[] }))
}

export function pageParam(value: string | null): number {
  return Math.min(100, Math.max(1, Number.parseInt(value || "1", 10) || 1))
}

export function errorResponse(error: unknown, status = 502): Response {
  console.error(new Date().toISOString(), "[keystone]", error)
  return Response.json({ error: error instanceof Error ? error.message : "Snowflake request failed" }, { status })
}
