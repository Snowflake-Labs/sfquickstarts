/** App title — displayed in the browser tab */
export const APP_TITLE = "Keystone Caseworker Console"

/** Path to the logo in /public (used as favicon) */
export const LOGO_SRC = "/icon.svg"
