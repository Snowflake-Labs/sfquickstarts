#!/bin/bash
cd /app
echo "waiting for kafka to start"
sleep 40
echo "Creating required kafka topics" >> /app/loop.log
kafka-topics --create --partitions 1 --topic gen_cust_info --bootstrap-server kafka1:9092
kafka-topics --create --partitions 1 --topic gen_prod_inv --bootstrap-server kafka1:9092
kafka-topics --create --partitions 3 --topic gen_cust_purchase --bootstrap-server kafka1:9092
echo "Connecting to Snowflake" >> /app/loop.log
connect-standalone connect-std.properties sf_streaming.properties
sleep 10

# Infinite loop, so you can access docker container anytime
while true
do
    #echo "Script is running..."
    sleep 10  # Delay for 1 second (adjust as needed)
done
