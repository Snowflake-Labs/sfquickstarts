from kafka import KafkaProducer
import json
from faker import Faker
import random
import sys
import os
from datetime import datetime, timedelta


fake = Faker()


def show_usage():
    print("Usage for python kafka producer script:")
    print("cust-info-producer.py Int1")
    print("Arguments:")
    print("Int1: Number of Customer information records to produce")
    print("Example:")
    print("cust-info-producer.py 1000")
    exit(1)

if len(sys.argv) >=1:
    if int(sys.argv[1]) >= 100:
        nrecords = int(sys.argv[1])
    else:
        print("Numbers of records default to minimum 100")
        nrecords = 100
else:
    show_usage()

customer_id = 1000 # Starting customer ID

# Generate fake customer purchase data
def generate_customer_info():
    global customer_id
    customer = {
        'custid': customer_id,
        'cname': fake.name(),
        'spendlimit': round(random.uniform(1000, 10000), 2)
    }
    customer_id += 1
    return customer

############ Producer Code #######

bootstrap_servers = 'kafka1:9092,kafka2:9092'  # Specify the Kafka broker(s)
producer = KafkaProducer(bootstrap_servers=bootstrap_servers, value_serializer=lambda v: json.dumps(v).encode('utf-8'))

print("Start Time of Process: " + str(datetime.now()))
def run_producer(num_records):
    # Iterate over all files and subdirectories in the specified directory
    for _ in range(num_records):
        record = generate_customer_info()        
        producer.send('gen_cust_info', record)
    producer.flush()


try:
    run_producer(nrecords)
    print (f"Producer ran gen_cust_info successfully and sent {nrecords} to Kafka")
    print("End Time of Process: " + str(datetime.now()))
except Exception as e:
    # Exception handling for other exceptions
    print("An error occurred:", str(e))

