#!/bin/bash
echo "waiting for kafka to start"
sleep 60

echo "Generating Customer Info records"
python /app/cust-info-producer.py 100
sleep 10  # Delay for 10 second (adjust as needed)

echo "Generating Product Inventory records"
python /app/product-inv-producer.py 1000
sleep 10  # Delay for 10 second (adjust as needed)


# Infinite loop
while true
do
    echo "Generating Customer Purchase records to simulate streaming..."
    python /app/cust-purchase-producer.py 20000 100
    sleep 10  # Delay for 10 second (adjust as needed)
done
