from kafka import KafkaProducer
import json
from faker import Faker
import random
import sys
import os
from datetime import datetime, timedelta


fake = Faker()


def show_usage():
    print("Usage for python kafka producer script:")
    print("product-inv-producer.py Int1")
    print("Arguments:")
    print("Int1: Number of Product JSON records to produce")
    print("Example:")
    print("product-inv-producer.py 1000")
    exit(1)

if len(sys.argv) >=1:

    if int(sys.argv[1]) >= 100:
        nrecords = int(sys.argv[1])
    else:
        print("Numbers of records default to minimum 100")
        nrecords = 100

else:
    show_usage()

product_id = 100 # Starting customer ID

# Generate fake customer purchase data
def generate_product_info():
    global product_id
    # Get the current date
    current_date = datetime.now()
            
    # Calculate the maximum date (3 months from now)
    min_date = current_date - timedelta(days=90)
    pdate = fake.date_between_dates(min_date,current_date).strftime('%Y-%m-%d')
    product = {
        'pid': product_id,
        'pname': fake.catch_phrase(),
        'stock': round(random.uniform(500, 1000),0),
        'stockdate': pdate
    }
    product_id += 1
    return product

############ Producer Code #######

bootstrap_servers = 'kafka1:9092,kafka2:9092'  # Specify the Kafka broker(s)
producer = KafkaProducer(bootstrap_servers=bootstrap_servers, value_serializer=lambda v: json.dumps(v).encode('utf-8'))

print("Start Time of Process: " + str(datetime.now()))
def run_producer(num_records):
    # Iterate over all files and subdirectories in the specified directory
    for _ in range(num_records):
        record = generate_product_info()        
        producer.send('gen_prod_inv', record)
    producer.flush()


try:
    run_producer(nrecords)
    print (f"Producer ran successfully and sent {nrecords} to Kafka")
    print("End Time of Process: " + str(datetime.now()))
except Exception as e:
    # Exception handling for other exceptions
    print("An error occurred:", str(e))

