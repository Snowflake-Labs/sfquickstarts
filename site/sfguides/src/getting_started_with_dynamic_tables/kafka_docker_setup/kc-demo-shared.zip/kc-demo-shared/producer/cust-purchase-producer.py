from kafka import KafkaProducer
import json
from faker import Faker
import random
import sys
import os
from datetime import datetime, timedelta


fake = Faker()


def show_usage():
    print("Usage for python kafka producer script:")
    print("cust-purchase-producer.py Int1 Int2")
    print("Arguments:")
    print("Int1: Numbers of purchase records to be generated")
    print("Int2: Number of customers info to be generated")
    print("Example:")
    print("cust-purchase-producer.py 1000 100")
    exit(1)

if len(sys.argv) >=1:
    if int(sys.argv[1]) >= 1000:
        nrecords = int(sys.argv[1])
    else:
        print("Number of purchase records to be generated - default to minimum 1000")
        nrecords = 1000

    if int(sys.argv[2]) >= 100:
        ncust = int(sys.argv[2])
    else:
        print("Numbers of customers default to minimum 100")
        ncust = 100
else:
    show_usage()

# Starting customer ID as 1001
customer_id = 1001       

# Generate fake customer purchase data
def generate_customer_purchase():
    global ncust
    c_id_tot = 1001 + ncust
    c_id = fake.random_int(min=1001, max=(c_id_tot-1))

    customer_purchase = {
        'custid': c_id,
        'purchase': {}
    }
    # Get the current date
    current_date = datetime.now()

    # Calculate the maximum date (days from now)
    min_date = current_date - timedelta(days=10)

    # Generate a random date within the date range
    pdate = fake.date_between_dates(min_date,current_date).strftime('%Y-%m-%d')

    purchase = {
        'prodid': fake.random_int(min=101, max=199),
        'quantity': fake.random_int(min=1, max=5),
        'purchase_amount': round(random.uniform(10, 1000),2),
        'purchase_date': pdate
    }
    customer_purchase['purchase'] = purchase

    return customer_purchase

############ Producer Code #######

bootstrap_servers = 'kafka1:9092,kafka2:9092'  # Specify the Kafka broker(s)
producer = KafkaProducer(bootstrap_servers=bootstrap_servers, value_serializer=lambda v: json.dumps(v).encode('utf-8'))

print("Start Time of Process: " + str(datetime.now()))
def run_producer(num_records):
    # Iterate over all files and subdirectories in the specified directory
    for _ in range(num_records):
        record = generate_customer_purchase()        
        producer.send('gen_cust_purchase', record)
    producer.flush()


try:
    run_producer(nrecords)
    print (f"Producer ran successfully and sent {nrecords} to Kafka")
    print("End Time of Process: " + str(datetime.now()))
except Exception as e:
    # Exception handling for other exceptions
    print("An error occurred:", str(e))

