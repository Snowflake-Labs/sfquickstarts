import streamlit as st
import os
import snowflake.connector
from snowflake.core import Root
from snowflake.snowpark import Session
from snowflake.snowpark.context import get_active_session
import snowflake.cortex

# Minimum relevance score for Cortex Search results to be considered as context.
# Scores typically range from 0.0 to 1.0. You can tune this as needed.
MIN_RELEVANCE_SCORE = 0.4

st.set_page_config(page_title="Snowswift AI Chat Hub", page_icon="❄️", layout="wide", initial_sidebar_state="expanded")

def get_system_token():
    """
    Reads the container's system token.
    """
    try:
        with open("/snowflake/session/token", "r") as f:
            return f.read().strip()
    except Exception:
        return None

def initialize_sessions(ingress_user_token):
    """
    Initializes the Owner and Visitor Snowpark Sessions.

    Sessions are cached **per Streamlit browser session** via `st.session_state`,
    so they are reused across reruns for the same user, but never shared
    between different users like `st.cache_resource` would do.
    """
    # Reuse already-initialized sessions for this Streamlit session
    if "sessions" in st.session_state:
        return st.session_state["sessions"]
    sessions = {
        "owner_session": None,
        "visitor_session": None
    }
    
    # ---------------------------------------------------------
    # 1. Create Owner Session (The Container's Identity)
    # ---------------------------------------------------------
    try:
        st.info("🔐 Establishing **Owner** session...")
        # In SiS Container Runtime, get_active_session() retrieves the 
        # implict connection for the container (Service Role)
        sessions["owner_session"] = get_active_session()
        st.success("✅ Owner session established.")
    except Exception as e:
        st.warning(f"⚠️ Could not establish Owner session: {e}")
        return sessions # Cannot proceed without owner session

    # ---------------------------------------------------------
    # 2. Create Visitor Session (The Human User's Identity)
    # ---------------------------------------------------------
    if ingress_user_token:
        try:
            st.info("🔐 Establishing **Visitor** session (restricted caller)...")
            
            # A. Construct the Composite Token (System Token + . + User Token)
            system_token = get_system_token()
            
            if not system_token:
                raise Exception("Could not read /snowflake/session/token required for OBO flow.")
            
            # This matches the logic in your working snippet
            composite_token = f"{system_token}.{ingress_user_token}"

            # B. Get Connection Details
            owner_conn = sessions["owner_session"].connection
            
            host = os.getenv('SNOWFLAKE_HOST') or owner_conn.host
            account = os.getenv('SNOWFLAKE_ACCOUNT') or owner_conn.account
            warehouse = os.getenv('SNOWFLAKE_WAREHOUSE') or owner_conn.warehouse
            database = os.getenv('SNOWFLAKE_DATABASE') or owner_conn.database
            schema = os.getenv('SNOWFLAKE_SCHEMA') or owner_conn.schema
            
            # C. Build the Visitor Configuration
            visitor_creds = {
                "account": account,
                "host": host,
                "authenticator": "oauth",
                "token": composite_token,  # The chained token
                "warehouse": warehouse,
                "database": database,
                "schema": schema,
                "client_session_keep_alive": True
            }

            # D. Create the Session
            sessions["visitor_session"] = Session.builder.configs(visitor_creds).create()
            st.success("✅ Visitor session established.")
            
        except Exception as e:
            st.warning(f"⚠️ Could not establish Visitor session: {e}")
            if st.session_state.get("debug"):
                st.error(f"Debug Detail: {str(e)}")
            
    # Clear all ephemeral info messages
    st.empty()

    # Cache per-browser-session so we don't recreate on every rerun
    st.session_state["sessions"] = sessions
    return sessions

def init_messages():
    if st.session_state.clear_conversation or "messages" not in st.session_state:
        st.session_state.messages = []

def get_current_role_from_session(session):
    try:
        current = session.sql("SELECT CURRENT_ROLE()").collect()[0][0]
        # Return a simple string for use in filters and logging
        return current if current else "UNKNOWN"

    except Exception as e:
        st.warning(f"Could not fetch roles: {e}")
        return "UNKNOWN"


def is_visitor_session_secure(session):
    """
    Securely determine if this is a visitor session by checking the session context.
    """
    try:
        current_user = session.sql('SELECT CURRENT_USER() AS user').collect()[0]['USER']
        
        # Get headers safely
        headers = st.context.headers or {}
        ingress_user = headers.get("Sf-Context-Current-User")
        ingress_user_token = headers.get("Sf-Context-Current-User-Token")
        
        return ingress_user_token is not None and current_user == ingress_user
    except Exception:
        return False

def initialize_session_state():
    if "messages" not in st.session_state:
        st.session_state.messages = []
    if "model_name" not in st.session_state:
        st.session_state.model_name = "mixtral-8x7b"
    if "use_chat_history" not in st.session_state:
        st.session_state.use_chat_history = True
    if "num_chat_messages" not in st.session_state:
        st.session_state.num_chat_messages = 5
    if "debug" not in st.session_state:
        st.session_state.debug = False
    if "clear_conversation" not in st.session_state:
        st.session_state.clear_conversation = False

def query_cortex_search_service(query, current_session):
    # Always use the owner session for cortex search service access
    owner_root = Root(sessions["owner_session"])
    
    # Update these to your specific DB/Schema names
    cortex_search_service = (
        owner_root.databases["RAG_DB"]
        .schemas["RAG_SCHEMA"]
        .cortex_search_services["rag_cortex_search_service"]
    )

    current_role = get_current_role_from_session(current_session)
    is_visitor = is_visitor_session_secure(current_session)

    scoring_profile = "default_with_components"

    if is_visitor and current_role and current_role != "UNKNOWN":
        filter_condition = {"@eq": {"product_department": current_role}}
        context_documents = cortex_search_service.search(
            query,
            columns=["CHUNK"],
            filter=filter_condition,
            scoring_profile=scoring_profile,
        )
        filter_applied = f"product_department @eq '{current_role}' (server-validated)"
    else:
        context_documents = cortex_search_service.search(
            query,
            columns=["CHUNK"],
            scoring_profile=scoring_profile,
        )
        filter_applied = "No filter (Owner access)"

    results = context_documents.results

    # Apply a simple relevance score threshold to filter out weak matches.
    # Use the semantic cosine_similarity score from the @scores component.
    filtered_results = []
    for r in results:
        scores = r.get("@scores") or {}
        score = scores.get("cosine_similarity")
        try:
            score_val = float(score) if score is not None else 1.0
        except (TypeError, ValueError):
            score_val = 1.0

        if score_val >= MIN_RELEVANCE_SCORE:
            filtered_results.append(r)

    context_list = [
        f"Context document {i+1}: {r['CHUNK']}"
        for i, r in enumerate(filtered_results)
    ]
    context_str = "\n\n".join(context_list)

    if st.session_state.debug:
        # Show semantic relevance scores alongside chunks in debug mode
        debug_context_list = []
        for r in filtered_results:
            scores = r.get("@scores") or {}
            cosine = scores.get("cosine_similarity", "N/A")
            debug_context_list.append(f"[cosine={cosine}] {r['CHUNK']}")
        debug_context_str = "\n\n".join(debug_context_list)

        st.sidebar.text_area("Context documents", debug_context_str, height=500)
        st.sidebar.write(f"**Search performed with role:** {current_role}")
        st.sidebar.write(f"**Is visitor session:** {is_visitor}")
        st.sidebar.write(f"**Filter applied:** {filter_applied}")
        st.sidebar.write(f"**Results returned (raw):** {len(results)} documents")
        st.sidebar.write(f"**Results used after score threshold ({MIN_RELEVANCE_SCORE}):** {len(filtered_results)} documents")

    return context_str

def get_chat_history():
    start_index = max(0, len(st.session_state.messages) - (st.session_state.num_chat_messages * 2))
    return st.session_state.messages[start_index:]

def make_chat_history_summary(chat_history, question, current_session):
    prompt = f"""
        [INST]
        Based on the chat history below and the question, generate a query that extend the question
        with the chat history provided. The query should be in natural language.
        Answer with only the query. Do not add any explanation.

        <chat_history>
        {chat_history}
        </chat_history>
        <question>
        {question}
        </question>
        [/INST]
    """

    owner_session = sessions["owner_session"]
    summary = owner_session.sql(f"""
        SELECT SNOWFLAKE.CORTEX.COMPLETE(
            '{st.session_state.model_name}',
            $${prompt}$$
        ) as response
    """).collect()[0]['RESPONSE']

    if st.session_state.debug:
        st.sidebar.text_area(
            "Chat history summary", summary.replace("$", "\$"), height=150
        )

    return summary

def create_prompt(user_question, session):
    """
    Generates the prompt. Returns None if no context is found.
    """
    # 1. Handle Chat History / Search Query generation
    if st.session_state.use_chat_history:
        chat_history = get_chat_history()
        if chat_history != []:
            question_summary = make_chat_history_summary(chat_history, user_question, session)
            prompt_context = query_cortex_search_service(question_summary, session)
        else:
            prompt_context = query_cortex_search_service(user_question, session)
            chat_history = ""
    else:
        prompt_context = query_cortex_search_service(user_question, session)
        chat_history = ""

    # ---------------------------------------------------------
    # Create Guardrail if no results are returned to RAG
    # ---------------------------------------------------------
    if not prompt_context or not prompt_context.strip():
        return None

    # 2. Build the Prompt (Only if context exists)
    prompt = f"""
            [INST]
            You are a helpful chatbot with RAG capabilities. Users will ask you about products in our product line. 
            Use the context provided between <context> and </context> tags to answer.
            
            <chat_history>
            {chat_history}
            </chat_history>
            
            <context>
            {prompt_context}
            </context>
            
            <question>
            {user_question}
            </question>
            [/INST]
            Answer:
        """
    return prompt


# --- Main App Logic ---

initialize_session_state()

st.title("❄️ AI Chat Hub (with Access Control)")
st.subheader(":snowflake: Powered by SPCS & Streamlit")

with st.sidebar:
    st.header("⚙️ Options")
    st.session_state.debug = st.checkbox("🔧 Debug Mode", value=False)
    
    st.session_state.model_name = st.selectbox(
        "Select a model",
        ("mixtral-8x7b", "mistral-large", "llama3-8b", "llama3-70b"),
        index=0
    )
    st.session_state.use_chat_history = st.toggle("Use Chat History", value=True)
    st.session_state.num_chat_messages = st.slider("Chat History Depth (pairs)", 1, 10, 5)

# Safe header retrieval
headers = st.context.headers or {}
ingress_user_token = headers.get("Sf-Context-Current-User-Token")
ingress_user = headers.get("Sf-Context-Current-User")

# --- Session Initialization ---
with st.spinner("Initializing Snowflake sessions..."):
    sessions = initialize_sessions(ingress_user_token)

# Session Selection: if an ingress_user_token is present and we successfully
# created a visitor session, always use that; otherwise fall back to owner.
if ingress_user_token and sessions.get("visitor_session"):
    session = sessions["visitor_session"]
    user = ingress_user
    session_key = "visitor_session"

elif sessions.get("owner_session"):
    session = sessions["owner_session"]
    user = "Owner"
    session_key = "owner_session"
else:
    st.error("❌ Cannot establish a valid Snowpark Session. Check logs/env vars.")
    st.stop()

# Extract role information
try:
    session_context = session.sql('SELECT CURRENT_USER() AS user, CURRENT_ROLE() AS role').collect()[0]
    current_role = session_context['ROLE']
    current_user = session_context['USER']
    
    st.session_state.current_role = current_role
    st.session_state.current_user = current_user
    st.session_state.session_key = session_key
    
    if st.session_state.debug:
        st.sidebar.write(f"**Current Role:** {current_role}")
        st.sidebar.write(f"**Current User:** {current_user}")
        st.sidebar.write(f"**Session Type:** {session_key}")
        
except Exception as e:
    st.error(f"❌ Could not extract session context: {e}")
    st.session_state.current_role = "UNKNOWN"
    st.session_state.current_user = user
    st.session_state.session_key = session_key

icons = {"assistant": "❄️", "user": "👤"}

for message in st.session_state.messages:
    with st.chat_message(message["role"], avatar=icons[message["role"]]):
        st.markdown(message["content"])

if question := st.chat_input("Ask a question..."):
    st.session_state.messages.append({"role": "user", "content": question})
    with st.chat_message("user", avatar=icons["user"]):
        st.markdown(question.replace("$", "\$"))

    with st.chat_message("assistant", avatar=icons["assistant"]):
        message_placeholder = st.empty()
        question = question.replace("'", "")
        
        with st.spinner("Thinking..."):
            # 1. Generate the prompt (or get None if no docs found)
            prompt_text = create_prompt(question, session)
            
            # 2. GUARDRAIL: Check if we have a valid prompt
            if prompt_text is None:
                # Fallback response - No LLM credits used here!
                generated_response = "I'm sorry, but I couldn't find any relevant documents in the database to answer your question."
                message_placeholder.warning(generated_response)
            else:
                # 3. Only call Cortex if we have context
                owner_session = sessions["owner_session"]
                response_query = f"""
                    SELECT SNOWFLAKE.CORTEX.COMPLETE(
                        '{st.session_state.model_name}',
                        $${prompt_text}$$
                    ) as response
                """
                
                generated_response = owner_session.sql(response_query).collect()[0]['RESPONSE']
                message_placeholder.markdown(generated_response)

    # Append to history
    st.session_state.messages.append(
        {"role": "assistant", "content": generated_response}
    )


    st.session_state.messages.append(
        {"role": "assistant", "content": generated_response}
    )