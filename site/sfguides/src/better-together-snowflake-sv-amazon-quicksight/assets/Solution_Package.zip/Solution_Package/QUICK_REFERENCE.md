# QuickSight Dataset Generator - Quick Reference

## One-Line Commands

### Generate Schema + Create Dataset + Share
```bash
# Step 1: Generate schema
python generate_quicksight_schema_v2.py --csv-path SF_DDL.csv --datasource-arn "arn:aws:quicksight:us-east-1:ACCOUNT_ID:datasource/DATASOURCE_ID" --database MOVIES --output quicksight_schema_complete.json

# Step 2: Create and share dataset
python test_complete_schema.py --share-with "Administrator/username-Isengard"
```

## Common Commands

### List Available Users
```bash
aws quicksight list-users --aws-account-id ACCOUNT_ID --namespace default --profile default --region us-east-1 --query 'UserList[].UserName'
```

### Check Dataset Status
```bash
aws quicksight describe-data-set --aws-account-id ACCOUNT_ID --data-set-id DATASET_ID --profile default --region us-east-1
```

### Check Ingestion Status
```bash
aws quicksight describe-ingestion --aws-account-id ACCOUNT_ID --data-set-id DATASET_ID --ingestion-id INGESTION_ID --profile default --region us-east-1
```

### Check Dataset Permissions
```bash
aws quicksight describe-data-set-permissions --aws-account-id ACCOUNT_ID --data-set-id DATASET_ID --profile default --region us-east-1
```

### Delete Dataset
```bash
aws quicksight delete-data-set --aws-account-id ACCOUNT_ID --data-set-id DATASET_ID --profile default --region us-east-1
```

## Script Parameters

### generate_quicksight_schema_v2.py
| Parameter | Required | Default | Description |
|-----------|----------|---------|-------------|
| --csv-path | No | ../SF_DDL.csv | Path to Snowflake DDL CSV |
| --datasource-arn | Yes | - | QuickSight data source ARN |
| --database | No | MOVIES | Snowflake database name |
| --dataset-id | No | movie-analytics-dataset | Dataset ID |
| --dataset-name | No | Movie Analytics Dataset | Dataset display name |
| --output | No | quicksight_schema_complete.json | Output file path |

### test_complete_schema.py
| Parameter | Required | Default | Description |
|-----------|----------|---------|-------------|
| --profile | No | - | AWS profile name (uses default if not specified) |
| --region | No | us-east-1 | AWS region |
| --share-with | No | - | Username to share with |

## Username Formats

| Format | Example | Use Case |
|--------|---------|----------|
| Full with namespace | `Administrator/wangzyn-Isengard` | Internal users with namespace prefix |
| Simple | `reader1` | Simple QuickSight users |
| Federated | `quicksight-fed-us-users/email@domain.com` | Federated identity users |

## Dataset Structure

### Tables (3)
- RATINGS_CURATED (fact)
- MOVIES_CURATED (dimension)
- USERS_CURATED (dimension)

### Joins
RATINGS → MOVIES → USERS (OUTER joins)

### Calculated Fields (8)
1. USER_FULL_NAME
2. MOVIES_DISTINCT_MOVIES
3. USERS_DISTINCT_USERS
4. RATINGS_TOTAL_RATINGS
5. RATINGS_AVG_RATING
6. RATINGS_DISTINCT_USERS
7. RATINGS_DISTINCT_MOVIES
8. RATINGS_POPULARITY_SCORE

### Output Columns (23)
- 2 Rating columns
- 3 Movie columns
- 11 User columns (all with USER_ prefix)
- 7 Metric columns

## Dataset Permissions

When sharing a dataset with `--share-with`, the following **full permissions** are granted:

| Permission | Description |
|------------|-------------|
| UpdateDataSetPermissions | Manage who can access the dataset |
| DescribeDataSet | View dataset details and schema |
| DescribeDataSetPermissions | View current permissions |
| PassDataSet | Use dataset in analyses and dashboards |
| DescribeIngestion | View ingestion status and details |
| ListIngestions | List all data refresh operations |
| UpdateDataSet | Modify dataset configuration |
| DeleteDataSet | Delete the dataset |
| CreateIngestion | Start new data refresh |
| CancelIngestion | Cancel running data refresh |

**Total: 10 permissions** - Full control over the dataset

## Troubleshooting

| Error | Solution |
|-------|----------|
| Namespace not found | Use `default` namespace or check with `list-namespaces` |
| User not found | Verify username with `list-users` |
| Field does not exist | Check column is in ProjectedColumns list |
| Ingestion failed | Check data source credentials and permissions |

## File Locations

```
quick_start/Solution_Package/
├── generate_quicksight_schema_v2.py    # Schema generator
├── test_complete_schema.py             # Dataset creator
├── SF_DDL.csv                          # Input DDL
├── quicksight_schema_complete.json     # Generated schema
├── USAGE_GUIDE.md                      # Detailed usage
├── COMPLETE_SCHEMA_SUMMARY.md          # Technical details
├── FINAL_SUMMARY.md                    # Project summary
└── QUICK_REFERENCE.md                  # This file
```

## Support Resources

- **AWS QuickSight Docs**: https://docs.aws.amazon.com/quicksight/
- **Boto3 QuickSight**: https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/quicksight.html
- **Snowflake Semantic Views**: https://docs.snowflake.com/en/user-guide/semantic-views

## Quick Test

```bash
# Test the complete workflow
cd quick_start/Solution_Package

# Generate schema
python generate_quicksight_schema_v2.py \
  --csv-path SF_DDL.csv \
  --datasource-arn "arn:aws:quicksight:us-east-1:889399602426:datasource/movies-snowflake-datasource" \
  --output quicksight_schema_complete.json

# Create and share
python test_complete_schema.py \
  --profile default \
  --region us-east-1 \
  --share-with "Administrator/wangzyn-Isengard"

# Verify
aws quicksight describe-data-set \
  --aws-account-id 889399602426 \
  --data-set-id movie-analytics-dataset-v2 \
  --profile default \
  --region us-east-1 \
  --query 'DataSet.OutputColumns[].Name'
```
