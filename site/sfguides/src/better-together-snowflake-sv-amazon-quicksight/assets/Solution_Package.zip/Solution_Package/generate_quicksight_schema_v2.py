#!/usr/bin/env python3
"""
Snowflake DDL to QuickSight Dataset Schema Generator V2

This script reads a Snowflake DDL CSV file and generates a complete QuickSight dataset schema
with all 3 tables, joins, renames, calculated fields, and descriptions.
"""

import csv
import re
import json
import uuid
from typing import Dict, List, Tuple


class SnowflakeDDLParser:
    """Parser for Snowflake Semantic View DDL"""
    
    def __init__(self, csv_path: str):
        self.csv_path = csv_path
        self.ddl_content = ""
        self.tables = []
        self.relationships = []
        self.facts = []
        self.dimensions = []
        self.metrics = []
        self.dimension_comments = {}  # Store comments for dimensions
    
    def read_csv(self):
        """Read DDL content from CSV file"""
        with open(self.csv_path, 'r', encoding='utf-8') as f:
            reader = csv.reader(f)
            next(reader)  # Skip header
            for row in reader:
                if len(row) > 1:
                    self.ddl_content = row[1]
                    break
        return self.ddl_content
    
    def parse_tables(self):
        """Parse table definitions from DDL"""
        tables_match = re.search(r'tables\s*\((.*?)\)\s*relationships', self.ddl_content, re.DOTALL)
        if not tables_match:
            return []
        
        tables_content = tables_match.group(1)
        table_pattern = r'(\w+)\s+as\s+([\w.]+)\s+primary key\s*\((.*?)\)'
        
        for match in re.finditer(table_pattern, tables_content):
            alias = match.group(1)
            full_name = match.group(2)
            primary_keys = [pk.strip() for pk in match.group(3).split(',')]
            
            # Extract schema and table name
            parts = full_name.split('.')
            schema = parts[1] if len(parts) > 1 else 'PUBLIC'
            table_name = parts[2] if len(parts) > 2 else parts[-1]
            
            self.tables.append({
                'alias': alias,
                'full_name': full_name,
                'schema': schema,
                'table_name': table_name,
                'primary_keys': primary_keys
            })
        
        return self.tables
    
    def parse_relationships(self):
        """Parse relationship definitions from DDL"""
        rel_match = re.search(r'relationships\s*\((.*?)\)\s*facts', self.ddl_content, re.DOTALL)
        if not rel_match:
            return []
        
        rel_content = rel_match.group(1)
        rel_pattern = r'(\w+)\s+as\s+(\w+)\((.*?)\)\s+references\s+(\w+)\((.*?)\)'
        
        for match in re.finditer(rel_pattern, rel_content):
            self.relationships.append({
                'name': match.group(1),
                'from_table': match.group(2),
                'from_column': match.group(3),
                'to_table': match.group(4),
                'to_column': match.group(5)
            })
        
        return self.relationships
    
    def parse_facts(self):
        """Parse fact definitions from DDL"""
        facts_match = re.search(r'facts\s*\((.*?)\)\s*dimensions', self.ddl_content, re.DOTALL)
        if not facts_match:
            return []
        
        facts_content = facts_match.group(1)
        fact_pattern = r'([\w.]+)\s+as\s+([\w.]+)'
        
        for match in re.finditer(fact_pattern, facts_content):
            source = match.group(1)
            alias = match.group(2)
            
            self.facts.append({
                'source': source,
                'alias': alias,
                'type': 'DECIMAL'
            })
        
        return self.facts
    
    def parse_dimensions(self):
        """Parse dimension definitions from DDL with comments"""
        dim_match = re.search(r'dimensions\s*\((.*?)\)\s*metrics', self.ddl_content, re.DOTALL)
        if not dim_match:
            return []
        
        dim_content = dim_match.group(1)
        
        # Split by lines and parse each dimension
        lines = dim_content.split('\n')
        
        for line in lines:
            line = line.strip()
            if not line or line.startswith('--'):
                continue
            
            # Match dimension definition with comment
            dim_match = re.match(r'([\w.]+)\s+as\s+(.+?)(?:\s+(?:with|comment)|,|$)', line)
            if dim_match:
                alias = dim_match.group(1)
                expression = dim_match.group(2).strip()
                
                # Extract comment if present
                comment_match = re.search(r"comment='([^']+)'", line)
                comment = comment_match.group(1) if comment_match else ''
                
                # Store comment
                if comment:
                    self.dimension_comments[alias] = comment
                
                # Extract column name
                col_name = expression
                if '(' not in expression and '.' in expression:
                    col_name = expression.split('.')[-1]
                elif '(' in expression:
                    col_match = re.search(r'[\w.]+\.(\w+)', expression)
                    if col_match:
                        col_name = col_match.group(1)
                
                # Determine data type
                data_type = self._infer_data_type(expression, alias)
                
                self.dimensions.append({
                    'alias': alias,
                    'expression': expression,
                    'column_name': col_name,
                    'type': data_type,
                    'comment': comment
                })
        
        return self.dimensions
    
    def parse_metrics(self):
        """Parse metric definitions from DDL with comments"""
        metrics_start = self.ddl_content.find('metrics (')
        if metrics_start == -1:
            return []
        
        last_comment = self.ddl_content.rfind("comment='")
        if last_comment == -1:
            return []
        
        metrics_section = self.ddl_content[metrics_start:last_comment]
        metrics_content = metrics_section[8:].strip()
        
        last_paren = metrics_content.rfind(')')
        if last_paren != -1:
            metrics_content = metrics_content[:last_paren]
        
        # Find all metrics using regex - use simpler pattern
        pattern = r'([\w.]+)\s+as\s+(.+?)\s+with\s+synonyms'
        matches = re.findall(pattern, metrics_content, re.DOTALL)
        
        for match in matches:
            alias = match[0].strip()
            expression = match[1].strip()
            
            # Extract comment if present in the full line
            # Find the line containing this metric
            for line in metrics_content.split('\n'):
                if alias in line and 'as' in line:
                    comment_match = re.search(r"comment='([^']+)'", line)
                    comment = comment_match.group(1) if comment_match else ''
                    break
            else:
                comment = ''
            
            data_type = 'INTEGER' if 'COUNT' in expression.upper() else 'DECIMAL'
            
            self.metrics.append({
                'alias': alias,
                'expression': expression,
                'type': data_type,
                'comment': comment
            })
        
        return self.metrics
    
    def _infer_data_type(self, expression: str, alias: str) -> str:
        """Infer QuickSight data type from expression"""
        expression_upper = expression.upper()
        alias_upper = alias.upper()
        
        if any(func in expression_upper for func in ['YEAR(', 'MONTH(', 'DAY(']):
            return 'INTEGER'
        if 'TIMESTAMP' in alias_upper or 'DATE' in alias_upper:
            return 'DATETIME'
        if 'CONCAT(' in expression_upper:
            return 'STRING'
        if any(word in alias_upper for word in ['ID', 'YEAR', 'MONTH', 'DAY']):
            return 'INTEGER'
        
        return 'STRING'
    
    def parse_all(self):
        """Parse all components of the DDL"""
        self.read_csv()
        self.parse_tables()
        self.parse_relationships()
        self.parse_facts()
        self.parse_dimensions()
        self.parse_metrics()
        
        return {
            'tables': self.tables,
            'relationships': self.relationships,
            'facts': self.facts,
            'dimensions': self.dimensions,
            'metrics': self.metrics,
            'dimension_comments': self.dimension_comments
        }


class QuickSightSchemaGenerator:
    """Generate complete QuickSight dataset schema from parsed DDL"""
    
    def __init__(self, parsed_ddl: Dict):
        self.parsed_ddl = parsed_ddl
        self.physical_table_map = {}
        self.logical_table_map = {}
    
    def generate_physical_table_map(self, datasource_arn: str, database: str) -> Dict:
        """Generate PhysicalTableMap for all tables"""
        for table in self.parsed_ddl['tables']:
            table_id = str(uuid.uuid4()) if table['alias'].lower() != 'ratings' else 'ratings'
            
            # Get all actual columns from the Snowflake table
            # These should be the ACTUAL column names in Snowflake, not the renamed versions
            input_columns = []
            seen_columns = set()
            
            # For each table, add the actual Snowflake columns
            if table['alias'].upper() == 'RATINGS':
                # RATINGS table columns from DDL
                input_columns = [
                    {'Name': 'USERID', 'Type': 'INTEGER'},
                    {'Name': 'MOVIEID', 'Type': 'INTEGER'},
                    {'Name': 'RATING', 'Type': 'DECIMAL', 'SubType': 'FLOAT'},
                    {'Name': 'TIMESTAMP', 'Type': 'DATETIME'}
                ]
            elif table['alias'].upper() == 'MOVIES':
                # MOVIES table columns from DDL
                input_columns = [
                    {'Name': 'MOVIEID', 'Type': 'INTEGER'},
                    {'Name': 'TITLE', 'Type': 'STRING'},
                    {'Name': 'RELEASE', 'Type': 'INTEGER'}
                ]
            elif table['alias'].upper() == 'USERS':
                # USERS table columns - include all columns that exist in the physical table
                input_columns = [
                    {'Name': 'USERID', 'Type': 'INTEGER'},
                    {'Name': 'FIRSTNAME', 'Type': 'STRING'},
                    {'Name': 'LASTNAME', 'Type': 'STRING'},
                    {'Name': 'STREET', 'Type': 'STRING'},
                    {'Name': 'CITY', 'Type': 'STRING'},
                    {'Name': 'STATE', 'Type': 'STRING'},
                    {'Name': 'POSTCODE', 'Type': 'STRING'},
                    {'Name': 'COUNTRY', 'Type': 'STRING'},
                    {'Name': 'EMAIL', 'Type': 'STRING'},
                    {'Name': 'PHONENUMBER', 'Type': 'STRING'}
                ]
            
            self.physical_table_map[table_id] = {
                'RelationalTable': {
                    'DataSourceArn': datasource_arn,
                    'Catalog': database if table['alias'].lower() == 'ratings' else None,
                    'Schema': table['schema'],
                    'Name': table['table_name'],
                    'InputColumns': input_columns
                }
            }
            
            # Remove None Catalog
            if self.physical_table_map[table_id]['RelationalTable']['Catalog'] is None:
                del self.physical_table_map[table_id]['RelationalTable']['Catalog']
        
        return self.physical_table_map
    
    def generate_logical_table_map(self) -> Dict:
        """Generate complete LogicalTableMap with joins, renames, casts, and calculated fields"""
        
        # Find table IDs
        ratings_id = 'ratings'
        movies_id = [k for k, v in self.physical_table_map.items() if 'MOVIES_CURATED' in v['RelationalTable']['Name']][0]
        users_id = [k for k, v in self.physical_table_map.items() if 'USERS_CURATED' in v['RelationalTable']['Name']][0]
        
        # 1. Base table: RATINGS with casts and renames
        # Note: Cast BEFORE rename so we can still reference original column names
        self.logical_table_map['combined'] = {
            'Alias': 'Combined Data',
            'DataTransforms': [
                {
                    'CastColumnTypeOperation': {
                        'ColumnName': 'USERID',
                        'NewColumnType': 'STRING'
                    }
                },
                {
                    'CastColumnTypeOperation': {
                        'ColumnName': 'MOVIEID',
                        'NewColumnType': 'STRING'
                    }
                },
                {
                    'RenameColumnOperation': {
                        'ColumnName': 'RATING',
                        'NewColumnName': 'RATING_VALUE'
                    }
                },
                {
                    'RenameColumnOperation': {
                        'ColumnName': 'TIMESTAMP',
                        'NewColumnName': 'RATING_TIMESTAMP'
                    }
                }
            ],
            'Source': {
                'PhysicalTableId': ratings_id
            }
        }
        
        # 2. MOVIES table with renames and casts
        movies_logical_id = str(uuid.uuid4())
        self.logical_table_map[movies_logical_id] = {
            'Alias': 'MOVIES_CURATED',
            'DataTransforms': [
                {
                    'RenameColumnOperation': {
                        'ColumnName': 'MOVIEID',
                        'NewColumnName': 'MOVIE_ID'
                    }
                },
                {
                    'CastColumnTypeOperation': {
                        'ColumnName': 'MOVIE_ID',
                        'NewColumnType': 'STRING'
                    }
                },
                {
                    'RenameColumnOperation': {
                        'ColumnName': 'TITLE',
                        'NewColumnName': 'MOVIE_TITLE'
                    }
                },
                {
                    'RenameColumnOperation': {
                        'ColumnName': 'RELEASE',
                        'NewColumnName': 'RELEASE_YEAR'
                    }
                },
                {
                    'CastColumnTypeOperation': {
                        'ColumnName': 'RELEASE_YEAR',
                        'NewColumnType': 'STRING'
                    }
                }
            ],
            'Source': {
                'PhysicalTableId': movies_id
            }
        }
        
        # 3. Intermediate table: Join RATINGS with MOVIES
        # After transforms: RATINGS has MOVIEID (STRING), MOVIES has MOVIE_ID (STRING)
        intermediate1_id = str(uuid.uuid4())
        self.logical_table_map[intermediate1_id] = {
            'Alias': 'Intermediate Table',
            'Source': {
                'JoinInstruction': {
                    'LeftOperand': 'combined',
                    'RightOperand': movies_logical_id,
                    'Type': 'OUTER',
                    'OnClause': '{MOVIEID} = {MOVIE_ID}'
                }
            }
        }
        
        # 4. USERS table with renames and casts
        users_logical_id = str(uuid.uuid4())
        self.logical_table_map[users_logical_id] = {
            'Alias': 'USERS_CURATED',
            'DataTransforms': [
                {
                    'RenameColumnOperation': {
                        'ColumnName': 'USERID',
                        'NewColumnName': 'USER_ID'
                    }
                },
                {
                    'CastColumnTypeOperation': {
                        'ColumnName': 'USER_ID',
                        'NewColumnType': 'STRING'
                    }
                },
                {
                    'RenameColumnOperation': {
                        'ColumnName': 'FIRSTNAME',
                        'NewColumnName': 'USER_FIRST_NAME'
                    }
                },
                {
                    'RenameColumnOperation': {
                        'ColumnName': 'LASTNAME',
                        'NewColumnName': 'USER_LAST_NAME'
                    }
                },
                {
                    'RenameColumnOperation': {
                        'ColumnName': 'STREET',
                        'NewColumnName': 'USER_STREET'
                    }
                },
                {
                    'RenameColumnOperation': {
                        'ColumnName': 'CITY',
                        'NewColumnName': 'USER_CITY'
                    }
                },
                {
                    'RenameColumnOperation': {
                        'ColumnName': 'STATE',
                        'NewColumnName': 'USER_STATE'
                    }
                },
                {
                    'RenameColumnOperation': {
                        'ColumnName': 'POSTCODE',
                        'NewColumnName': 'USER_POSTCODE'
                    }
                },
                {
                    'RenameColumnOperation': {
                        'ColumnName': 'COUNTRY',
                        'NewColumnName': 'USER_COUNTRY'
                    }
                },
                {
                    'RenameColumnOperation': {
                        'ColumnName': 'EMAIL',
                        'NewColumnName': 'USER_EMAIL'
                    }
                },
                {
                    'RenameColumnOperation': {
                        'ColumnName': 'PHONENUMBER',
                        'NewColumnName': 'USER_PHONENUMBER'
                    }
                }
            ],
            'Source': {
                'PhysicalTableId': users_id
            }
        }
        
        # 5. Final table: Join with USERS, add calculated fields and descriptions
        final_id = str(uuid.uuid4())
        
        # Build calculated fields from dimensions and metrics
        calculated_fields = []
        tag_operations = []
        
        # Add USER_FULL_NAME calculated field from dimensions
        user_full_name_dim = next((d for d in self.parsed_ddl['dimensions'] if 'USER_FULL_NAME' in d['alias']), None)
        if user_full_name_dim:
            calculated_fields.append({
                'ColumnName': 'USER_FULL_NAME',
                'ColumnId': str(uuid.uuid4()),
                'Expression': "concat({USER_FIRST_NAME}, ' ', {USER_LAST_NAME})"
            })
            if user_full_name_dim.get('comment'):
                tag_operations.append({
                    'TagColumnOperation': {
                        'ColumnName': 'USER_FULL_NAME',
                        'Tags': [{
                            'ColumnDescription': {
                                'Text': user_full_name_dim['comment']
                            }
                        }]
                    }
                })
        
        # Add ALL metrics as calculated fields
        for metric in self.parsed_ddl['metrics']:
            # Use the full alias to avoid duplicates (e.g., MOVIES.DISTINCT_MOVIES -> MOVIES_DISTINCT_MOVIES)
            col_name = metric['alias'].replace('.', '_').upper()
            
            # Convert Snowflake expression to QuickSight expression
            expression = metric['expression']
            
            # Convert common Snowflake functions to QuickSight
            expression = expression.replace('COUNT(DISTINCT', 'distinct_count(')
            expression = expression.replace('COUNT(', 'count(')
            expression = expression.replace('AVG(', 'avg(')
            expression = expression.replace('SUM(', 'sum(')
            expression = expression.replace('MAX(', 'max(')
            expression = expression.replace('MIN(', 'min(')
            
            # Remove table prefixes and wrap column names in curly braces
            # IMPORTANT: Map to the FINAL column names that exist after all transforms
            # After joins and renames, we have:
            # - MOVIE_ID (from MOVIES table, renamed and cast to STRING)
            # - USER_ID (from USERS table, renamed and cast to STRING)
            # - RATING_VALUE (from RATINGS table, renamed)
            # - USERID and MOVIEID are cast to STRING but NOT renamed in RATINGS base table
            import re
            
            # Handle specific column mappings based on our renames
            # For metrics that reference RATINGS columns, use the available columns
            expression = expression.replace('RATINGS.rating_value', '{RATING_VALUE}')
            
            # For RATINGS.user_id and RATINGS.movie_id, we need to use the joined columns
            # RATINGS_DISTINCT_USERS should count USERID from RATINGS (cast to STRING, not renamed)
            # RATINGS_DISTINCT_MOVIES should count MOVIEID from RATINGS (cast to STRING, not renamed)
            # But these columns are NOT in the projected columns!
            # Solution: Use the joined columns from other tables instead
            expression = expression.replace('RATINGS.user_id', '{USER_ID}')  # Use joined USER_ID from USERS
            expression = expression.replace('RATINGS.movie_id', '{MOVIE_ID}')  # Use joined MOVIE_ID from MOVIES
            
            # For MOVIES and USERS metrics, use the renamed columns
            expression = expression.replace('MOVIES.movie_id', '{MOVIE_ID}')  # After rename
            expression = expression.replace('USERS.user_id', '{USER_ID}')  # After rename
            
            # Handle references to other metrics (e.g., RATINGS.total_ratings -> {RATINGS_TOTAL_RATINGS})
            # These reference other calculated fields
            expression = expression.replace('RATINGS.total_ratings', '{RATINGS_TOTAL_RATINGS}')
            expression = expression.replace('RATINGS.avg_rating', '{RATINGS_AVG_RATING}')
            
            # Remove any remaining table prefixes
            expression = re.sub(r'\b[A-Z_]+\.([a-z_]+)\b', r'{\1}', expression)
            
            calculated_fields.append({
                'ColumnName': col_name,
                'ColumnId': str(uuid.uuid4()),
                'Expression': expression
            })
            
            # Add description if available
            if metric.get('comment'):
                tag_operations.append({
                    'TagColumnOperation': {
                        'ColumnName': col_name,
                        'Tags': [{
                            'ColumnDescription': {
                                'Text': metric['comment']
                            }
                        }]
                    }
                })
        
        # Add descriptions for key fields from dimensions
        field_descriptions = {
            'MOVIE_ID': 'Movie ID',
            'MOVIE_TITLE': 'Title of the movie',
            'RELEASE_YEAR': 'Year the movie was released',
            'USER_ID': 'User ID'
        }
        
        for field, desc in field_descriptions.items():
            tag_operations.append({
                'TagColumnOperation': {
                    'ColumnName': field,
                    'Tags': [{
                        'ColumnDescription': {
                            'Text': desc
                        }
                    }]
                }
            })
        
        # Build final transforms
        transforms = []
        
        # Add calculated fields
        if calculated_fields:
            for calc_field in calculated_fields:
                transforms.append({
                    'CreateColumnsOperation': {
                        'Columns': [calc_field]
                    }
                })
        
        # Add tag operations
        transforms.extend(tag_operations)
        
        # Add project operation to select final columns
        # Include all base columns plus calculated fields
        projected_columns = [
            'RATING_VALUE',
            'RATING_TIMESTAMP',
            'MOVIE_ID',
            'MOVIE_TITLE',
            'RELEASE_YEAR',
            'USER_ID',
            'USER_FIRST_NAME',
            'USER_LAST_NAME',
            'USER_STREET',
            'USER_CITY',
            'USER_STATE',
            'USER_POSTCODE',
            'USER_COUNTRY',
            'USER_EMAIL',
            'USER_PHONENUMBER',
            'USER_FULL_NAME'
        ]
        
        # Add all metric column names (using full alias to avoid duplicates)
        for metric in self.parsed_ddl['metrics']:
            col_name = metric['alias'].replace('.', '_').upper()
            projected_columns.append(col_name)
        
        transforms.append({
            'ProjectOperation': {
                'ProjectedColumns': projected_columns
            }
        })
        
        self.logical_table_map[final_id] = {
            'Alias': 'Intermediate Table (2)',
            'DataTransforms': transforms,
            'Source': {
                'JoinInstruction': {
                    'LeftOperand': intermediate1_id,
                    'RightOperand': users_logical_id,
                    'Type': 'OUTER',
                    'OnClause': '{USERID} = {USER_ID}'
                }
            }
        }
        
        return self.logical_table_map
    
    def generate_complete_schema(self, datasource_arn: str, database: str, 
                                dataset_id: str, dataset_name: str) -> Dict:
        """Generate complete QuickSight dataset schema"""
        self.generate_physical_table_map(datasource_arn, database)
        self.generate_logical_table_map()
        
        schema = {
            'DataSetId': dataset_id,
            'Name': dataset_name,
            'PhysicalTableMap': self.physical_table_map,
            'LogicalTableMap': self.logical_table_map,
            'ImportMode': 'SPICE',
            'DataSetUsageConfiguration': {
                'DisableUseAsDirectQuerySource': False,
                'DisableUseAsImportedSource': False
            }
        }
        
        return schema


def main():
    """Main function"""
    import argparse
    
    parser = argparse.ArgumentParser(
        description='Generate complete QuickSight dataset schema from Snowflake DDL CSV'
    )
    parser.add_argument('--csv-path', default='../SF_DDL.csv', help='Path to Snowflake DDL CSV file')
    parser.add_argument('--datasource-arn', required=True, help='QuickSight data source ARN')
    parser.add_argument('--database', default='MOVIES', help='Snowflake database name')
    parser.add_argument('--dataset-id', default='movie-analytics-dataset', help='QuickSight dataset ID')
    parser.add_argument('--dataset-name', default='Movie Analytics Dataset', help='QuickSight dataset name')
    parser.add_argument('--output', default='quicksight_schema_complete.json', help='Output JSON file path')
    
    args = parser.parse_args()
    
    # Parse DDL
    print(f"Parsing Snowflake DDL from: {args.csv_path}")
    parser = SnowflakeDDLParser(args.csv_path)
    parsed_ddl = parser.parse_all()
    
    print(f"Found {len(parsed_ddl['tables'])} tables")
    print(f"Found {len(parsed_ddl['relationships'])} relationships")
    print(f"Found {len(parsed_ddl['dimensions'])} dimensions")
    print(f"Found {len(parsed_ddl['facts'])} facts")
    print(f"Found {len(parsed_ddl['metrics'])} metrics")
    
    # Generate QuickSight schema
    print("\nGenerating complete QuickSight dataset schema...")
    generator = QuickSightSchemaGenerator(parsed_ddl)
    schema = generator.generate_complete_schema(
        datasource_arn=args.datasource_arn,
        database=args.database,
        dataset_id=args.dataset_id,
        dataset_name=args.dataset_name
    )
    
    # Save to file
    with open(args.output, 'w') as f:
        json.dump(schema, f, indent=2)
    
    print(f"\nComplete schema saved to: {args.output}")
    print("\nThis schema includes:")
    print("  ✓ All 3 physical tables (MOVIES, USERS, RATINGS)")
    print("  ✓ Logical tables with joins")
    print("  ✓ Column renames based on DDL aliases")
    print("  ✓ Type casts (IDs to STRING)")
    print("  ✓ Calculated fields (USER_FULL_NAME, DISTINCT_MOVIES)")
    print("  ✓ Column descriptions from DDL comments")


if __name__ == '__main__':
    main()
