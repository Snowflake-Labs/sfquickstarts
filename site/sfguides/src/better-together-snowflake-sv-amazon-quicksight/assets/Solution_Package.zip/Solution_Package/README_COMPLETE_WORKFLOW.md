# Complete Workflow: Snowflake DDL to QuickSight Dataset

This guide walks you through the complete process of creating a QuickSight dataset from a Snowflake Semantic View DDL.

## 📋 Table of Contents

1. [Overview](#overview)
2. [Prerequisites](#prerequisites)
3. [Step-by-Step Guide](#step-by-step-guide)
4. [Validation](#validation)
5. [Troubleshooting](#troubleshooting)

## Overview

This toolkit automates the process of:
1. Storing Snowflake credentials securely in AWS Secrets Manager
2. Creating a QuickSight data source connected to Snowflake
3. Parsing Snowflake DDL to extract tables, relationships, dimensions, facts, and metrics
4. Generating a QuickSight-compatible dataset schema
5. Creating the dataset in QuickSight with SPICE ingestion

## Prerequisites

### Required
- Python 3.7+
- AWS CLI configured
- boto3 Python package: `pip install boto3`
- AWS account with QuickSight subscription
- Snowflake account with appropriate permissions

### AWS Permissions Required
- QuickSight: CreateDataSource, CreateDataSet, UpdateDataSetPermissions, CreateIngestion
- Secrets Manager: CreateSecret, GetSecretValue
- STS: GetCallerIdentity

## Step-by-Step Guide

### Step 0: Validate Your Setup

First, validate that everything is configured correctly:

```bash
python validate_setup.py --profile quick_suite_sa --skip-optional
```

This checks:
- ✓ Python packages installed
- ✓ AWS credentials configured
- ✓ CSV file exists

### Step 1: Store Snowflake Credentials

Store your Snowflake credentials in AWS Secrets Manager:

**Option A: Interactive Setup (Recommended)**
```bash
./setup_secrets.sh
```

**Option B: AWS CLI**
```bash
aws secretsmanager create-secret \
  --name snowflake-credentials \
  --description "Snowflake credentials for QuickSight" \
  --secret-string '{
    "account": "your-snowflake-account",
    "database": "MOVIES",
    "warehouse": "WORKSHOPWH",
    "user": "your-username",
    "password": "your-password"
  }' \
  --region us-east-1
```

**Verify the secret:**
```bash
aws secretsmanager describe-secret \
  --secret-id snowflake-credentials \
  --region us-east-1
```

### Step 2: Create QuickSight Data Source

Create a QuickSight data source that connects to Snowflake using the credentials from Secrets Manager:

```bash
python create_snowflake_datasource.py \
  --datasource-id movies-snowflake-datasource \
  --datasource-name "Movies Snowflake Data Source" \
  --secret-name snowflake-credentials \
  --profile quick_suite_sa \
  --region us-east-1
```

**Expected Output:**
```
✓ Data Source Created Successfully!
Data Source Details:
  ID: movies-snowflake-datasource
  ARN: arn:aws:quicksight:us-east-1:123456789012:datasource/movies-snowflake-datasource
  Status: CREATION_SUCCESSFUL
```

**Save the ARN** - you'll need it in the next step!

### Step 3: Generate QuickSight Schema

Parse the Snowflake DDL CSV and generate a QuickSight dataset schema:

```bash
python generate_quicksight_schema.py \
  --csv-path /Users/wangzyn/snowflake-quicksight-workshop/quick_start/SF_DDL.csv \
  --datasource-arn "arn:aws:quicksight:us-east-1:123456789012:datasource/movies-snowflake-datasource" \
  --database MOVIES \
  --dataset-id movie-analytics-dataset \
  --dataset-name "Movie Analytics Dataset" \
  --output quicksight_schema.json
```

**Expected Output:**
```
Parsing Snowflake DDL from: .../SF_DDL.csv
Found 3 tables
Found 2 relationships
Found 17 dimensions
Found 1 facts
Found 7 metrics

Schema saved to: quicksight_schema.json
```

**Review the schema:**
```bash
cat quicksight_schema.json | python -m json.tool | head -50
```

### Step 4: Create QuickSight Dataset

Create the dataset in QuickSight using the generated schema:

```bash
python create_dataset_from_schema.py \
  --schema quicksight_schema.json \
  --profile quick_suite_sa \
  --region us-east-1 \
  --share-with "ElevatedAccess/wangzyn-Isengard"
```

**Expected Output:**
```
✓ Dataset created successfully!
Dataset ID: movie-analytics-dataset
Dataset ARN: arn:aws:quicksight:us-east-1:123456789012:dataset/movie-analytics-dataset
Status: CREATION_SUCCESSFUL

✓ SPICE ingestion started!
Ingestion ID: ingestion-1234567890
Ingestion Status: INITIALIZED

✓ Dataset shared with user: ElevatedAccess/wangzyn-Isengard
```

### Step 5: Verify in QuickSight Console

1. Log into AWS QuickSight
2. Go to "Datasets"
3. Find "Movie Analytics Dataset"
4. Click to view the dataset details
5. Check that all fields are present and organized in folders

## Validation

### Full Validation

Run the complete validation including optional checks:

```bash
python validate_setup.py \
  --profile quick_suite_sa \
  --secret-name snowflake-credentials \
  --datasource-id movies-snowflake-datasource
```

**Expected Output:**
```
✓ PASS: Python packages
✓ PASS: AWS credentials
✓ PASS: CSV file
✓ PASS: Secrets Manager secret
✓ PASS: QuickSight data source

Passed: 5/5

✓ All checks passed! You're ready to create QuickSight datasets.
```

### Verify Data Source

```bash
aws quicksight describe-data-source \
  --aws-account-id $(aws sts get-caller-identity --query Account --output text) \
  --data-source-id movies-snowflake-datasource \
  --region us-east-1
```

### Verify Dataset

```bash
aws quicksight describe-data-set \
  --aws-account-id $(aws sts get-caller-identity --query Account --output text) \
  --data-set-id movie-analytics-dataset \
  --region us-east-1
```

### Check SPICE Ingestion Status

```bash
aws quicksight list-ingestions \
  --aws-account-id $(aws sts get-caller-identity --query Account --output text) \
  --data-set-id movie-analytics-dataset \
  --region us-east-1
```

## Troubleshooting

### Issue: "Secret not found"

**Solution:**
```bash
# List all secrets
aws secretsmanager list-secrets --region us-east-1

# Create the secret
./setup_secrets.sh
```

### Issue: "Data source not found"

**Solution:**
```bash
# List all data sources
aws quicksight list-data-sources \
  --aws-account-id $(aws sts get-caller-identity --query Account --output text) \
  --region us-east-1

# Create the data source
python create_snowflake_datasource.py --secret-name snowflake-credentials
```

### Issue: "Permission denied"

**Solution:**
Check your IAM permissions include:
- `quicksight:*`
- `secretsmanager:GetSecretValue`
- `sts:GetCallerIdentity`

### Issue: "Dataset already exists"

**Solution:**
The scripts automatically delete existing resources. If you want to keep them, use different IDs:
```bash
python generate_quicksight_schema.py --dataset-id movie-analytics-dataset-v2
```

### Issue: "SPICE ingestion failed"

**Solution:**
1. Check Snowflake credentials are correct
2. Verify network connectivity to Snowflake
3. Check QuickSight has permission to access Snowflake
4. Review ingestion errors in QuickSight console

## Advanced Usage

### Using in CI/CD Pipeline

```yaml
# Example GitHub Actions workflow
- name: Create QuickSight Dataset
  run: |
    python create_snowflake_datasource.py --secret-name ${{ secrets.SF_SECRET }}
    python generate_quicksight_schema.py --datasource-arn ${{ env.DATASOURCE_ARN }}
    python create_dataset_from_schema.py --schema quicksight_schema.json
```

### Programmatic Usage

```python
from create_snowflake_datasource import create_snowflake_datasource
from generate_quicksight_schema import SnowflakeDDLParser, QuickSightSchemaGenerator

# Create data source
ds_response = create_snowflake_datasource(
    datasource_id='my-datasource',
    datasource_name='My Data Source',
    secret_name='my-secret'
)

# Generate schema
parser = SnowflakeDDLParser('path/to/ddl.csv')
parsed = parser.parse_all()

generator = QuickSightSchemaGenerator(parsed)
schema = generator.generate_complete_schema(
    datasource_arn=ds_response['Arn'],
    database='MYDB',
    dataset_id='my-dataset',
    dataset_name='My Dataset'
)

# Create dataset
import boto3
qs = boto3.client('quicksight')
qs.create_data_set(AwsAccountId='123456789012', **schema)
```

### Customizing the Schema

Edit the generated `quicksight_schema.json` to:
- Add custom calculated fields
- Modify field folders
- Change data types
- Add row-level security

Then create the dataset:
```bash
python create_dataset_from_schema.py --schema quicksight_schema.json
```

## Next Steps

After creating your dataset:

1. **Create an Analysis**
   - Go to QuickSight > Analyses > New analysis
   - Select your dataset
   - Start building visualizations

2. **Create a Dashboard**
   - Publish your analysis as a dashboard
   - Share with other users

3. **Schedule SPICE Refresh**
   - Set up automatic SPICE refresh schedule
   - Keep your data up to date

4. **Add Row-Level Security**
   - Define RLS rules in the dataset
   - Control data access by user

## Files Reference

| File | Purpose |
|------|---------|
| `setup_secrets.sh` | Interactive secret creation |
| `create_snowflake_datasource.py` | Create QuickSight data source |
| `generate_quicksight_schema.py` | Parse DDL and generate schema |
| `create_dataset_from_schema.py` | Create QuickSight dataset |
| `validate_setup.py` | Validate prerequisites |
| `example_usage.py` | Complete Python example |
| `example_workflow.sh` | Complete bash example |

## Support

For detailed documentation, see:
- `QUICKSIGHT_SCHEMA_README.md` - Comprehensive documentation
- `QUICKSTART_SUMMARY.md` - Quick reference guide
- `example_usage.py` - Code examples

## License

This toolkit is provided as-is for use with AWS QuickSight and Snowflake.
