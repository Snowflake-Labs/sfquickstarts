# QuickSight Dataset from Snowflake DDL - Quick Start Summary

This toolkit provides a complete solution for creating QuickSight datasets from Snowflake Semantic View DDL definitions.

## 📁 Files Created

### Core Scripts
1. **create_snowflake_datasource.py** - Creates QuickSight Snowflake data source from AWS Secrets Manager
2. **generate_quicksight_schema.py** - Parses Snowflake DDL CSV and generates QuickSight schema
3. **create_dataset_from_schema.py** - Creates QuickSight dataset from generated schema

### Helper Scripts
4. **setup_secrets.sh** - Interactive script to create AWS Secrets Manager secret
5. **example_usage.py** - Complete Python workflow example
6. **example_workflow.sh** - Complete bash workflow example

### Documentation
7. **QUICKSIGHT_SCHEMA_README.md** - Comprehensive documentation
8. **QUICKSTART_SUMMARY.md** - This file

## 🚀 Quick Start (3 Steps)

### Step 1: Setup Snowflake Credentials in AWS Secrets Manager

```bash
# Interactive setup
./setup_secrets.sh

# Or use AWS CLI directly
aws secretsmanager create-secret \
  --name snowflake-credentials \
  --secret-string '{"account":"your-account","database":"MOVIES","warehouse":"WORKSHOPWH","user":"username","password":"password"}' \
  --region us-east-1
```

### Step 2: Create Snowflake Data Source in QuickSight

```bash
python create_snowflake_datasource.py \
  --datasource-id movies-snowflake-datasource \
  --datasource-name "Movies Snowflake Data Source" \
  --secret-name snowflake-credentials \
  --profile quick_suite_sa
```

**Output:** Data source ARN (save this for next step)

### Step 3: Generate Schema and Create Dataset

```bash
# Generate schema from Snowflake DDL
python generate_quicksight_schema.py \
  --csv-path /Users/wangzyn/snowflake-quicksight-workshop/quick_start/SF_DDL.csv \
  --datasource-arn "arn:aws:quicksight:us-east-1:ACCOUNT_ID:datasource/movies-snowflake-datasource" \
  --database MOVIES \
  --dataset-id movie-analytics-dataset \
  --output quicksight_schema.json

# Create dataset in QuickSight
python create_dataset_from_schema.py \
  --schema quicksight_schema.json \
  --profile quick_suite_sa \
  --share-with "ElevatedAccess/wangzyn-Isengard"
```

## 📊 What Gets Created

### From Snowflake DDL CSV
The parser extracts:
- **Tables** (3): MOVIES, USERS, RATINGS with their schemas
- **Relationships** (2): Join conditions between tables
- **Dimensions** (17): Attribute fields like MOVIE_TITLE, USER_EMAIL, etc.
- **Facts** (1): Measure fields like RATING_VALUE
- **Metrics** (7): Calculated fields like AVG_RATING, TOTAL_RATINGS, POPULARITY_SCORE

### QuickSight Dataset Schema
Generates:
- **PhysicalTableMap**: Maps to actual Snowflake tables
- **LogicalTableMap**: Defines joins and calculated fields
- **FieldFolders**: Organizes fields by category (Movies, Users, Ratings, Metrics)
- **Calculated Fields**: Converts Snowflake metrics to QuickSight expressions

## 🔧 Configuration Options

### create_snowflake_datasource.py
```bash
--datasource-id      # QuickSight data source ID
--datasource-name    # Display name
--secret-name        # AWS Secrets Manager secret name (required)
--profile            # AWS profile
--region             # AWS region (default: us-east-1)
--no-delete          # Don't delete existing data source
```

### generate_quicksight_schema.py
```bash
--csv-path           # Path to Snowflake DDL CSV
--datasource-arn     # QuickSight data source ARN (required)
--database           # Snowflake database name
--dataset-id         # QuickSight dataset ID
--dataset-name       # Display name
--output             # Output JSON file path
```

### create_dataset_from_schema.py
```bash
--schema             # Path to schema JSON file
--profile            # AWS profile
--region             # AWS region
--share-with         # QuickSight user (format: namespace/username)
```

## 📝 AWS Secrets Manager Format

Your secret must contain these fields:

```json
{
  "account": "your-snowflake-account",
  "database": "MOVIES",
  "warehouse": "WORKSHOPWH",
  "user": "your-username",
  "password": "your-password"
}
```

## 🔐 Required AWS Permissions

### QuickSight
- `quicksight:CreateDataSource`
- `quicksight:DescribeDataSource`
- `quicksight:DeleteDataSource`
- `quicksight:CreateDataSet`
- `quicksight:DescribeDataSet`
- `quicksight:DeleteDataSet`
- `quicksight:UpdateDataSetPermissions`
- `quicksight:CreateIngestion`

### Secrets Manager
- `secretsmanager:GetSecretValue`
- `secretsmanager:DescribeSecret`

### STS
- `sts:GetCallerIdentity`

## 🎯 Use Cases

1. **Automated Dataset Creation**: Generate QuickSight datasets from Snowflake semantic views
2. **CI/CD Integration**: Automate dataset deployment in your pipeline
3. **Multi-Environment Setup**: Easily replicate datasets across dev/test/prod
4. **Schema Migration**: Convert Snowflake DDL to QuickSight format
5. **Bulk Dataset Creation**: Process multiple DDL files to create multiple datasets

## 🔄 Workflow Diagram

```
Snowflake DDL CSV
       ↓
[generate_quicksight_schema.py]
       ↓
QuickSight Schema JSON
       ↓
[create_dataset_from_schema.py]
       ↓
QuickSight Dataset + SPICE Ingestion
```

## 💡 Tips

1. **Test with Sample Data**: Start with a small DDL to verify the workflow
2. **Version Control**: Store generated schemas in git for tracking changes
3. **Automate**: Use these scripts in your CI/CD pipeline
4. **Monitor Ingestion**: Check SPICE ingestion status in QuickSight console
5. **Field Folders**: Customize field organization by editing the schema JSON

## 🐛 Common Issues

### "Data source not found"
- Make sure you created the data source first using `create_snowflake_datasource.py`
- Verify the data source ID matches what you're using

### "Secret not found"
- Check the secret exists: `aws secretsmanager describe-secret --secret-id snowflake-credentials`
- Verify you're using the correct region

### "Permission denied"
- Ensure your AWS credentials have the required permissions listed above
- Check your QuickSight subscription is active

### "Dataset already exists"
- The scripts auto-delete existing resources by default
- Use different IDs if you want to keep old resources

## 📚 Additional Resources

- [QuickSight API Documentation](https://docs.aws.amazon.com/quicksight/latest/APIReference/)
- [Snowflake Semantic Views](https://docs.snowflake.com/en/user-guide/semantic-views)
- [AWS Secrets Manager](https://docs.aws.amazon.com/secretsmanager/)

## 🤝 Support

For issues or questions:
1. Check the QUICKSIGHT_SCHEMA_README.md for detailed documentation
2. Review the example_usage.py for code examples
3. Verify your AWS permissions and Snowflake credentials
