# QuickSight Dataset Schema Generator

This tool reads Snowflake DDL from a CSV file and generates a QuickSight dataset schema that can be used with the AWS QuickSight `create_data_set` API.

## Overview

The tool consists of two main scripts:

1. **generate_quicksight_schema.py** - Parses Snowflake DDL and generates QuickSight schema
2. **create_dataset_from_schema.py** - Creates QuickSight dataset using the generated schema

## How It Works

The parser reads the Snowflake DDL CSV and extracts:

- **Tables**: Snowflake tables with their schemas and primary keys
- **Relationships**: Join conditions between tables
- **Facts**: Fact fields (measures)
- **Dimensions**: Dimension fields (attributes)
- **Metrics**: Calculated fields with expressions

These are then converted into QuickSight dataset schema format with:

- **PhysicalTableMap**: Maps to actual Snowflake tables
- **LogicalTableMap**: Defines joins and calculated fields
- **FieldFolders**: Organizes fields by category

## Prerequisites

```bash
pip install boto3
```

AWS credentials configured with QuickSight and Secrets Manager permissions.

### Validate Your Setup

Before starting, you can validate that all prerequisites are met:

```bash
python validate_setup.py --profile quick_suite_sa
```

This will check:
- Python packages are installed
- AWS credentials are configured
- CSV file exists and is readable
- AWS Secrets Manager secret exists (optional)
- QuickSight data source exists (optional)

### AWS Secrets Manager Setup

For the data source creation step, you need to store Snowflake credentials in AWS Secrets Manager with the following format:

```json
{
  "account": "your-snowflake-account",
  "database": "MOVIES",
  "warehouse": "WORKSHOPWH",
  "user": "your-username",
  "password": "your-password"
}
```

**Option 1: Use the helper script (interactive)**
```bash
./setup_secrets.sh
```

**Option 2: Create the secret using AWS CLI**
```bash
aws secretsmanager create-secret \
  --name snowflake-credentials \
  --secret-string '{"account":"your-account","database":"MOVIES","warehouse":"WORKSHOPWH","user":"username","password":"password"}' \
  --region us-east-1
```

**Option 3: Use AWS Console**
1. Go to AWS Secrets Manager
2. Click "Store a new secret"
3. Select "Other type of secret"
4. Add the key-value pairs as shown above
5. Name it "snowflake-credentials"

## Usage

### Step 0 (Optional): Create Snowflake Data Source

If you don't have a QuickSight data source yet, create one using credentials from AWS Secrets Manager:

```bash
python create_snowflake_datasource.py \
  --datasource-id movies-snowflake-datasource \
  --datasource-name "Movies Snowflake Data Source" \
  --secret-name snowflake-credentials \
  --profile quick_suite_sa \
  --region us-east-1
```

**Parameters:**
- `--datasource-id`: QuickSight data source ID (default: movies-snowflake-datasource)
- `--datasource-name`: Display name for the data source (default: Movies Snowflake Data Source)
- `--secret-name`: AWS Secrets Manager secret name (required)
- `--profile`: AWS profile name (optional)
- `--region`: AWS region (default: us-east-1)
- `--no-delete`: Don't delete existing data source with same ID

This will output the data source ARN that you'll use in the next step.

### Step 1: Generate Schema

Generate the QuickSight dataset schema from Snowflake DDL:

```bash
python generate_quicksight_schema.py \
  --csv-path /Users/wangzyn/snowflake-quicksight-workshop/quick_start/SF_DDL.csv \
  --datasource-arn "arn:aws:quicksight:us-east-1:123456789012:datasource/your-datasource-id" \
  --database MOVIES \
  --dataset-id semantic-view-dataset \
  --dataset-name "Semantic View Dataset" \
  --output quicksight_schema.json
```

**Parameters:**
- `--csv-path`: Path to Snowflake DDL CSV file (default: /Users/wangzyn/snowflake-quicksight-workshop/quick_start/SF_DDL.csv)
- `--datasource-arn`: QuickSight data source ARN (required)
- `--database`: Snowflake database name (default: MOVIES)
- `--dataset-id`: QuickSight dataset ID (default: semantic-view-dataset)
- `--dataset-name`: QuickSight dataset name (default: Semantic View Dataset)
- `--output`: Output JSON file path (default: quicksight_schema.json)

### Step 2: Create Dataset

Use the generated schema to create a QuickSight dataset:

```bash
python create_dataset_from_schema.py \
  --schema quicksight_schema.json \
  --profile quick_suite_sa \
  --region us-east-1 \
  --share-with "ElevatedAccess/your-username"
```

**Parameters:**
- `--schema`: Path to schema JSON file (default: quicksight_schema.json)
- `--profile`: AWS profile name (optional)
- `--region`: AWS region (default: us-east-1)
- `--share-with`: QuickSight user to share with (format: namespace/username)

## Example: Complete Workflow

```bash
# 0. (Optional) Create QuickSight data source from Secrets Manager
python create_snowflake_datasource.py \
  --datasource-id movies-snowflake-datasource \
  --datasource-name "Movies Snowflake Data Source" \
  --secret-name snowflake-credentials \
  --profile quick_suite_sa

# 1. Generate schema from Snowflake DDL (use the ARN from step 0)
python generate_quicksight_schema.py \
  --datasource-arn "arn:aws:quicksight:us-east-1:123456789012:datasource/movies-snowflake-datasource" \
  --database MOVIES \
  --dataset-id movie-analytics-dataset \
  --dataset-name "Movie Analytics Dataset"

# 2. Create dataset in QuickSight
python create_dataset_from_schema.py \
  --schema quicksight_schema.json \
  --profile quick_suite_sa \
  --share-with "ElevatedAccess/wangzyn-Isengard"
```

## Using the Schema Programmatically

You can also use the generated schema in your own Python scripts:

```python
import boto3
import json
from create_snowflake_datasource import create_snowflake_datasource

# Step 0: Create data source from Secrets Manager (optional)
datasource_response = create_snowflake_datasource(
    datasource_id='movies-snowflake-datasource',
    datasource_name='Movies Snowflake Data Source',
    secret_name='snowflake-credentials',
    aws_profile='quick_suite_sa',
    region='us-east-1'
)

# Step 1: Load schema
with open('quicksight_schema.json', 'r') as f:
    schema = json.load(f)

# Step 2: Initialize QuickSight client
quicksight = boto3.client('quicksight', region_name='us-east-1')
sts = boto3.client('sts')
account_id = sts.get_caller_identity()['Account']

# Step 3: Create dataset
response = quicksight.create_data_set(
    AwsAccountId=account_id,
    **schema
)

print(f"Dataset created: {response['DataSetId']}")

# Step 4: Create SPICE ingestion
import time
ingestion_id = f"ingestion-{int(time.time())}"
ingestion_response = quicksight.create_ingestion(
    AwsAccountId=account_id,
    DataSetId=schema['DataSetId'],
    IngestionId=ingestion_id,
    IngestionType='FULL_REFRESH'
)

print(f"Ingestion started: {ingestion_response['IngestionId']}")
```

## Schema Structure

The generated schema includes:

### PhysicalTableMap
Maps to actual Snowflake tables with their columns:

```json
{
  "movies": {
    "RelationalTable": {
      "DataSourceArn": "arn:aws:quicksight:...",
      "Catalog": "MOVIES",
      "Schema": "PUBLIC",
      "Name": "MOVIES_CURATED",
      "InputColumns": [
        {"Name": "MOVIEID", "Type": "INTEGER"},
        {"Name": "TITLE", "Type": "STRING"}
      ]
    }
  }
}
```

### LogicalTableMap
Defines joins and calculated fields:

```json
{
  "combined": {
    "Alias": "Combined Data",
    "Source": {"PhysicalTableId": "ratings"},
    "DataTransforms": [
      {
        "CreateColumnsOperation": {
          "Columns": [
            {
              "ColumnName": "AVG_RATING",
              "ColumnId": "avg_rating",
              "Expression": "avg({RATING_VALUE})"
            }
          ]
        }
      }
    ]
  }
}
```

### FieldFolders
Organizes fields by category:

```json
{
  "MOVIES Fields": {
    "description": "Fields from MOVIES_CURATED table",
    "columns": ["MOVIEID", "TITLE", "RELEASE"]
  },
  "Metrics": {
    "description": "Calculated metrics and aggregations",
    "columns": ["DISTINCT_MOVIES", "AVG_RATING"]
  }
}
```

## Troubleshooting

### Secret Not Found
Make sure the secret exists in AWS Secrets Manager:
```bash
aws secretsmanager describe-secret --secret-id snowflake-credentials --region us-east-1
```

### Invalid Secret Format
Ensure your secret contains all required fields:
- `account`: Snowflake account identifier
- `database`: Database name
- `warehouse`: Warehouse name
- `user`: Username
- `password`: Password

### Data Source ARN Not Found
If you created the data source using `create_snowflake_datasource.py`, the ARN is displayed in the output. You can also get it using:
```bash
aws quicksight describe-data-source \
  --aws-account-id YOUR_ACCOUNT_ID \
  --data-source-id movies-snowflake-datasource \
  --region us-east-1
```

### Permission Denied
Ensure your AWS credentials have the following permissions:
- QuickSight:
  - `quicksight:CreateDataSource`
  - `quicksight:CreateDataSet`
  - `quicksight:DescribeDataSet`
  - `quicksight:UpdateDataSetPermissions`
  - `quicksight:CreateIngestion`
- Secrets Manager:
  - `secretsmanager:GetSecretValue`

### Dataset Already Exists
The scripts will automatically delete existing datasets/data sources with the same ID. If you want to keep the old resources, use different IDs with `--dataset-id` or `--datasource-id`.

## Notes

- The tool supports SPICE import mode by default
- Calculated fields are generated for metrics with expressions
- Field folders help organize fields in the QuickSight UI
- Relationships are used to define join conditions between tables
