#!/bin/bash
# Example workflow for generating QuickSight dataset from Snowflake DDL

# Step 0 (Optional): Create Snowflake data source from AWS Secrets Manager
echo "Step 0 (Optional): Creating Snowflake data source..."
echo "Uncomment the following lines if you need to create the data source first:"
echo ""
# python create_snowflake_datasource.py \
#   --datasource-id movies-snowflake-datasource \
#   --datasource-name "Movies Snowflake Data Source" \
#   --secret-name snowflake-credentials \
#   --profile quick_suite_sa \
#   --region us-east-1
echo ""

# Step 1: Generate schema from Snowflake DDL CSV
echo "Step 1: Generating QuickSight schema from Snowflake DDL..."
python generate_quicksight_schema.py \
  --csv-path /Users/wangzyn/snowflake-quicksight-workshop/quick_start/SF_DDL.csv \
  --datasource-arn "arn:aws:quicksight:us-east-1:YOUR_ACCOUNT_ID:datasource/movies-snowflake-datasource" \
  --database MOVIES \
  --dataset-id movie-analytics-dataset \
  --dataset-name "Movie Analytics Dataset" \
  --output quicksight_schema.json

echo ""
echo "Step 2: Creating QuickSight dataset..."
# Step 2: Create dataset in QuickSight
python create_dataset_from_schema.py \
  --schema quicksight_schema.json \
  --profile quick_suite_sa \
  --region us-east-1 \
  --share-with "ElevatedAccess/wangzyn-Isengard"

echo ""
echo "✓ Workflow complete!"
echo "Your QuickSight dataset is ready to use."
