# QuickSight Dataset Generator - Solution Package

## Overview

This package provides a complete solution for converting Snowflake Semantic View DDL into QuickSight datasets with automatic schema generation, data ingestion, and user sharing.

## Package Contents

### Core Scripts
- **`generate_quicksight_schema_v2.py`** - Main schema generator (converts Snowflake DDL to QuickSight schema)
- **`test_complete_schema.py`** - Dataset creator with sharing functionality
- **`create_secret.py`** - AWS Secrets Manager secret creation
- **`create_snowflake_datasource.py`** - QuickSight data source creation
- **`setup_secrets.sh`** - Interactive secret setup script

### Documentation
- **`USAGE_GUIDE.md`** - Complete end-to-end usage guide (START HERE)
- **`QUICK_REFERENCE.md`** - Quick command reference
- **`FINAL_SUMMARY.md`** - Project overview and features
- **`COMPLETE_SCHEMA_SUMMARY.md`** - Technical implementation details

### Sample Files
- **`SF_DDL.csv`** - Sample Snowflake DDL input
- **`quicksight_schema_complete.json`** - Sample generated schema
- **`movie-analytics-dataset.json`** - Sample dataset output

### Helper Scripts
- **`create_dataset_from_schema.py`** - Alternative dataset creator
- **`validate_setup.py`** - Setup validation script
- **`example_usage.py`** - Usage examples
- **`example_workflow.sh`** - Workflow example script

## Quick Start

### 1. Install Dependencies
```bash
pip install boto3
```

### 2. Configure AWS Credentials
```bash
aws configure --profile default
```

### 3. Follow the Complete Workflow

See **`USAGE_GUIDE.md`** for detailed instructions.

**Quick workflow:**
```bash
# Step 1: Create secret
python create_secret.py \
  --secret-name snowflake-credentials \
  --account YOUR_ACCOUNT \
  --user YOUR_USER \
  --password YOUR_PASSWORD

# Step 2: Create data source
python create_snowflake_datasource.py \
  --secret-name snowflake-credentials

# Step 3: Generate schema
python generate_quicksight_schema_v2.py \
  --csv-path SF_DDL.csv \
  --datasource-arn "arn:aws:quicksight:REGION:ACCOUNT:datasource/ID"

# Step 4: Create and share dataset
python test_complete_schema.py \
  --share-with "Administrator/username"
```

## Features

### Schema Generation
✅ Converts Snowflake DDL to QuickSight schema  
✅ Supports multiple tables with joins  
✅ Automatic column renames and type casts  
✅ Calculated fields from DDL metrics  
✅ Column descriptions from DDL comments  

### Dataset Creation
✅ Automatic dataset creation  
✅ SPICE ingestion initiation  
✅ User sharing with full permissions  
✅ Flexible username format support  

### Generated Dataset Includes
- 3 physical tables (MOVIES, USERS, RATINGS)
- Table joins (RATINGS → MOVIES → USERS)
- 23 output columns with proper naming
- 8 calculated fields including 7 metrics
- Column descriptions and metadata

## Requirements

### Software
- Python 3.x
- boto3 library
- AWS CLI (optional, for verification)

### AWS Permissions
- Secrets Manager: Create/Update secrets
- QuickSight: Create data sources and datasets
- IAM: Get caller identity

### Snowflake Access
- Valid Snowflake account
- Database and warehouse access
- User credentials

## Documentation

### Primary Documentation
1. **USAGE_GUIDE.md** - Complete step-by-step guide (recommended starting point)
2. **QUICK_REFERENCE.md** - Quick command reference
3. **FINAL_SUMMARY.md** - Project overview and results

### Technical Documentation
4. **COMPLETE_SCHEMA_SUMMARY.md** - Implementation details
5. **QUICKSIGHT_SCHEMA_README.md** - Schema structure details
6. **README_COMPLETE_WORKFLOW.md** - Workflow documentation

## Support

### Common Issues

**Secret Creation Fails**
- Check IAM permissions for Secrets Manager
- Verify AWS credentials are configured

**Data Source Creation Fails**
- Verify Snowflake credentials in secret
- Check Snowflake account identifier format
- Ensure warehouse is running

**Schema Generation Fails**
- Verify DDL CSV file path and format
- Check data source ARN is correct

**Dataset Creation Fails**
- Verify data source exists
- Check column references in calculated fields
- Review ingestion logs for errors

### Getting Help

1. Check the troubleshooting section in USAGE_GUIDE.md
2. Review error messages and logs
3. Verify all prerequisites are met
4. Check AWS CloudWatch logs for detailed errors

## Dataset Structure

### Physical Tables
- **RATINGS_CURATED** - Fact table with user ratings
- **MOVIES_CURATED** - Movie dimension table
- **USERS_CURATED** - User dimension table

### Calculated Fields
1. USER_FULL_NAME - Concatenated user name
2. MOVIES_DISTINCT_MOVIES - Count of distinct movies
3. USERS_DISTINCT_USERS - Count of distinct users
4. RATINGS_TOTAL_RATINGS - Total rating count
5. RATINGS_AVG_RATING - Average rating value
6. RATINGS_DISTINCT_USERS - Distinct users who rated
7. RATINGS_DISTINCT_MOVIES - Distinct movies rated
8. RATINGS_POPULARITY_SCORE - Popularity metric

### Permissions Granted When Sharing
When sharing a dataset, users receive full control with 10 permissions:
- UpdateDataSetPermissions
- DescribeDataSet
- DescribeDataSetPermissions
- PassDataSet
- DescribeIngestion
- ListIngestions
- UpdateDataSet
- DeleteDataSet
- CreateIngestion
- CancelIngestion

## Version Information

- **Version**: 2.0
- **Last Updated**: January 2026
- **Python**: 3.x
- **AWS SDK**: boto3

## License

This solution package is provided as-is for use with AWS QuickSight and Snowflake integration.

## Next Steps

1. Read **USAGE_GUIDE.md** for complete instructions
2. Prepare your Snowflake credentials
3. Export your Snowflake DDL to CSV format
4. Follow the 6-step workflow to create your dataset
5. Share the dataset with your team
6. Build analyses and dashboards in QuickSight

## Contact

For questions or issues, refer to:
- AWS QuickSight Documentation: https://docs.aws.amazon.com/quicksight/
- Snowflake Documentation: https://docs.snowflake.com/
- AWS Support: https://aws.amazon.com/support/

---

**Ready to get started?** Open **USAGE_GUIDE.md** for the complete walkthrough!
