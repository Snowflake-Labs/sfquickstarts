# QuickSight Dataset Generator - Complete End-to-End Guide

## Overview
This guide walks you through the complete process of creating QuickSight datasets from Snowflake DDL, from setting up credentials to sharing datasets with users.

## Complete Workflow

```
1. Create AWS Secret (Snowflake credentials)
   ↓
2. Create QuickSight Data Source (using secret)
   ↓
3. Generate QuickSight Schema (from Snowflake DDL)
   ↓
4. Create Dataset (from generated schema)
   ↓
5. Start SPICE Ingestion (load data)
   ↓
6. Share Dataset (with users)
```

---

## Prerequisites

### Required Software
- Python 3.x with boto3 installed
- AWS CLI configured
- Access to Snowflake account

### Required Permissions
- AWS Secrets Manager: Create/Update secrets
- QuickSight: Create data sources and datasets
- IAM: Get caller identity

### Required Information
- Snowflake account identifier
- Snowflake database name
- Snowflake warehouse name
- Snowflake username and password
- QuickSight user to share with

---

## Step 1: Create AWS Secret for Snowflake Credentials

Store your Snowflake credentials securely in AWS Secrets Manager.

### Option A: Using Python Script (Recommended)

```bash
python create_secret.py \
  --secret-name snowflake-credentials \
  --account YOUR_SNOWFLAKE_ACCOUNT \
  --database MOVIES \
  --warehouse WORKSHOPWH \
  --user YOUR_USERNAME \
  --password YOUR_PASSWORD \
  --region us-east-1 \
  --profile default
```

### Option B: Using Interactive Shell Script

```bash
./setup_secrets.sh
```

The script will prompt you for:
- Snowflake account identifier
- Database name (default: MOVIES)
- Warehouse name (default: WORKSHOPWH)
- Username
- Password
- AWS region (default: us-east-1)
- Secret name (default: snowflake-credentials)

### Verify Secret Creation

```bash
aws secretsmanager get-secret-value \
  --secret-id snowflake-credentials \
  --region us-east-1 \
  --profile default
```

### Expected Secret Format

```json
{
  "account": "your-account.us-east-1",
  "database": "MOVIES",
  "warehouse": "WORKSHOPWH",
  "user": "your_username",
  "password": "your_password"
}
```

---

## Step 2: Create QuickSight Data Source

Create a QuickSight data source that connects to Snowflake using the credentials from Secrets Manager.

### Command

```bash
python create_snowflake_datasource.py \
  --datasource-id movies-snowflake-datasource \
  --datasource-name "Movies Snowflake Data Source" \
  --secret-name snowflake-credentials \
  --region us-east-1 \
  --profile default
```

### Parameters

| Parameter | Required | Default | Description |
|-----------|----------|---------|-------------|
| --datasource-id | No | movies-snowflake-datasource | QuickSight data source ID |
| --datasource-name | No | Movies Snowflake Data Source | Display name |
| --secret-name | Yes | - | AWS Secrets Manager secret name |
| --region | No | us-east-1 | AWS region |
| --profile | No | default | AWS profile name |
| --no-delete | No | False | Keep existing data source |

### Expected Output

```
Using AWS Account ID: 889399602426
Region: us-east-1

Retrieving Snowflake credentials from secret: snowflake-credentials
  ✓ Snowflake Account: your-account.us-east-1
  ✓ Database: MOVIES
  ✓ Warehouse: WORKSHOPWH
  ✓ User: your_username

Creating Snowflake data source: Movies Snowflake Data Source

============================================================
✓ Data Source Created Successfully!
============================================================

Data Source Details:
  ID: movies-snowflake-datasource
  ARN: arn:aws:quicksight:us-east-1:889399602426:datasource/movies-snowflake-datasource
  Status: 200
  Creation Status: CREATION_SUCCESSFUL
```

### Verify Data Source

```bash
aws quicksight describe-data-source \
  --aws-account-id YOUR_ACCOUNT_ID \
  --data-source-id movies-snowflake-datasource \
  --region us-east-1 \
  --profile default
```

---

## Step 3: Generate QuickSight Schema from Snowflake DDL

Convert your Snowflake Semantic View DDL (exported to CSV) into a complete QuickSight dataset schema.

### Command

```bash
python generate_quicksight_schema_v2.py \
  --csv-path SF_DDL.csv \
  --datasource-arn "arn:aws:quicksight:us-east-1:ACCOUNT_ID:datasource/movies-snowflake-datasource" \
  --database MOVIES \
  --dataset-id movie-analytics-dataset-v2 \
  --dataset-name "Movie Analytics Dataset-v2" \
  --output quicksight_schema_complete.json
```

### Parameters

| Parameter | Required | Default | Description |
|-----------|----------|---------|-------------|
| --csv-path | No | ../SF_DDL.csv | Path to Snowflake DDL CSV file |
| --datasource-arn | Yes | - | QuickSight data source ARN |
| --database | No | MOVIES | Snowflake database name |
| --dataset-id | No | movie-analytics-dataset | QuickSight dataset ID |
| --dataset-name | No | Movie Analytics Dataset | Dataset display name |
| --output | No | quicksight_schema_complete.json | Output file path |

### Expected Output

```
Parsing Snowflake DDL from: SF_DDL.csv
Found 3 tables
Found 2 relationships
Found 17 dimensions
Found 1 facts
Found 7 metrics

Generating complete QuickSight dataset schema...

Complete schema saved to: quicksight_schema_complete.json

This schema includes:
  ✓ All 3 physical tables (MOVIES, USERS, RATINGS)
  ✓ Logical tables with joins
  ✓ Column renames based on DDL aliases
  ✓ Type casts (IDs to STRING)
  ✓ Calculated fields (USER_FULL_NAME, 7 metrics)
  ✓ Column descriptions from DDL comments
```

### What Gets Generated

The schema includes:

**Physical Tables (3)**
- RATINGS_CURATED (fact table)
- MOVIES_CURATED (dimension table)
- USERS_CURATED (dimension table)

**Transformations**
- Column renames (e.g., TITLE → MOVIE_TITLE)
- Type casts (IDs to STRING)
- Table joins (RATINGS → MOVIES → USERS)
- USER_ prefix on all user columns

**Calculated Fields (8)**
1. USER_FULL_NAME
2. MOVIES_DISTINCT_MOVIES
3. USERS_DISTINCT_USERS
4. RATINGS_TOTAL_RATINGS
5. RATINGS_AVG_RATING
6. RATINGS_DISTINCT_USERS
7. RATINGS_DISTINCT_MOVIES
8. RATINGS_POPULARITY_SCORE

---

## Step 4: Create Dataset and Start Ingestion

Create the QuickSight dataset from the generated schema and start loading data into SPICE.

### Option A: Create Dataset Without Sharing

```bash
python test_complete_schema.py \
  --region us-east-1
```

Or with a specific profile:

```bash
python test_complete_schema.py \
  --profile default \
  --region us-east-1
```

### Option B: Create Dataset and Share with User (Recommended)

```bash
python test_complete_schema.py \
  --region us-east-1 \
  --share-with "Administrator/wangzyn-Isengard"
```

Or with a specific profile:

```bash
python test_complete_schema.py \
  --profile default \
  --region us-east-1 \
  --share-with "Administrator/wangzyn-Isengard"
```

### Parameters

| Parameter | Required | Default | Description |
|-----------|----------|---------|-------------|
| --profile | No | - | AWS profile name (uses default credentials if not specified) |
| --region | No | us-east-1 | AWS region |
| --share-with | No | - | Username to share with (format: namespace/username) |

### Expected Output

```
Account: 889399602426
Dataset ID: movie-analytics-dataset-v2
No existing dataset
✓ Dataset created: movie-analytics-dataset-v2
✓ Status: 201
✓ Ingestion started: ingestion-1769029330
✓ Dataset shared with: Administrator/wangzyn-Isengard
  User ARN: arn:aws:quicksight:us-east-1:889399602426:user/default/Administrator/wangzyn-Isengard
```

---

## Step 5: Monitor SPICE Ingestion

Check the status of data loading into SPICE.

### Check Ingestion Status

```bash
aws quicksight describe-ingestion \
  --aws-account-id YOUR_ACCOUNT_ID \
  --data-set-id movie-analytics-dataset-v2 \
  --ingestion-id INGESTION_ID \
  --region us-east-1 \
  --profile default
```

### Expected Statuses

- `INITIALIZED` - Ingestion is starting
- `QUEUED` - Waiting to start
- `RUNNING` - Currently loading data
- `COMPLETED` - Successfully loaded
- `FAILED` - Error occurred

### Successful Ingestion Output

```json
{
  "IngestionStatus": "COMPLETED",
  "RowInfo": {
    "RowsIngested": 378436,
    "RowsDropped": 0,
    "TotalRowsInDataset": 378436
  },
  "ErrorInfo": {}
}
```

---

## Step 6: Verify Dataset and Permissions

### Check Dataset Details

```bash
aws quicksight describe-data-set \
  --aws-account-id YOUR_ACCOUNT_ID \
  --data-set-id movie-analytics-dataset-v2 \
  --region us-east-1 \
  --profile default
```

### Check Dataset Permissions

```bash
aws quicksight describe-data-set-permissions \
  --aws-account-id YOUR_ACCOUNT_ID \
  --data-set-id movie-analytics-dataset-v2 \
  --region us-east-1 \
  --profile default
```

### Verify Output Columns

```bash
aws quicksight describe-data-set \
  --aws-account-id YOUR_ACCOUNT_ID \
  --data-set-id movie-analytics-dataset-v2 \
  --region us-east-1 \
  --profile default \
  --query 'DataSet.OutputColumns[].Name'
```

Expected: 23 columns including all user columns with USER_ prefix and 7 metric calculated fields.

---

## Dataset Permissions Granted

When sharing a dataset with `--share-with`, the following **full permissions** are granted:

| Permission | Description |
|------------|-------------|
| UpdateDataSetPermissions | Manage who can access the dataset |
| DescribeDataSet | View dataset details and schema |
| DescribeDataSetPermissions | View current permissions |
| PassDataSet | Use dataset in analyses and dashboards |
| DescribeIngestion | View ingestion status and details |
| ListIngestions | List all data refresh operations |
| UpdateDataSet | Modify dataset configuration |
| DeleteDataSet | Delete the dataset |
| CreateIngestion | Start new data refresh |
| CancelIngestion | Cancel running data refresh |

**Total: 10 permissions** - Full control over the dataset

These permissions give the user complete control over the dataset including the ability to modify, delete, and manage permissions.

---

## Complete End-to-End Example

Here's a complete workflow from start to finish:

```bash
# Step 1: Create secret for Snowflake credentials
python create_secret.py \
  --secret-name snowflake-credentials \
  --account myaccount.us-east-1 \
  --database MOVIES \
  --warehouse WORKSHOPWH \
  --user myuser \
  --password mypassword \
  --region us-east-1 \
  --profile default

# Step 2: Create QuickSight data source
python create_snowflake_datasource.py \
  --datasource-id movies-snowflake-datasource \
  --datasource-name "Movies Snowflake Data Source" \
  --secret-name snowflake-credentials \
  --region us-east-1 \
  --profile default

# Step 3: Generate QuickSight schema from Snowflake DDL
python generate_quicksight_schema_v2.py \
  --csv-path SF_DDL.csv \
  --datasource-arn "arn:aws:quicksight:us-east-1:889399602426:datasource/movies-snowflake-datasource" \
  --database MOVIES \
  --dataset-id movie-analytics-dataset-v2 \
  --dataset-name "Movie Analytics Dataset-v2" \
  --output quicksight_schema_complete.json

# Step 4: Create dataset and share with user
python test_complete_schema.py \
  --region us-east-1 \
  --share-with "Administrator/wangzyn-Isengard"

# Step 5: Wait for ingestion to complete (optional)
sleep 30

# Step 6: Verify dataset
aws quicksight describe-data-set \
  --aws-account-id 889399602426 \
  --data-set-id movie-analytics-dataset-v2 \
  --region us-east-1 \
  --profile default \
  --query 'DataSet.[Name,ImportMode,ConsumedSpiceCapacityInBytes]'
```

---

## Finding QuickSight Users to Share With

### List All Namespaces

```bash
aws quicksight list-namespaces \
  --aws-account-id YOUR_ACCOUNT_ID \
  --region us-east-1 \
  --profile default
```

### List Users in Default Namespace

```bash
aws quicksight list-users \
  --aws-account-id YOUR_ACCOUNT_ID \
  --namespace default \
  --region us-east-1 \
  --profile default \
  --query 'UserList[].UserName'
```

### Username Formats

| Format | Example | Use Case |
|--------|---------|----------|
| Full with namespace | `Administrator/wangzyn-Isengard` | Internal users with namespace prefix |
| Simple | `reader1` | Simple QuickSight users |
| Federated | `quicksight-fed-us-users/email@domain.com` | Federated identity users |

---

## Troubleshooting

### Secret Creation Issues

**Error: Access Denied**
- Check IAM permissions for Secrets Manager
- Ensure you have `secretsmanager:CreateSecret` and `secretsmanager:UpdateSecret` permissions

**Error: Secret already exists**
- Use `--no-delete` flag or delete the existing secret first
- Or update the existing secret using the same command

### Data Source Creation Issues

**Error: Invalid credentials**
- Verify Snowflake credentials in the secret
- Test Snowflake connection manually
- Check Snowflake account identifier format

**Error: Warehouse not found**
- Verify warehouse name in Snowflake
- Ensure warehouse is running
- Check user has access to the warehouse

### Schema Generation Issues

**Error: CSV file not found**
- Check the path to SF_DDL.csv
- Ensure the file exists and is readable

**Error: No tables found**
- Verify the DDL CSV format
- Check that the DDL contains table definitions

### Dataset Creation Issues

**Error: Data source not found**
- Verify the data source ARN is correct
- Check that the data source was created successfully
- Ensure you're using the correct AWS account and region

**Error: Field does not exist**
- This means a calculated field references a column not in ProjectedColumns
- Check the generated schema for column names
- Verify all referenced columns exist after transformations

### Ingestion Issues

**Status: FAILED**
- Check Snowflake connection credentials
- Verify data source permissions
- Review ingestion error details using `describe-ingestion`
- Check Snowflake query history for errors

**Status: QUEUED for long time**
- Check SPICE capacity limits
- Verify no other ingestions are running
- Check QuickSight service status

### Sharing Issues

**Error: Namespace not found**
- Use `default` namespace for most users
- Check available namespaces with `list-namespaces`

**Error: User not found**
- Verify username with `list-users`
- Check the username format matches exactly
- Ensure user exists in the correct namespace

---

## Next Steps After Dataset Creation

### 1. Build Analyses
Use QuickSight Analysis to create visualizations:
- Create charts and graphs
- Add filters and parameters
- Build interactive dashboards

### 2. Create Dashboards
Publish analyses as dashboards:
- Share with broader audience
- Set up email reports
- Configure refresh schedules

### 3. Schedule Data Refreshes
Set up automatic SPICE refresh:
```bash
aws quicksight create-ingestion \
  --aws-account-id YOUR_ACCOUNT_ID \
  --data-set-id movie-analytics-dataset-v2 \
  --ingestion-id "scheduled-$(date +%s)" \
  --ingestion-type FULL_REFRESH
```

### 4. Monitor Usage
Track dataset usage and performance:
- Review SPICE capacity consumption
- Monitor query performance
- Check user access patterns

---

## Additional Resources

### AWS Documentation
- [QuickSight User Guide](https://docs.aws.amazon.com/quicksight/)
- [Secrets Manager User Guide](https://docs.aws.amazon.com/secretsmanager/)
- [Boto3 QuickSight Reference](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/quicksight.html)

### Snowflake Documentation
- [Snowflake Semantic Views](https://docs.snowflake.com/en/user-guide/semantic-views)
- [Snowflake DDL Reference](https://docs.snowflake.com/en/sql-reference/ddl-database)

### Script Files
- `create_secret.py` - Create AWS Secrets Manager secret
- `create_snowflake_datasource.py` - Create QuickSight data source
- `generate_quicksight_schema_v2.py` - Generate dataset schema
- `test_complete_schema.py` - Create dataset and share
- `setup_secrets.sh` - Interactive secret creation

---

## Quick Reference Commands

```bash
# Create secret
python create_secret.py --secret-name NAME --account ACCOUNT --user USER --password PASS

# Create data source
python create_snowflake_datasource.py --secret-name NAME

# Generate schema
python generate_quicksight_schema_v2.py --csv-path DDL.csv --datasource-arn ARN

# Create and share dataset
python test_complete_schema.py --share-with "Administrator/username"

# Check ingestion
aws quicksight describe-ingestion --aws-account-id ID --data-set-id DATASET --ingestion-id ING

# List users
aws quicksight list-users --aws-account-id ID --namespace default
```
