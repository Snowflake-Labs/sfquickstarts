#!/usr/bin/env python3
"""
Example: Complete workflow for creating QuickSight dataset from Snowflake DDL

This example demonstrates:
0. (Optional) Creating Snowflake data source from AWS Secrets Manager
1. Parsing Snowflake DDL from CSV
2. Generating QuickSight dataset schema
3. Creating the dataset in QuickSight
4. Starting SPICE ingestion
"""

import boto3
import json
from generate_quicksight_schema import SnowflakeDDLParser, QuickSightSchemaGenerator
from create_snowflake_datasource import create_snowflake_datasource


def main():
    # Configuration
    CSV_PATH = '/Users/wangzyn/snowflake-quicksight-workshop/quick_start/SF_DDL.csv'
    AWS_PROFILE = 'quick_suite_sa'
    AWS_REGION = 'us-east-1'
    SNOWFLAKE_DATABASE = 'MOVIES'
    DATASET_ID = 'movie-analytics-dataset'
    DATASET_NAME = 'Movie Analytics Dataset'
    SHARE_WITH_USER = 'ElevatedAccess/wangzyn-Isengard'
    
    # Data source configuration
    DATASOURCE_ID = 'movies-snowflake-datasource'
    DATASOURCE_NAME = 'Movies Snowflake Data Source'
    SNOWFLAKE_SECRET_NAME = 'snowflake-credentials'  # AWS Secrets Manager secret name
    CREATE_DATASOURCE = False  # Set to True to create data source from Secrets Manager
    
    # Initialize AWS clients
    session = boto3.Session(profile_name=AWS_PROFILE)
    quicksight = session.client('quicksight', region_name=AWS_REGION)
    sts = session.client('sts')
    account_id = sts.get_caller_identity()['Account']
    
    print(f"Using AWS Account: {account_id}")
    print(f"Region: {AWS_REGION}\n")
    
    # Step 0 (Optional): Create Snowflake data source
    if CREATE_DATASOURCE:
        print("Step 0: Creating Snowflake data source from AWS Secrets Manager...")
        datasource_response = create_snowflake_datasource(
            datasource_id=DATASOURCE_ID,
            datasource_name=DATASOURCE_NAME,
            secret_name=SNOWFLAKE_SECRET_NAME,
            aws_profile=AWS_PROFILE,
            region=AWS_REGION,
            delete_existing=True
        )
        datasource_arn = datasource_response['Arn']
        print(f"  ✓ Data source created: {datasource_arn}\n")
    else:
        # Get existing data source
        print("Step 0: Getting existing data source ARN...")
        try:
            datasource = quicksight.describe_data_source(
                AwsAccountId=account_id,
                DataSourceId=DATASOURCE_ID
            )
            datasource_arn = datasource['DataSource']['Arn']
            print(f"  ✓ Using existing data source: {datasource_arn}\n")
        except quicksight.exceptions.ResourceNotFoundException:
            print(f"  ✗ Data source '{DATASOURCE_ID}' not found!")
            print(f"  Set CREATE_DATASOURCE = True to create it from Secrets Manager")
            print(f"  Or create it manually using create_snowflake_datasource.py")
            return
    
    # Step 1: Parse Snowflake DDL
    print("Step 1: Parsing Snowflake DDL...")
    parser = SnowflakeDDLParser(CSV_PATH)
    parsed_ddl = parser.parse_all()
    
    print(f"  ✓ Found {len(parsed_ddl['tables'])} tables")
    print(f"  ✓ Found {len(parsed_ddl['relationships'])} relationships")
    print(f"  ✓ Found {len(parsed_ddl['dimensions'])} dimensions")
    print(f"  ✓ Found {len(parsed_ddl['facts'])} facts")
    print(f"  ✓ Found {len(parsed_ddl['metrics'])} metrics\n")
    
    # Step 2: Generate QuickSight schema
    print("Step 2: Generating QuickSight dataset schema...")
    generator = QuickSightSchemaGenerator(parsed_ddl)
    schema = generator.generate_complete_schema(
        datasource_arn=datasource_arn,
        database=SNOWFLAKE_DATABASE,
        dataset_id=DATASET_ID,
        dataset_name=DATASET_NAME
    )
    
    # Save schema to file
    with open('quicksight_schema.json', 'w') as f:
        json.dump(schema, f, indent=2)
    print(f"  ✓ Schema saved to quicksight_schema.json\n")
    
    # Step 3: Delete existing dataset if it exists
    print("Step 3: Checking for existing dataset...")
    try:
        quicksight.delete_data_set(
            AwsAccountId=account_id,
            DataSetId=DATASET_ID
        )
        print(f"  ✓ Deleted existing dataset: {DATASET_ID}")
        import time
        time.sleep(5)
    except quicksight.exceptions.ResourceNotFoundException:
        print(f"  ✓ No existing dataset found")
    
    # Step 4: Create dataset
    print("\nStep 4: Creating QuickSight dataset...")
    try:
        response = quicksight.create_data_set(
            AwsAccountId=account_id,
            **schema
        )
        print(f"  ✓ Dataset created: {response['DataSetId']}")
        print(f"  ✓ Dataset ARN: {response['Arn']}")
        print(f"  ✓ Status: {response['Status']}\n")
    except Exception as e:
        print(f"  ✗ Error creating dataset: {e}")
        return
    
    # Step 5: Create SPICE ingestion
    print("Step 5: Starting SPICE ingestion...")
    import time
    ingestion_id = f"ingestion-{int(time.time())}"
    try:
        ingestion_response = quicksight.create_ingestion(
            AwsAccountId=account_id,
            DataSetId=DATASET_ID,
            IngestionId=ingestion_id,
            IngestionType='FULL_REFRESH'
        )
        print(f"  ✓ Ingestion started: {ingestion_response['IngestionId']}")
        print(f"  ✓ Status: {ingestion_response['IngestionStatus']}\n")
    except Exception as e:
        print(f"  ✗ Error starting ingestion: {e}\n")
    
    # Step 6: Share with user
    if SHARE_WITH_USER:
        print(f"Step 6: Sharing dataset with user...")
        try:
            quicksight.update_data_set_permissions(
                AwsAccountId=account_id,
                DataSetId=DATASET_ID,
                GrantPermissions=[
                    {
                        'Principal': f"arn:aws:quicksight:{AWS_REGION}:{account_id}:user/default/{SHARE_WITH_USER}",
                        'Actions': [
                            'quicksight:UpdateDataSetPermissions',
                            'quicksight:DescribeDataSet',
                            'quicksight:DescribeDataSetPermissions',
                            'quicksight:PassDataSet',
                            'quicksight:DescribeIngestion',
                            'quicksight:ListIngestions',
                            'quicksight:UpdateDataSet',
                            'quicksight:DeleteDataSet',
                            'quicksight:CreateIngestion',
                            'quicksight:CancelIngestion'
                        ]
                    }
                ]
            )
            print(f"  ✓ Dataset shared with: {SHARE_WITH_USER}\n")
        except Exception as e:
            print(f"  ✗ Error sharing dataset: {e}\n")
    
    print("=" * 60)
    print("✓ Workflow complete!")
    print("=" * 60)
    print(f"\nDataset Details:")
    print(f"  ID: {DATASET_ID}")
    print(f"  Name: {DATASET_NAME}")
    print(f"  ARN: arn:aws:quicksight:{AWS_REGION}:{account_id}:dataset/{DATASET_ID}")
    print(f"\nYou can now use this dataset in QuickSight to create analyses and dashboards.")


if __name__ == '__main__':
    main()
