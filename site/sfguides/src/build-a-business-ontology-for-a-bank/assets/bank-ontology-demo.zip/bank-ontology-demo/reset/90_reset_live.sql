-- 90_reset_live.sql: undo Act 3 so the demo can be run again.
-- End state: 23 active nodes + Net Interest Margin as DRAFT, 29 relationships, 33 representations,
-- base semantic view (no interest metrics), no interest table.
-- Tolerates a partly-run Act 3: ontology calls on missing items return {"error":true,...} and carry on.
-- Run the whole file in one session.

-- 1. Resolve ids
SET t_nim_active = (SELECT MAX(value:termId::STRING) FROM TABLE(FLATTEN(PARSE_JSON(SYSTEM$GET_GLOSSARY_TERM_LIST('Regulatory Reporting', '')):terms)) WHERE value:name::STRING = 'Net Interest Margin');
SET t_nim_draft  = (SELECT MAX(value:termId::STRING) FROM TABLE(FLATTEN(PARSE_JSON(SYSTEM$GET_GLOSSARY_TERM_DRAFTS('Regulatory Reporting')):terms)) WHERE value:name::STRING = 'Net Interest Margin');
SET t_nim = COALESCE($t_nim_active, $t_nim_draft, '0');
SET t_principal = (SELECT value:termId::STRING FROM TABLE(FLATTEN(PARSE_JSON(SYSTEM$GET_GLOSSARY_TERM_LIST('Consumer Loan', '')):terms)) WHERE value:name::STRING = 'Outstanding Principal');
SET t_deposits  = (SELECT value:termId::STRING FROM TABLE(FLATTEN(PARSE_JSON(SYSTEM$GET_GLOSSARY_TERM_LIST('Current Account', '')):terms)) WHERE value:name::STRING = 'Total Deposits');
SET t_npl_loan  = (SELECT value:termId::STRING FROM TABLE(FLATTEN(PARSE_JSON(SYSTEM$GET_GLOSSARY_TERM_LIST('Regulatory Reporting', '')):terms)) WHERE value:name::STRING = 'Non-Performing Loan');
SET t_month_end = (SELECT value:termId::STRING FROM TABLE(FLATTEN(PARSE_JSON(SYSTEM$GET_GLOSSARY_TERM_LIST('Regulatory Reporting', '')):terms)) WHERE value:name::STRING = 'Reporting Month End');
SELECT $t_nim_active AS active_nim, $t_nim_draft AS draft_nim;

-- 2. Remove NIM's relationships and representations (the ones Act 3 creates)
SELECT SYSTEM$DELETE_GLOSSARY_RELATIONSHIP($t_principal, $t_nim);
SELECT SYSTEM$DELETE_GLOSSARY_RELATIONSHIP($t_deposits,  $t_nim);
SELECT SYSTEM$DELETE_GLOSSARY_RELATIONSHIP($t_npl_loan,  $t_nim);
SELECT SYSTEM$DELETE_GLOSSARY_RELATIONSHIP($t_month_end, $t_nim);
SELECT SYSTEM$DELETE_GLOSSARY_ASSOCIATION($t_nim,
  '{"refType":"SEMANTIC_VIEW","fqn":"BANK_DEMO.SEMANTIC.RETAIL_BANKING_SV","subObjectType":"DERIVED_METRIC","subObjectName":"NET_INTEREST_MARGIN"}');
SELECT SYSTEM$DELETE_GLOSSARY_ASSOCIATION($t_nim,
  '{"refType":"TABLE","fqn":"BANK_DEMO.SILVER.INTEREST_ACCRUAL_MONTHLY","objectName":"INTEREST_ACCRUAL_MONTHLY"}');

-- 3. Remove the node (approved or draft) and re-propose the original draft
SELECT SYSTEM$DELETE_GLOSSARY_TERM($t_nim);
SELECT SYSTEM$DRAFT_GLOSSARY_TERM('{"name": "Net Interest Margin", "domainName": "Regulatory Reporting", "itemKind": "METRIC", "description": "Net interest income divided by average interest-earning assets, annualised. PROPOSED: not yet reviewed by Finance; no implementation exists yet.", "synonyms": ["NIM"], "sourceType": "MANUAL", "formula": "(interest_income - interest_expense) / AVG(interest_earning_assets)"}');

-- 4. Data: drop the interest table and restore the base semantic view
DROP TABLE IF EXISTS BANK_DEMO.SILVER.INTEREST_ACCRUAL_MONTHLY;
USE DATABASE BANK_DEMO;
USE SCHEMA SEMANTIC;
-- Base semantic view (same as sql/02_semantic_view.sql)
CALL SYSTEM$CREATE_SEMANTIC_VIEW_FROM_YAML('BANK_DEMO.SEMANTIC', $$
name: RETAIL_BANKING_SV
description: 'Retail banking semantic view over the SILVER layer (synthetic demo bank): customers and their relationship managers, month-end current account balances, loans with maturity, arrears and the NPL and loan-to-deposit ratios, and customer interactions by channel. Monthly data from June 2025 to September 2026.'
tables:
- name: ACCOUNT_BALANCE
  description: Month-end ledger balance per current account, with the account holder and their KYC status
  base_table:
    database: BANK_DEMO
    schema: SEMANTIC
    table: ACCOUNT_BALANCE_INPUT
  primary_key:
    columns:
    - ARRANGEMENT_ID
    - SNAPSHOT_DATE
  facts:
  - name: VERIFIED_HOLDER_PARTY_ID
    description: Party holding the account, only when KYC is verified
    expr: IFF(HOLDER_KYC_STATUS = 'VERIFIED', HOLDER_PARTY_ID, NULL)
    data_type: VARCHAR(134217728)
    access_modifier: public_access
  metrics:
  - name: ACTIVE_CUSTOMERS
    synonyms:
    - active customers
    - active parties
    description: Parties with KYC VERIFIED holding at least one open current account at month end
    expr: COUNT(DISTINCT account_balance.verified_holder_party_id)
    access_modifier: public_access
    non_additive_dimensions:
    - table: CALENDAR
      dimension: MONTH_END_DATE
      sort_direction: ascending
      null_order: last
  - name: TOTAL_DEPOSITS
    synonyms:
    - deposits
    - customer deposits
    - deposit balances
    - balance
    - balances
    - customer balance
    - deposit balance
    description: Sum of month-end current account ledger balances, GBP. Semi-additive over time
    expr: SUM(LEDGER_BALANCE_GBP)
    access_modifier: public_access
    non_additive_dimensions:
    - table: CALENDAR
      dimension: MONTH_END_DATE
      sort_direction: ascending
      null_order: last
- name: CALENDAR
  description: Shared month-end reporting calendar
  base_table:
    database: BANK_DEMO
    schema: SILVER
    table: MONTH_END_CALENDAR
  primary_key:
    columns:
    - MONTH_END_DATE
  dimensions:
  - name: MONTH_END_DATE
    synonyms:
    - reporting date
    - snapshot date
    - as at date
    - month end
    description: Month-end reporting date for balances and positions
    expr: MONTH_END_DATE
    data_type: DATE
    access_modifier: public_access
- name: CURRENT_ACCOUNT
  synonyms:
  - current account
  - deposit account
  - CASA
  description: Current Account Arrangement (core banking platform)
  base_table:
    database: BANK_DEMO
    schema: SILVER
    table: CURRENT_ACCOUNT_ARRANGEMENT
  primary_key:
    columns:
    - ARRANGEMENT_ID
  dimensions:
  - name: HOLDER_PARTY_ID
    expr: PARTY_ID
    data_type: VARCHAR(16777216)
    access_modifier: public_access
  - name: OPENED_DATE
    expr: OPENED_DATE
    data_type: DATE
    access_modifier: public_access
  - name: PRODUCT_NAME
    description: Current account product
    expr: PRODUCT_NAME
    data_type: VARCHAR(24)
    access_modifier: public_access
- name: INTERACTION
  synonyms:
  - visits
  - activity
  - customer contacts
  - sessions
  description: 'Every customer interaction by channel: mobile app, online banking, branch visit or contact centre call'
  base_table:
    database: BANK_DEMO
    schema: SILVER
    table: CUSTOMER_INTERACTION
  primary_key:
    columns:
    - INTERACTION_ID
  dimensions:
  - name: CHANNEL
    synonyms:
    - channel
    - touchpoint
    description: Mobile app, Online banking, Branch or Contact centre
    expr: CHANNEL
    data_type: VARCHAR(14)
    access_modifier: public_access
  - name: CHANNEL_GROUP
    synonyms:
    - digital vs assisted
    description: Digital (app, online) or Assisted (branch, contact centre)
    expr: IFF(CHANNEL IN ('Mobile app', 'Online banking'), 'Digital', 'Assisted')
    data_type: VARCHAR(8)
    access_modifier: public_access
  - name: INTERACTION_DATE
    synonyms:
    - visit date
    - activity date
    expr: INTERACTION_DATE
    data_type: DATE
    access_modifier: public_access
  - name: INTERACTION_MONTH
    synonyms:
    - activity month
    - visit month
    description: First day of the month of the interaction
    expr: DATE_TRUNC('MONTH', INTERACTION_DATE)
    data_type: DATE
    access_modifier: public_access
  - name: INTERACTION_TYPE
    synonyms:
    - activity type
    - reason
    description: Login, Payment, Enquiry, Product application or Complaint
    expr: INTERACTION_TYPE
    data_type: VARCHAR(19)
    access_modifier: public_access
  facts:
  - name: IS_COMPLAINT
    expr: IFF(INTERACTION_TYPE = 'Complaint', 1, 0)
    data_type: NUMBER(1,0)
    access_modifier: public_access
  - name: IS_DIGITAL
    expr: IFF(CHANNEL IN ('Mobile app', 'Online banking'), 1, 0)
    data_type: NUMBER(1,0)
    access_modifier: public_access
  metrics:
  - name: ACTIVE_CHANNEL_USERS
    synonyms:
    - active users
    - unique customers
    - customers using the channel
    description: Distinct customers with at least one interaction
    expr: COUNT(DISTINCT PARTY_ID)
    access_modifier: public_access
  - name: COMPLAINTS
    synonyms:
    - complaint count
    description: Interactions recorded as a complaint
    expr: SUM(interaction.is_complaint)
    access_modifier: public_access
  - name: DIGITAL_SHARE
    synonyms:
    - digital adoption
    - digital share
    description: Share of interactions through mobile app or online banking
    expr: DIV0(SUM(interaction.is_digital), COUNT(INTERACTION_ID))
    access_modifier: public_access
  - name: INTERACTIONS
    synonyms:
    - visits
    - activity
    - contacts
    - interaction count
    description: Number of customer interactions
    expr: COUNT(INTERACTION_ID)
    access_modifier: public_access
- name: LOAN
  synonyms:
  - loan
  - lending facility
  - credit facility
  description: 'Loan Arrangement: personal loans and SME term loans with term and maturity date (core banking platform)'
  base_table:
    database: BANK_DEMO
    schema: SILVER
    table: LOAN_ARRANGEMENT
  primary_key:
    columns:
    - LOAN_ID
  dimensions:
  - name: BORROWER_PARTY_ID
    description: Customer who holds the loan
    expr: PARTY_ID
    data_type: VARCHAR(16777216)
    access_modifier: public_access
  - name: INTEREST_RATE_PCT
    synonyms:
    - rate
    - interest rate
    description: Contractual annual interest rate, %
    expr: INTEREST_RATE_PCT
    data_type: NUMBER(5,2)
    access_modifier: public_access
  - name: LOAN_CATEGORY
    description: CONSUMER_LOAN or CORPORATE_LOAN
    expr: LOAN_CATEGORY
    data_type: VARCHAR(14)
    access_modifier: public_access
  - name: LOAN_ID
    expr: LOAN_ID
    data_type: VARCHAR(16777216)
    access_modifier: public_access
  - name: LOAN_PRODUCT
    description: Personal Loan or SME Term Loan
    expr: LOAN_PRODUCT
    data_type: VARCHAR(13)
    access_modifier: public_access
  - name: MATURITY_DATE
    synonyms:
    - maturity
    - end date
    - final repayment date
    description: Date the loan is due to be fully repaid
    expr: MATURITY_DATE
    data_type: DATE
    access_modifier: public_access
  - name: MATURITY_YEAR
    description: Calendar year in which the loan matures
    expr: YEAR(MATURITY_DATE)
    data_type: NUMBER(4,0)
    access_modifier: public_access
  - name: ORIGINATION_DATE
    expr: ORIGINATION_DATE
    data_type: DATE
    access_modifier: public_access
  - name: TERM_MONTHS
    synonyms:
    - loan term
    - tenor
    description: Contractual term in months
    expr: TERM_MONTHS
    data_type: NUMBER(4,0)
    access_modifier: public_access
- name: LOAN_POSITION
  description: Month-end outstanding principal and days past due per loan, with the borrower and the maturity date
  base_table:
    database: BANK_DEMO
    schema: SEMANTIC
    table: LOAN_POSITION_INPUT
  primary_key:
    columns:
    - LOAN_ID
    - SNAPSHOT_DATE
  dimensions:
  - name: ARREARS_BUCKET
    synonyms:
    - delinquency bucket
    - arrears status
    expr: "CASE WHEN DAYS_PAST_DUE = 0 THEN '0 Current'\n                                         WHEN DAYS_PAST_DUE < 30 THEN '1-29 DPD'\n                                         WHEN DAYS_PAST_DUE < 90 THEN '30-89 DPD'\n                                         ELSE '90+ DPD' END"
    data_type: VARCHAR(9)
    access_modifier: public_access
  - name: DAYS_PAST_DUE
    synonyms:
    - DPD
    - arrears days
    expr: DAYS_PAST_DUE
    data_type: NUMBER(12,0)
    access_modifier: public_access
  - name: MATURITY_BUCKET
    synonyms:
    - maturity profile
    - maturity band
    - time to maturity
    - residual maturity
    description: 'Residual maturity: time from the month end of the position to the loan''s maturity date'
    expr: CASE WHEN MATURITY_DATE <= SNAPSHOT_DATE THEN '0. Matured' WHEN MATURITY_DATE <= DATEADD(year, 1, SNAPSHOT_DATE) THEN '1. Under 1 year' WHEN MATURITY_DATE <= DATEADD(year, 2, SNAPSHOT_DATE) THEN '2. 1-2 years' WHEN MATURITY_DATE <= DATEADD(year, 3, SNAPSHOT_DATE) THEN '3. 2-3 years' WHEN MATURITY_DATE <= DATEADD(year, 5, SNAPSHOT_DATE) THEN '4. 3-5 years' ELSE '5. Over 5 years' END
    data_type: VARCHAR(15)
    access_modifier: public_access
  facts:
  - name: LOAN_PARTY_ID
    description: Borrower of the loan
    expr: BORROWER_PARTY_ID
    data_type: VARCHAR(16777216)
    access_modifier: public_access
  - name: NON_PERFORMING_PRINCIPAL_GBP
    description: Outstanding principal on loans 90 or more days past due
    expr: IFF(DAYS_PAST_DUE >= 90, OUTSTANDING_PRINCIPAL_GBP, 0)
    data_type: NUMBER(29,2)
    access_modifier: public_access
  metrics:
  - name: BORROWERS
    synonyms:
    - borrowing customers
    - customers with loans
    description: Customers with at least one loan with a balance at month end
    expr: COUNT(DISTINCT IFF(OUTSTANDING_PRINCIPAL_GBP > 0, loan_position.loan_party_id, NULL))
    access_modifier: public_access
    non_additive_dimensions:
    - table: CALENDAR
      dimension: MONTH_END_DATE
      sort_direction: ascending
      null_order: last
  - name: LOANS_OUTSTANDING
    synonyms:
    - number of loans
    - loan count
    description: Loans with a balance at month end
    expr: COUNT(DISTINCT IFF(OUTSTANDING_PRINCIPAL_GBP > 0, LOAN_ID, NULL))
    access_modifier: public_access
    non_additive_dimensions:
    - table: CALENDAR
      dimension: MONTH_END_DATE
      sort_direction: ascending
      null_order: last
  - name: NON_PERFORMING_PRINCIPAL
    synonyms:
    - NPL balance
    - non-performing loans
    description: Month-end outstanding principal on loans 90+ days past due, GBP
    expr: SUM(loan_position.non_performing_principal_gbp)
    access_modifier: public_access
    non_additive_dimensions:
    - table: CALENDAR
      dimension: MONTH_END_DATE
      sort_direction: ascending
      null_order: last
  - name: OUTSTANDING_PRINCIPAL
    synonyms:
    - gross loans
    - loan book
    - loans outstanding
    - loan portfolio
    - total loans
    - lending book
    - outstanding balance
    description: Sum of month-end outstanding loan principal, GBP. Semi-additive over time
    expr: SUM(OUTSTANDING_PRINCIPAL_GBP)
    access_modifier: public_access
    non_additive_dimensions:
    - table: CALENDAR
      dimension: MONTH_END_DATE
      sort_direction: ascending
      null_order: last
- name: PARTY
  synonyms:
  - customer
  - client
  - counterparty
  - customers
  description: 'Party: person or organisation the bank has a relationship with, with segment, KYC status and relationship manager (CRM)'
  base_table:
    database: BANK_DEMO
    schema: SILVER
    table: PARTY
  primary_key:
    columns:
    - PARTY_ID
  dimensions:
  - name: CUSTOMER_SEGMENT
    synonyms:
    - segment
    - customer tier
    description: RETAIL, PREMIER or SME
    expr: CUSTOMER_SEGMENT
    data_type: VARCHAR(7)
    access_modifier: public_access
  - name: KYC_STATUS
    synonyms:
    - KYC
    - know your customer status
    description: VERIFIED, PENDING or EXPIRED
    expr: KYC_STATUS
    data_type: VARCHAR(8)
    access_modifier: public_access
  - name: ONBOARDED_DATE
    expr: ONBOARDED_DATE
    data_type: DATE
    access_modifier: public_access
  - name: PARTY_ID
    expr: PARTY_ID
    data_type: VARCHAR(16777216)
    access_modifier: public_access
  - name: PARTY_NAME
    synonyms:
    - customer name
    - client name
    - business name
    description: Customer or business name. Masked to initials for some roles
    expr: PARTY_NAME
    data_type: VARCHAR(16777216)
    access_modifier: public_access
  - name: PARTY_SOURCE_SYSTEM
    description: System of record for the Party
    expr: SOURCE_SYSTEM
    data_type: VARCHAR(3)
    access_modifier: public_access
  - name: PARTY_TYPE
    description: INDIVIDUAL or ORGANISATION
    expr: PARTY_TYPE
    data_type: VARCHAR(12)
    access_modifier: public_access
  - name: RM_ID
    description: Relationship manager who owns the customer
    expr: RM_ID
    data_type: VARCHAR(4)
    access_modifier: public_access
  metrics:
  - name: CUSTOMER_COUNT
    synonyms:
    - number of customers
    - customers on record
    description: Number of Parties on record
    expr: COUNT(PARTY_ID)
    access_modifier: public_access
- name: RELATIONSHIP_MANAGER
  synonyms:
  - RM
  - banker
  - account manager
  description: Relationship managers who own each customer book
  base_table:
    database: BANK_DEMO
    schema: SILVER
    table: RELATIONSHIP_MANAGER
  primary_key:
    columns:
    - RM_ID
  dimensions:
  - name: RM_NAME
    synonyms:
    - relationship manager
    - RM
    - banker
    description: Relationship manager who owns the customer
    expr: RM_NAME
    data_type: VARCHAR(16777216)
    access_modifier: public_access
  - name: RM_REGION
    synonyms:
    - region
    - area
    expr: REGION
    data_type: VARCHAR(16777216)
    access_modifier: public_access
  - name: RM_TEAM
    description: Personal & Premier or Business Banking
    expr: TEAM
    data_type: VARCHAR(16777216)
    access_modifier: public_access
metrics:
- name: COMPLAINT_RATE
  synonyms:
  - complaint rate
  - complaints per interaction
  description: Complaints as a share of interactions
  expr: DIV0(interaction.complaints, interaction.interactions)
  access_modifier: public_access
- name: LOAN_TO_DEPOSIT_RATIO
  synonyms:
  - LDR
  - loan to deposit ratio
  description: Outstanding loan principal divided by customer deposits at the same month end
  expr: DIV0(loan_position.outstanding_principal, account_balance.total_deposits)
  access_modifier: public_access
- name: NPL_RATIO
  synonyms:
  - NPL ratio
  - non-performing loan ratio
  description: Non-performing principal (90+ DPD) divided by outstanding principal
  expr: DIV0(loan_position.non_performing_principal, loan_position.outstanding_principal)
  access_modifier: public_access
relationships:
- name: BALANCE_TO_ACCOUNT
  left_table: ACCOUNT_BALANCE
  right_table: CURRENT_ACCOUNT
  relationship_columns:
  - left_column: ARRANGEMENT_ID
    right_column: ARRANGEMENT_ID
- name: BALANCE_TO_CALENDAR
  left_table: ACCOUNT_BALANCE
  right_table: CALENDAR
  relationship_columns:
  - left_column: SNAPSHOT_DATE
    right_column: MONTH_END_DATE
- name: CURRENT_ACCOUNT_TO_PARTY
  left_table: CURRENT_ACCOUNT
  right_table: PARTY
  relationship_columns:
  - left_column: PARTY_ID
    right_column: PARTY_ID
- name: INTERACTION_TO_PARTY
  left_table: INTERACTION
  right_table: PARTY
  relationship_columns:
  - left_column: PARTY_ID
    right_column: PARTY_ID
- name: LOAN_TO_PARTY
  left_table: LOAN
  right_table: PARTY
  relationship_columns:
  - left_column: PARTY_ID
    right_column: PARTY_ID
- name: POSITION_TO_CALENDAR
  left_table: LOAN_POSITION
  right_table: CALENDAR
  relationship_columns:
  - left_column: SNAPSHOT_DATE
    right_column: MONTH_END_DATE
- name: POSITION_TO_LOAN
  left_table: LOAN_POSITION
  right_table: LOAN
  relationship_columns:
  - left_column: LOAN_ID
    right_column: LOAN_ID
- name: PARTY_TO_RM
  left_table: PARTY
  right_table: RELATIONSHIP_MANAGER
  relationship_columns:
  - left_column: RM_ID
    right_column: RM_ID
module_custom_instructions:
  sql_generation: 'The data runs to 30 September 2026 and is the latest available. Never use CURRENT_DATE or CURRENT_TIMESTAMP: treat ''now'', ''today'', ''latest'', ''this month'' and ''last month'' as September 2026 (month end 2026-09-30), ''previous month'' or ''prior month'' as August 2026, and ''last N months'' as the N months ending September 2026. Balances and positions are month-end snapshots: when the user gives no date, report the latest month end (2026-09-30) for balances and loans, and the latest full month (September 2026) for interactions. Never sum balances across dates. To find customers with a balance over a threshold, group by customer at a single month end and filter on the summed balance. Round ratios to 4 decimals and GBP amounts to 0 decimals. Order maturity and arrears buckets by their leading number.'
verified_queries:
- name: CUSTOMERS_BALANCE_OVER_120K
  sql: "SELECT party_name, customer_segment, rm_name, total_deposits\nFROM SEMANTIC_VIEW(BANK_DEMO.SEMANTIC.RETAIL_BANKING_SV\n  METRICS account_balance.total_deposits\n  DIMENSIONS party.party_name, party.customer_segment, relationship_manager.rm_name\n  WHERE calendar.month_end_date = '2026-09-30')\nWHERE total_deposits > 120000\nORDER BY total_deposits DESC\n"
  question: Which customers have balances over 120k?
  verified_at: 1795392000
  verified_by: Bank demo
  use_as_onboarding_question: true
- name: CUSTOMERS_BY_LOAN_MATURITY
  sql: "SELECT maturity_bucket, borrowers, loans_outstanding, outstanding_principal\nFROM SEMANTIC_VIEW(BANK_DEMO.SEMANTIC.RETAIL_BANKING_SV\n  METRICS loan_position.borrowers, loan_position.loans_outstanding, loan_position.outstanding_principal\n  DIMENSIONS loan_position.maturity_bucket\n  WHERE calendar.month_end_date = '2026-09-30')\nORDER BY maturity_bucket\n"
  question: How many customers do we have by loan maturity?
  verified_at: 1795392000
  verified_by: Bank demo
  use_as_onboarding_question: true
- name: LOAN_PORTFOLIO_BY_MATURITY
  sql: "SELECT maturity_bucket, loan_product, outstanding_principal, loans_outstanding\nFROM SEMANTIC_VIEW(BANK_DEMO.SEMANTIC.RETAIL_BANKING_SV\n  METRICS loan_position.outstanding_principal, loan_position.loans_outstanding\n  DIMENSIONS loan_position.maturity_bucket, loan.loan_product\n  WHERE calendar.month_end_date = '2026-09-30')\nORDER BY maturity_bucket, loan_product\n"
  question: What is the total loan portfolio by maturity?
  verified_at: 1795392000
  verified_by: Bank demo
  use_as_onboarding_question: true
- name: ACTIVITY_BY_CHANNEL
  sql: "SELECT interaction_month, channel, interactions, active_channel_users, complaints\nFROM SEMANTIC_VIEW(BANK_DEMO.SEMANTIC.RETAIL_BANKING_SV\n  METRICS interaction.interactions, interaction.active_channel_users, interaction.complaints\n  DIMENSIONS interaction.interaction_month, interaction.channel\n  WHERE interaction.interaction_month >= '2026-04-01')\nORDER BY interaction_month, channel\n"
  question: Show customer visits and activity by channel over the last six months
  verified_at: 1795392000
  verified_by: Bank demo
  use_as_onboarding_question: true
- name: LOANS_MATURING_NEXT_12_MONTHS
  sql: "SELECT party_name, loan_id, loan_product, maturity_date, outstanding_principal\nFROM SEMANTIC_VIEW(BANK_DEMO.SEMANTIC.RETAIL_BANKING_SV\n  METRICS loan_position.outstanding_principal\n  DIMENSIONS party.party_name, loan.loan_id, loan.loan_product, loan.maturity_date\n  WHERE calendar.month_end_date = '2026-09-30' AND loan_position.maturity_bucket = '1. Under 1 year')\nORDER BY maturity_date\n"
  question: Which loans mature in the next 12 months?
  verified_at: 1795392000
  verified_by: Bank demo
  use_as_onboarding_question: false
$$, FALSE);


-- 5. Read back. Expect 23 active nodes, 1 draft (Net Interest Margin), 29 relationships, 33 representations.
SELECT SYSTEM$GET_GLOSSARY_SUMMARY();
