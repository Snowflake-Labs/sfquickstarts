-- 99_teardown.sql: remove everything this demo created. Irreversible.
-- Run as ACCOUNTADMIN, the whole file in one session.
-- The ontology is account-wide. This script only deletes the five demo domains whose description carries the
-- [bank-ontology-demo] marker written by 03_ontology.sql; a domain with the same name but no marker is left
-- untouched and reported. Order matters: representations and relationships first, then nodes and drafts,
-- then the empty domains.
CREATE WAREHOUSE IF NOT EXISTS BANK_DEMO_WH
  WAREHOUSE_SIZE = XSMALL AUTO_SUSPEND = 60 AUTO_RESUME = TRUE INITIALLY_SUSPENDED = TRUE;
USE WAREHOUSE BANK_DEMO_WH;

-- 1. Ontology
EXECUTE IMMEDIATE $$
DECLARE
  names ARRAY DEFAULT ARRAY_CONSTRUCT('Customer', 'Current Account', 'Consumer Loan', 'Regulatory Reporting', 'Customer Engagement');
  marked ARRAY DEFAULT ARRAY_CONSTRUCT();
  skipped ARRAY DEFAULT ARRAY_CONSTRUCT();
  d VARCHAR;
  f VARCHAR;
  j VARCHAR;
  found BOOLEAN;
  is_demo BOOLEAN;
  r VARCHAR;
BEGIN
  FOR i IN 0 TO 4 DO
    d := names[i]::VARCHAR;
    j := (SELECT SYSTEM$GET_GLOSSARY_DOMAIN(:d));
    found := (SELECT NOT COALESCE(PARSE_JSON(:j):error::BOOLEAN, FALSE));
    is_demo := (SELECT CONTAINS(COALESCE(PARSE_JSON(:j):description::VARCHAR, ''), '[bank-ontology-demo]'));
    IF (found AND is_demo) THEN
      marked := ARRAY_APPEND(marked, d);
    ELSEIF (found) THEN
      skipped := ARRAY_APPEND(skipped, d);
    END IF;
  END FOR;
  IF (ARRAY_SIZE(marked) > 0) THEN
    FOR i IN 0 TO ARRAY_SIZE(marked) - 1 DO
      f := '{"domainFilter": "' || marked[i]::VARCHAR || '"}';
      r := (SELECT SYSTEM$DELETE_ALL_GLOSSARY_ASSOCIATIONS(:f));
      r := (SELECT SYSTEM$DELETE_ALL_GLOSSARY_RELATIONSHIPS(:f));
    END FOR;
    FOR i IN 0 TO ARRAY_SIZE(marked) - 1 DO
      f := '{"domainFilter": "' || marked[i]::VARCHAR || '"}';
      r := (SELECT SYSTEM$DELETE_ALL_GLOSSARY_TERM_DRAFTS(:f));
      r := (SELECT SYSTEM$DELETE_ALL_GLOSSARY_TERMS(:f));
    END FOR;
    FOR i IN 0 TO ARRAY_SIZE(marked) - 1 DO
      d := marked[i]::VARCHAR;
      r := (SELECT SYSTEM$DELETE_GLOSSARY_DOMAIN(:d));
    END FOR;
  END IF;
  RETURN 'Deleted demo domains: ' || COALESCE(NULLIF(ARRAY_TO_STRING(marked, ', '), ''), 'none')
      || '. Left untouched (no demo marker): ' || COALESCE(NULLIF(ARRAY_TO_STRING(skipped, ', '), ''), 'none') || '.';
END;
$$;

-- 2. CoWork: detach the governed agent (no-op if it isn't attached)
EXECUTE IMMEDIATE $$
DECLARE
  si VARCHAR;
BEGIN
  SHOW SNOWFLAKE INTELLIGENCES;
  si := (SELECT MAX("name") FROM TABLE(RESULT_SCAN(LAST_QUERY_ID())));
  IF (si IS NOT NULL) THEN
    EXECUTE IMMEDIATE 'ALTER SNOWFLAKE INTELLIGENCE "' || REPLACE(si, '"', '""') || '" DROP AGENT BANK_DEMO.SEMANTIC.RETAIL_BANKING_AGENT';
  END IF;
  RETURN 'Detached the agent from CoWork.';
EXCEPTION
  WHEN OTHER THEN RETURN 'Nothing to detach from CoWork.';
END;
$$;

-- 3. Your default role, warehouse and secondary roles, as saved by 00_setup.sql
EXECUTE IMMEDIATE $$
DECLARE
  res VARCHAR;
BEGIN
  CALL BANK_DEMO.GOVERNANCE.RESTORE_USER_DEFAULTS();
  res := (SELECT $1 FROM TABLE(RESULT_SCAN(LAST_QUERY_ID())));
  RETURN res;
EXCEPTION
  WHEN OTHER THEN RETURN 'No saved defaults found: check your default role and warehouse with DESCRIBE USER.';
END;
$$;

-- 4. Data, agents, roles and warehouse
DROP DATABASE IF EXISTS BANK_DEMO;
DROP ROLE IF EXISTS BANK_RM;
DROP ROLE IF EXISTS BANK_HEAD_OF_LENDING;
SELECT SYSTEM$GET_GLOSSARY_SUMMARY();
DROP WAREHOUSE IF EXISTS BANK_DEMO_WH;
