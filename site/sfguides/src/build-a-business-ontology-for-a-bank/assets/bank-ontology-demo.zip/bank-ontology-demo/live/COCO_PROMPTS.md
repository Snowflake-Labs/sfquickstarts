# Act 3: Adding One Data Product, Live in Cortex Code

Adds a new data product during the demo. Type each prompt below into Cortex Code, connected to the demo account.
Every step also has a prepared script: if CoCo goes off-script, run the script instead. The result is the same.

**Before you start:** make sure the account is at the baseline. If in doubt, run `reset/90_reset_live.sql`, then
`sql/06_verify.sql` should be all PASS.

## Step 1: Land the New Data in Silver (1 min)

> Run live/10_interest_silver.sql and show me the net interest margin check at the end.

Fallback: run `live/10_interest_silver.sql` in a worksheet. You should see 16 month ends, with NIM going from 3.61% in
August 2026 to 3.40% in September.

Key point: this is the next data product landing, interest accruals from the core banking platform. The script
attaches the same row access policy as everything else, so a relationship manager only sees interest on her own
book. Access is part of landing the data.

## Step 2: Extend the Semantic View (3 min)

> Add BANK_DEMO.SILVER.INTEREST_ACCRUAL_MONTHLY to the semantic view BANK_DEMO.SEMANTIC.RETAIL_BANKING_SV, joined to
> the calendar on SNAPSHOT_DATE. Add metrics for interest income, interest expense, net interest income, interest-earning
> assets (loans plus the central bank reserve, semi-additive by month end) and NET_INTEREST_MARGIN = net interest income
> x 12 / interest-earning assets. Keep everything else unchanged, then check NIM against raw SQL for every month end.

Fallback: `live/11_sv_add_nim.sql`.

Key point: the technical steward owns *how* it's computed. Nothing in the ontology has changed yet, so the agent
still refuses: the number exists, but nobody has approved what it means. Optionally, ask the agent *"What is our Net
Interest Margin?"* here to show it.

## Step 3: Finance Approves the Definition (4 min, business-ontology skill)

> In the Regulatory Reporting domain of the Business Ontology, Finance has reviewed the draft Net Interest Margin.
> Update it to match the NET_INTEREST_MARGIN metric we just built (loans 90+ days past due are on non-accrual), approve
> it, add DERIVES relationships from Outstanding Principal, Total Deposits and Non-Performing Loan, a SCOPES relationship
> from Reporting Month End, and bind it to the NET_INTEREST_MARGIN metric in RETAIL_BANKING_SV and the
> INTEREST_ACCRUAL_MONTHLY table.

Fallback: `live/12_ontology_nim.sql`. The read-back should show 24 active nodes, 0 drafts, 33 relationships and 35
representations.

Please note: NIM is still an unpublished draft, so it's edited in place. Edit cards (maker-checker on a change) only
apply to active nodes, so if the skill tries one and gets "Only an active term can have a pending change", that's expected.

## Step 4: Show It (2 min)

1. Snowsight » Catalog » Business Ontology » Graph: Net Interest Margin now has its inputs and bindings (the graph
   updates straight away).
2. In CoWork (or the agent playground), ask **Retail Banking Agent**:
   - *"What is our Net Interest Margin?"* → **3.40%** at 30 September 2026, citing `Regulatory Reporting.Net Interest Margin`.
   - *"Why did Net Interest Margin fall between August and September 2026?"* → 3.61% to 3.40%: more loans hit 90+
     days past due and stopped accruing (non-performing principal went from £75,029 to £265,008), loans shrank, and
     more deposits sat in the 4% reserve.

The trace will likely show the ontology search returning nothing and the agent reading the approved list instead:
search runs on an index that can lag new approvals by a few hours in this preview. Either way, the agent only sees
approved definitions.

## After the Session

Run `reset/90_reset_live.sql`, then `sql/06_verify.sql` (all PASS).
