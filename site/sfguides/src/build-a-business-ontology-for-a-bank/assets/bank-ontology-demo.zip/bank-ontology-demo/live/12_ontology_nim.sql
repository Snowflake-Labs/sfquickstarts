-- 12_ontology_nim.sql: Act 3, step 3 (scripted fallback for the CoCo / business-ontology skill step).
-- Finance reviews the proposed Net Interest Margin, aligns it to the implementation in
-- RETAIL_BANKING_SV, approves it, links it to its inputs and binds it to the data.
-- Prerequisites: live/10_interest_silver.sql and live/11_sv_add_nim.sql have run.
-- Run the whole file in one session (ids are carried in session variables).

-- 0. Resolve ids (never hard-code them: they differ per account)
SET t_nim = (SELECT value:termId::STRING
             FROM TABLE(FLATTEN(PARSE_JSON(SYSTEM$GET_GLOSSARY_TERM_DRAFTS('Regulatory Reporting')):terms))
             WHERE value:name::STRING = 'Net Interest Margin');
SET t_principal = (SELECT value:termId::STRING FROM TABLE(FLATTEN(PARSE_JSON(SYSTEM$GET_GLOSSARY_TERM_LIST('Consumer Loan', '')):terms)) WHERE value:name::STRING = 'Outstanding Principal');
SET t_deposits  = (SELECT value:termId::STRING FROM TABLE(FLATTEN(PARSE_JSON(SYSTEM$GET_GLOSSARY_TERM_LIST('Current Account', '')):terms)) WHERE value:name::STRING = 'Total Deposits');
SET t_npl_loan  = (SELECT value:termId::STRING FROM TABLE(FLATTEN(PARSE_JSON(SYSTEM$GET_GLOSSARY_TERM_LIST('Regulatory Reporting', '')):terms)) WHERE value:name::STRING = 'Non-Performing Loan');
SET t_month_end = (SELECT value:termId::STRING FROM TABLE(FLATTEN(PARSE_JSON(SYSTEM$GET_GLOSSARY_TERM_LIST('Regulatory Reporting', '')):terms)) WHERE value:name::STRING = 'Reporting Month End');
SELECT $t_nim AS nim, $t_principal AS principal, $t_deposits AS deposits, $t_npl_loan AS npl_loan, $t_month_end AS month_end;

-- 1. Finance revises the proposal. An unpublished draft is edited in place (edit cards are for ACTIVE nodes).
SELECT SYSTEM$UPDATE_GLOSSARY_TERM($t_nim, '{
  "description": "Net interest income for one reporting month, annualised (x12), divided by interest-earning assets (Loans plus the central bank reserve) at the same reporting month end. Loans 90 or more Days Past Due are on non-accrual and earn no interest income. Demo simplification: month-end balances rather than daily averages.",
  "synonyms": ["NIM", "Net Interest Margin Ratio"],
  "formula": "(SUM(interest_income_gbp) - SUM(interest_expense_gbp)) * 12 / SUM(earning_asset_balance_gbp) GROUP BY month_end_date",
  "formulaSource": "BANK_DEMO.SEMANTIC.RETAIL_BANKING_SV"
}');

-- 2. Approve (steward with MODIFY on Regulatory Reporting)
SELECT SYSTEM$APPROVE_GLOSSARY_TERM($t_nim);

-- 3. Relationships: what NIM is computed from, and how it is scoped
SELECT SYSTEM$CREATE_GLOSSARY_RELATIONSHIP($t_principal, $t_nim, 'DERIVES', '', 'MANUAL');
SELECT SYSTEM$CREATE_GLOSSARY_RELATIONSHIP($t_deposits,  $t_nim, 'DERIVES', '', 'MANUAL');
SELECT SYSTEM$CREATE_GLOSSARY_RELATIONSHIP($t_npl_loan,  $t_nim, 'DERIVES', '', 'MANUAL');
SELECT SYSTEM$CREATE_GLOSSARY_RELATIONSHIP($t_month_end, $t_nim, 'SCOPES',  '', 'MANUAL');

-- 4. Representations: bind NIM to the semantic view metric and the new Silver table
SELECT SYSTEM$CREATE_GLOSSARY_ASSOCIATION($t_nim,
  '{"refType":"SEMANTIC_VIEW","fqn":"BANK_DEMO.SEMANTIC.RETAIL_BANKING_SV","subObjectType":"DERIVED_METRIC","subObjectName":"NET_INTEREST_MARGIN"}',
  'RELATED_SEMANTIC_VIEW', 'MANUAL');
SELECT SYSTEM$CREATE_GLOSSARY_ASSOCIATION($t_nim,
  '{"refType":"TABLE","fqn":"BANK_DEMO.SILVER.INTEREST_ACCRUAL_MONTHLY","objectName":"INTEREST_ACCRUAL_MONTHLY"}',
  'DESCRIBES', 'MANUAL');

-- 5. Read back. Expect 24 active nodes, 0 drafts, 33 relationships, 35 representations.
SELECT SYSTEM$GET_GLOSSARY_SUMMARY();
