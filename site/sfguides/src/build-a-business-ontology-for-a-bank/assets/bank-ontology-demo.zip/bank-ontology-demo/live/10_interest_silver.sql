-- 10_interest_silver.sql: Act 3, step 1. A new Silver data product: monthly interest accruals.
-- Source: core banking platform (synthetic). Deterministic: derived from the existing Silver tables.
--
-- One row per interest-bearing arrangement per reporting month end:
--   LOAN                  interest income at the loan's contractual rate. Loans 90+ days past due are on
--                         non-accrual (no income recognised), which ties NIM to the NPL definition.
--   CURRENT_ACCOUNT       interest expense paid to depositors, priced by product.
--   CENTRAL_BANK_RESERVE  deposits not lent out (Total Deposits - Outstanding Principal) placed at the
--                         central bank, earning the reserve rate.
-- Demo simplification: interest accrues monthly on the month-end balance (rate / 12).
USE DATABASE BANK_DEMO;
USE SCHEMA SILVER;

CREATE OR REPLACE TABLE INTEREST_ACCRUAL_MONTHLY (
    ARRANGEMENT_ID               VARCHAR,
    ARRANGEMENT_TYPE             VARCHAR(20),
    SNAPSHOT_DATE                DATE,
    INTEREST_BEARING_BALANCE_GBP NUMBER(29,2),
    ANNUAL_RATE_PCT              NUMBER(5,2),
    INTEREST_INCOME_GBP          NUMBER(29,2),
    INTEREST_EXPENSE_GBP         NUMBER(29,2),
    SOURCE_SYSTEM                VARCHAR(12)
) COMMENT = 'Monthly interest accrual per interest-bearing arrangement (loans, current accounts, central bank reserve). Income and expense are monthly flows: additive across months. Source: core banking platform (synthetic).';

INSERT INTO INTEREST_ACCRUAL_MONTHLY
WITH loans AS (
    SELECT p.loan_id, p.snapshot_date, p.outstanding_principal_gbp AS bal, l.interest_rate_pct AS rate,
           IFF(p.days_past_due >= 90, 0, ROUND(p.outstanding_principal_gbp * l.interest_rate_pct / 100 / 12, 2)) AS income
    FROM loan_position_snapshot p
    JOIN loan_arrangement l ON l.loan_id = p.loan_id
),
deposits AS (
    SELECT b.arrangement_id, b.snapshot_date, b.ledger_balance_gbp AS bal,
           CASE a.product_name WHEN 'Everyday Current Account' THEN 1.50
                               WHEN 'Premier Current Account'  THEN 3.00
                               WHEN 'Business Current Account' THEN 2.00 END AS rate
    FROM current_account_balance_snapshot b
    JOIN current_account_arrangement a ON a.arrangement_id = b.arrangement_id
),
reserve AS (
    SELECT c.month_end_date AS snapshot_date,
           GREATEST(COALESCE(d.dep, 0) - COALESCE(l.loans, 0), 0) AS bal
    FROM month_end_calendar c
    LEFT JOIN (SELECT snapshot_date, SUM(bal) dep FROM deposits GROUP BY 1) d ON d.snapshot_date = c.month_end_date
    LEFT JOIN (SELECT snapshot_date, SUM(bal) loans FROM loans GROUP BY 1) l ON l.snapshot_date = c.month_end_date
)
SELECT loan_id, 'LOAN', snapshot_date, bal, rate, income, 0, 'CORE_BANKING' FROM loans
UNION ALL
SELECT arrangement_id, 'CURRENT_ACCOUNT', snapshot_date, bal, rate, 0, ROUND(GREATEST(bal, 0) * rate / 100 / 12, 2), 'CORE_BANKING' FROM deposits
UNION ALL
SELECT 'TSY-CB-RESERVE', 'CENTRAL_BANK_RESERVE', snapshot_date, bal, 4.00, ROUND(bal * 4.00 / 100 / 12, 2), 0, 'CORE_BANKING' FROM reserve;

-- Same access rules as the rest of Silver: a relationship manager sees interest on their own book only
-- (the central bank reserve is bank-level and belongs to no book).
ALTER TABLE INTEREST_ACCRUAL_MONTHLY ADD ROW ACCESS POLICY BANK_DEMO.GOVERNANCE.RM_BOOK_POLICY ON (ARRANGEMENT_ID);

-- Check: one row per arrangement per month end, and NIM by month (should be ~3-4.5%).
SELECT snapshot_date,
       SUM(interest_income_gbp) AS income,
       SUM(interest_expense_gbp) AS expense,
       SUM(IFF(arrangement_type IN ('LOAN', 'CENTRAL_BANK_RESERVE'), interest_bearing_balance_gbp, 0)) AS earning_assets,
       ROUND(DIV0((SUM(interest_income_gbp) - SUM(interest_expense_gbp)) * 12, earning_assets) * 100, 2) AS nim_pct
FROM INTEREST_ACCRUAL_MONTHLY
GROUP BY 1 ORDER BY 1;
