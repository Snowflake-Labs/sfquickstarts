-- 00_setup.sql: warehouse, database, schemas and persona roles for the demo bank.
-- Run as ACCOUNTADMIN (or a role that can create warehouses, databases and roles, and alter your user).
-- Everything this demo creates is removed by reset/99_teardown.sql.
CREATE WAREHOUSE IF NOT EXISTS BANK_DEMO_WH
  WAREHOUSE_SIZE = XSMALL AUTO_SUSPEND = 60 AUTO_RESUME = TRUE INITIALLY_SUSPENDED = TRUE
  COMMENT = 'Bank ontology demo: queries and agents';
USE WAREHOUSE BANK_DEMO_WH;

CREATE DATABASE IF NOT EXISTS BANK_DEMO
  COMMENT = 'Synthetic demo retail bank: Silver layer, semantic view, Business Ontology agents. No real customer data.';
CREATE SCHEMA IF NOT EXISTS BANK_DEMO.SILVER   COMMENT = 'Cleansed, conformed Silver layer of a synthetic demo bank';
CREATE SCHEMA IF NOT EXISTS BANK_DEMO.SEMANTIC COMMENT = 'Semantic views and agents';
CREATE SCHEMA IF NOT EXISTS BANK_DEMO.GOVERNANCE COMMENT = 'Persona mapping, row access and masking policies';

-- Demo personas (policies and grants: 05_governance.sql). Both are granted to the user running this script.
CREATE ROLE IF NOT EXISTS BANK_RM COMMENT = 'Demo persona: Sarah Collins, Relationship Manager. Sees her own customer book only.';
CREATE ROLE IF NOT EXISTS BANK_HEAD_OF_LENDING COMMENT = 'Demo persona: Head of Lending. Sees the whole bank, customer names masked to initials.';
SET demo_user = CURRENT_USER();
GRANT ROLE BANK_RM TO USER IDENTIFIER($demo_user);
GRANT ROLE BANK_HEAD_OF_LENDING TO USER IDENTIFIER($demo_user);

-- Your current defaults. sql/persona_switch.sql changes them to switch persona in CoWork;
-- RESTORE_USER_DEFAULTS puts them back, and reset/99_teardown.sql calls it. Saved on the first run only.
DESCRIBE USER IDENTIFIER($demo_user);
CREATE TABLE IF NOT EXISTS BANK_DEMO.GOVERNANCE.DEMO_USER_DEFAULTS
  COMMENT = 'Defaults of the user who installed the demo, saved before any persona switch' AS
SELECT $demo_user::VARCHAR AS USER_NAME,
       NULLIF(MAX(IFF("property" = 'DEFAULT_ROLE', "value", NULL)), 'null')::VARCHAR AS DEFAULT_ROLE,
       NULLIF(MAX(IFF("property" = 'DEFAULT_WAREHOUSE', "value", NULL)), 'null')::VARCHAR AS DEFAULT_WAREHOUSE,
       NULLIF(MAX(IFF("property" = 'DEFAULT_SECONDARY_ROLES', "value", NULL)), 'null')::VARCHAR AS DEFAULT_SECONDARY_ROLES,
       CURRENT_TIMESTAMP() AS SAVED_AT
FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()));

CREATE OR REPLACE PROCEDURE BANK_DEMO.GOVERNANCE.RESTORE_USER_DEFAULTS()
  RETURNS VARCHAR
  LANGUAGE SQL
  COMMENT = 'Puts back the default role, warehouse and secondary roles saved by 00_setup.sql'
  EXECUTE AS CALLER
AS
$$
DECLARE
  u VARCHAR;
  r VARCHAR;
  w VARCHAR;
  s VARCHAR;
  roles VARCHAR;
  user_id VARCHAR;
  set_clause VARCHAR DEFAULT '';
  unset_clause VARCHAR DEFAULT '';
BEGIN
  SELECT USER_NAME, DEFAULT_ROLE, DEFAULT_WAREHOUSE, DEFAULT_SECONDARY_ROLES INTO :u, :r, :w, :s
    FROM BANK_DEMO.GOVERNANCE.DEMO_USER_DEFAULTS LIMIT 1;
  user_id := '"' || REPLACE(u, '"', '""') || '"';
  IF (r IS NULL) THEN
    unset_clause := unset_clause || ', DEFAULT_ROLE';
  ELSE
    set_clause := set_clause || ' DEFAULT_ROLE = ''' || REPLACE(r, '''', '''''') || '''';
  END IF;
  IF (w IS NULL) THEN
    unset_clause := unset_clause || ', DEFAULT_WAREHOUSE';
  ELSE
    set_clause := set_clause || ' DEFAULT_WAREHOUSE = ''' || REPLACE(w, '''', '''''') || '''';
  END IF;
  IF (s IS NULL) THEN
    unset_clause := unset_clause || ', DEFAULT_SECONDARY_ROLES';
  ELSE
    roles := (SELECT LISTAGG('''' || REPLACE(f.value::VARCHAR, '''', '''''') || '''', ', ')
                FROM TABLE(FLATTEN(INPUT => TRY_PARSE_JSON(:s))) f);
    set_clause := set_clause || ' DEFAULT_SECONDARY_ROLES = (' || COALESCE(roles, '') || ')';
  END IF;
  IF (set_clause <> '') THEN
    EXECUTE IMMEDIATE 'ALTER USER ' || user_id || ' SET' || set_clause;
  END IF;
  IF (unset_clause <> '') THEN
    EXECUTE IMMEDIATE 'ALTER USER ' || user_id || ' UNSET ' || LTRIM(unset_clause, ', ');
  END IF;
  RETURN 'Restored defaults for ' || u || ': role ' || COALESCE(r, '(unset)') || ', warehouse '
      || COALESCE(w, '(unset)') || ', secondary roles ' || COALESCE(s, '(unset)');
END;
$$;
