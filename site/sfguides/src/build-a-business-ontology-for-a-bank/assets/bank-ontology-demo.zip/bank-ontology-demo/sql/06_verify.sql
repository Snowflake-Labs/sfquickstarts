-- 06_verify.sql: checks the install against figures computed independently from the raw Silver tables.
-- Three result sets (whole bank, then each persona). Every row must say PASS. Run as ACCOUNTADMIN with the
-- account at the baseline (before Act 3, or after reset/90_reset_live.sql).
USE WAREHOUSE BANK_DEMO_WH;

-- 1. Whole bank: Silver, semantic view, self-service questions, ontology
WITH sv AS (
    SELECT * FROM SEMANTIC_VIEW(BANK_DEMO.SEMANTIC.RETAIL_BANKING_SV
        DIMENSIONS calendar.month_end_date
        METRICS npl_ratio, loan_to_deposit_ratio, account_balance.total_deposits, loan_position.outstanding_principal,
                account_balance.active_customers)
    WHERE month_end_date = '2026-09-30'
),
raw_loans AS (
    SELECT SUM(outstanding_principal_gbp) AS principal,
           SUM(IFF(days_past_due >= 90, outstanding_principal_gbp, 0)) AS npl
    FROM BANK_DEMO.SILVER.LOAN_POSITION_SNAPSHOT WHERE snapshot_date = '2026-09-30'
),
raw_dep AS (
    SELECT SUM(ledger_balance_gbp) AS deposits
    FROM BANK_DEMO.SILVER.CURRENT_ACCOUNT_BALANCE_SNAPSHOT WHERE snapshot_date = '2026-09-30'
),
raw_active AS (
    SELECT COUNT(DISTINCT a.party_id) AS n
    FROM BANK_DEMO.SILVER.CURRENT_ACCOUNT_BALANCE_SNAPSHOT b
    JOIN BANK_DEMO.SILVER.CURRENT_ACCOUNT_ARRANGEMENT a ON a.arrangement_id = b.arrangement_id
    JOIN BANK_DEMO.SILVER.PARTY p ON p.party_id = a.party_id
    WHERE b.snapshot_date = '2026-09-30' AND p.kyc_status = 'VERIFIED'
),
over_120k AS (
    SELECT COUNT(*) AS n, MAX(total_deposits) AS top
    FROM SEMANTIC_VIEW(BANK_DEMO.SEMANTIC.RETAIL_BANKING_SV
        METRICS account_balance.total_deposits DIMENSIONS party.party_id
        WHERE calendar.month_end_date = '2026-09-30')
    WHERE total_deposits > 120000
),
maturity AS (
    SELECT LISTAGG(ROUND(outstanding_principal)::STRING || '/' || borrowers::STRING, ' ')
             WITHIN GROUP (ORDER BY maturity_bucket) AS profile
    FROM SEMANTIC_VIEW(BANK_DEMO.SEMANTIC.RETAIL_BANKING_SV
        METRICS loan_position.outstanding_principal, loan_position.borrowers
        DIMENSIONS loan_position.maturity_bucket
        WHERE calendar.month_end_date = '2026-09-30')
),
complaints AS (
    SELECT LISTAGG(complaints::STRING, ' -> ') WITHIN GROUP (ORDER BY interaction_month) AS trend
    FROM SEMANTIC_VIEW(BANK_DEMO.SEMANTIC.RETAIL_BANKING_SV
        METRICS interaction.complaints DIMENSIONS interaction.interaction_month, interaction.channel
        WHERE interaction.channel = 'Contact centre' AND interaction.interaction_month >= '2026-08-01')
),
ont AS (SELECT PARSE_JSON(SYSTEM$GET_GLOSSARY_SUMMARY()) AS s),
checks AS (
    SELECT 'Row counts (800/4/663/5465/248/1912/16/32035)' AS check_name,
           (SELECT COUNT(*) FROM BANK_DEMO.SILVER.PARTY) = 800
       AND (SELECT COUNT(*) FROM BANK_DEMO.SILVER.RELATIONSHIP_MANAGER) = 4
       AND (SELECT COUNT(*) FROM BANK_DEMO.SILVER.CURRENT_ACCOUNT_ARRANGEMENT) = 663
       AND (SELECT COUNT(*) FROM BANK_DEMO.SILVER.CURRENT_ACCOUNT_BALANCE_SNAPSHOT) = 5465
       AND (SELECT COUNT(*) FROM BANK_DEMO.SILVER.LOAN_ARRANGEMENT) = 248
       AND (SELECT COUNT(*) FROM BANK_DEMO.SILVER.LOAN_POSITION_SNAPSHOT) = 1912
       AND (SELECT COUNT(*) FROM BANK_DEMO.SILVER.MONTH_END_CALENDAR) = 16
       AND (SELECT COUNT(*) FROM BANK_DEMO.SILVER.CUSTOMER_INTERACTION) = 32035 AS ok,
           NULL AS detail
    UNION ALL
    SELECT 'NPL ratio Sep-26 = 4.03% (SV = raw)',
           ROUND(sv.npl_ratio, 4) = 0.0403 AND ABS(sv.npl_ratio - raw_loans.npl / raw_loans.principal) < 1e-9,
           TO_VARCHAR(ROUND(sv.npl_ratio * 100, 2)) || '%'
    FROM sv, raw_loans
    UNION ALL
    SELECT 'Loan-to-deposit Sep-26 = 40.36% (SV = raw)',
           ROUND(sv.loan_to_deposit_ratio, 4) = 0.4036 AND ABS(sv.loan_to_deposit_ratio - raw_loans.principal / raw_dep.deposits) < 1e-9,
           TO_VARCHAR(ROUND(sv.loan_to_deposit_ratio * 100, 2)) || '%'
    FROM sv, raw_loans, raw_dep
    UNION ALL
    SELECT 'Deposits Sep-26 = 16,303,946 and principal = 6,579,562',
           ROUND(sv.total_deposits) = 16303946 AND ROUND(sv.outstanding_principal) = 6579562,
           TO_VARCHAR(ROUND(sv.total_deposits)) || ' / ' || TO_VARCHAR(ROUND(sv.outstanding_principal))
    FROM sv
    UNION ALL
    SELECT 'Active customers Sep-26 = 598 (SV = raw)',
           sv.active_customers = 598 AND raw_active.n = 598, TO_VARCHAR(sv.active_customers)
    FROM sv, raw_active
    UNION ALL
    SELECT 'Customers over £120k = 41, top £257,022', n = 41 AND ROUND(top) = 257022, n || ' / ' || ROUND(top)
    FROM over_120k
    UNION ALL
    SELECT 'Maturity profile (principal/borrowers)',
           profile = '390858/33 624964/47 1702827/63 2819301/95 1041613/10', profile
    FROM maturity
    UNION ALL
    SELECT 'Contact-centre complaints Aug -> Sep = 48 -> 184', trend = '48 -> 184', trend
    FROM complaints
    UNION ALL
    SELECT 'Ontology baseline: 5 domains, 23 active, 1 draft, 29 relationships, 33 representations',
           s:domainCount::INT >= 5 AND s:activeTermCount::INT >= 23 AND s:draftTermCount::INT >= 1
       AND s:relationshipCount::INT >= 29 AND s:associationCount::INT >= 33,
           s:domainCount::STRING || ' / ' || s:activeTermCount::STRING || ' / ' || s:draftTermCount::STRING || ' / ' ||
           s:relationshipCount::STRING || ' / ' || s:associationCount::STRING
    FROM ont
)
SELECT IFF(ok, 'PASS', 'FAIL') AS result, check_name, detail FROM checks;

-- 2. Relationship manager persona (Sarah Collins): her book only, full names
EXECUTE USING POLICY_CONTEXT(CURRENT_ROLE => 'BANK_RM') AS
WITH b AS (
    SELECT party_name, total_deposits FROM SEMANTIC_VIEW(BANK_DEMO.SEMANTIC.RETAIL_BANKING_SV
        METRICS account_balance.total_deposits DIMENSIONS party.party_name
        WHERE calendar.month_end_date = '2026-09-30')
),
t AS (
    SELECT total_deposits, outstanding_principal FROM SEMANTIC_VIEW(BANK_DEMO.SEMANTIC.RETAIL_BANKING_SV
        METRICS account_balance.total_deposits, loan_position.outstanding_principal
        DIMENSIONS calendar.month_end_date WHERE calendar.month_end_date = '2026-09-30')
)
SELECT IFF(ROUND(t.total_deposits) = 3924640 AND ROUND(t.outstanding_principal) = 1085229
           AND (SELECT COUNT(*) FROM BANK_DEMO.SILVER.PARTY) = 345
           AND (SELECT COUNT(*) FROM b WHERE total_deposits > 120000) = 0
           AND (SELECT COUNT(*) FROM b WHERE total_deposits > 50000) = 30
           AND (SELECT MAX_BY(party_name, total_deposits) FROM b) = 'Grace Thompson', 'PASS', 'FAIL') AS result,
       'BANK_RM: 345 customers, £3,924,640 deposits, £1,085,229 loans, 0 over £120k, 30 over £50k (top Grace Thompson)' AS check_name,
       ROUND(t.total_deposits) || ' / ' || ROUND(t.outstanding_principal) AS detail
FROM t;

-- 3. Head of Lending persona: whole bank, names masked to initials + id
EXECUTE USING POLICY_CONTEXT(CURRENT_ROLE => 'BANK_HEAD_OF_LENDING') AS
SELECT IFF((SELECT COUNT(*) FROM BANK_DEMO.SILVER.PARTY) = 800
           AND (SELECT ROUND(SUM(ledger_balance_gbp)) FROM BANK_DEMO.SILVER.CURRENT_ACCOUNT_BALANCE_SNAPSHOT WHERE snapshot_date = '2026-09-30') = 16303946
           AND (SELECT party_name FROM BANK_DEMO.SILVER.PARTY WHERE party_id = 'PTY-000549') = 'P. D. P. (PTY-000549)', 'PASS', 'FAIL') AS result,
       'BANK_HEAD_OF_LENDING: 800 customers, £16,303,946 deposits, names masked' AS check_name,
       (SELECT party_name FROM BANK_DEMO.SILVER.PARTY WHERE party_id = 'PTY-000549') AS detail;
