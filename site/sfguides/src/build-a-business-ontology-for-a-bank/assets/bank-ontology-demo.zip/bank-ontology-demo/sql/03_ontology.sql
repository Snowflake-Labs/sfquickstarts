-- 03_ontology.sql: Business Ontology for the demo bank (5 domains).
-- Requires Business Ontology (Private Preview) on the account and a role that can create
-- ontology domains (ACCOUNTADMIN by default).
-- Run the whole file in one session: ids are carried in session variables.

-- 0. Pre-flight. The ontology is account-wide, so domain names must be free. Stops before anything is created.
-- Each domain description ends with [bank-ontology-demo]: reset/99_teardown.sql only deletes domains with that marker.
EXECUTE IMMEDIATE $$
DECLARE
  clash VARCHAR;
  ontology_not_enabled EXCEPTION (-20001, 'Business Ontology is not enabled on this account. It is in private preview: ask your Snowflake account team to enable it, then run this script again.');
  domain_exists EXCEPTION (-20002, 'A domain this demo creates already exists in this account: Customer, Current Account, Consumer Loan, Regulatory Reporting or Customer Engagement. If it comes from an earlier install of this demo, run reset/99_teardown.sql first. Otherwise rename the domains in 03_ontology.sql, 04_agents.sql and 05_governance.sql.');
BEGIN
  BEGIN
    SELECT LISTAGG(d.value:name::VARCHAR, ', ') INTO :clash
      FROM TABLE(FLATTEN(INPUT => PARSE_JSON(SYSTEM$GET_GLOSSARY_SUMMARY()):domains)) d
     WHERE d.value:name::VARCHAR IN ('Customer', 'Current Account', 'Consumer Loan', 'Regulatory Reporting', 'Customer Engagement');
  EXCEPTION
    WHEN OTHER THEN RAISE ontology_not_enabled;
  END;
  IF (clash IS NOT NULL AND clash <> '') THEN
    RAISE domain_exists;
  END IF;
  RETURN 'Pre-flight passed: Business Ontology is enabled and the five demo domain names are free.';
END;
$$;

-- 1. Domains
SET d_customer = (SELECT PARSE_JSON(SYSTEM$CREATE_GLOSSARY_DOMAIN('Customer', 'Who our customers are (identifiers, segment, KYC). Steward: Customer Data Owner. System of record: CRM. [bank-ontology-demo]')):domainId::STRING);
SET d_current_account = (SELECT PARSE_JSON(SYSTEM$CREATE_GLOSSARY_DOMAIN('Current Account', 'Current account arrangements and deposit balances. Steward: Deposits Product Owner. System of record: core banking platform. [bank-ontology-demo]')):domainId::STRING);
SET d_consumer_loan = (SELECT PARSE_JSON(SYSTEM$CREATE_GLOSSARY_DOMAIN('Consumer Loan', 'Consumer and corporate loan arrangements, principal and arrears. Steward: Lending Product Owner. System of record: core banking platform. [bank-ontology-demo]')):domainId::STRING);
SET d_regulatory_reporting = (SELECT PARSE_JSON(SYSTEM$CREATE_GLOSSARY_DOMAIN('Regulatory Reporting', 'Governed prudential ratios and reporting conventions. Steward: Finance and Risk Reporting. [bank-ontology-demo]')):domainId::STRING);
SET d_customer_engagement = (SELECT PARSE_JSON(SYSTEM$CREATE_GLOSSARY_DOMAIN('Customer Engagement', 'How customers interact with the bank across digital and assisted channels, and what they complain about. Steward: Channels and Service Owner. Systems of record: channel platforms. [bank-ontology-demo]')):domainId::STRING);

-- 2. Nodes (draft). Every node below except the DRAFT ones is approved in step 3.
-- Customer.Active Customer (METRIC)
SET t_customer_active_customer = (SELECT PARSE_JSON(SYSTEM$DRAFT_GLOSSARY_TERM('{"name": "Active Customer", "domainName": "Customer", "itemKind": "METRIC", "description": "Number of distinct Customers with KYC Status VERIFIED that hold at least one open Current Account at the reporting month end. Customers holding only a loan, or with PENDING or EXPIRED KYC, are not active customers.", "synonyms": ["Active Customers"], "sourceType": "MANUAL", "formula": "COUNT(DISTINCT party_id) WHERE kyc_status = ''VERIFIED'' AND current account open at month end GROUP BY month_end_date", "formulaSource": "BANK_DEMO.SEMANTIC.RETAIL_BANKING_SV"}')):termId::STRING);
-- Customer.Customer (ENTITY)
SET t_customer_customer = (SELECT PARSE_JSON(SYSTEM$DRAFT_GLOSSARY_TERM('{"name": "Customer", "domainName": "Customer", "itemKind": "ENTITY", "description": "A person or organisation that the bank has, or may have, a relationship with. A Customer holds products such as a Current Account or a Loan. System of record: CRM.", "synonyms": ["Client", "Counterparty"], "sourceType": "MANUAL"}')):termId::STRING);
-- Customer.Customer Identifier (TERM)
SET t_customer_customer_identifier = (SELECT PARSE_JSON(SYSTEM$DRAFT_GLOSSARY_TERM('{"name": "Customer Identifier", "domainName": "Customer", "itemKind": "TERM", "description": "The bank-assigned key that uniquely identifies a Customer across all systems (format PTY-nnnnnn). The CRM Account Id is kept only as a source record id and must not be used to join across systems.", "synonyms": ["Customer ID", "Customer Number"], "sourceType": "MANUAL"}')):termId::STRING);
-- Customer.Customer Segment (TERM)
SET t_customer_customer_segment = (SELECT PARSE_JSON(SYSTEM$DRAFT_GLOSSARY_TERM('{"name": "Customer Segment", "domainName": "Customer", "itemKind": "TERM", "description": "Commercial grouping assigned to a Customer at onboarding. Allowed values: RETAIL, PREMIER, SME. SME customers are organisations; RETAIL and PREMIER customers are individuals.", "synonyms": ["Segment", "Customer Tier"], "sourceType": "MANUAL"}')):termId::STRING);
-- Customer.KYC Status (TERM)
SET t_customer_kyc_status = (SELECT PARSE_JSON(SYSTEM$DRAFT_GLOSSARY_TERM('{"name": "KYC Status", "domainName": "Customer", "itemKind": "TERM", "description": "Outcome of Know Your Customer checks on a Customer. Allowed values: VERIFIED, PENDING, EXPIRED. Only a VERIFIED Customer counts as an Active Customer.", "synonyms": ["KYC", "Know Your Customer Status"], "sourceType": "MANUAL"}')):termId::STRING);
-- Customer.Relationship Manager (ENTITY)
SET t_customer_relationship_manager = (SELECT PARSE_JSON(SYSTEM$DRAFT_GLOSSARY_TERM('{"name": "Relationship Manager", "domainName": "Customer", "itemKind": "ENTITY", "description": "A member of staff who owns a book of Customers and is their named contact. Every Customer is assigned to exactly one Relationship Manager: SME customers to the Business Banking team, Retail and Premier customers to the Personal & Premier team. A Relationship Manager sees only the…", "synonyms": ["RM", "Banker", "Account Manager"], "sourceType": "MANUAL"}')):termId::STRING);
-- Current Account.Current Account (ENTITY)
SET t_current_account_current_account = (SELECT PARSE_JSON(SYSTEM$DRAFT_GLOSSARY_TERM('{"name": "Current Account", "domainName": "Current Account", "itemKind": "ENTITY", "description": "A GBP current account that the bank provides to a Customer. An account is open from its opened date until its closed date. System of record: core banking platform.", "synonyms": ["Deposit Account", "CASA"], "sourceType": "MANUAL"}')):termId::STRING);
-- Current Account.Total Deposits (METRIC)
SET t_current_account_total_deposits = (SELECT PARSE_JSON(SYSTEM$DRAFT_GLOSSARY_TERM('{"name": "Total Deposits", "domainName": "Current Account", "itemKind": "METRIC", "description": "Sum of month-end ledger balances across all open Current Accounts, in GBP. Semi-additive: always take the balance at one reporting month end and never sum balances across dates. A Customer''s balance is their Total Deposits at one month end: the sum across their open Current Accounts.", "synonyms": ["Customer Deposits", "Deposit Balances", "Deposits", "Balance", "Balances", "Customer Balance"], "sourceType": "MANUAL", "formula": "SUM(ledger_balance_gbp) GROUP BY month_end_date", "formulaSource": "BANK_DEMO.SEMANTIC.RETAIL_BANKING_SV"}')):termId::STRING);
-- Consumer Loan.Borrowers (METRIC)
SET t_consumer_loan_borrowers = (SELECT PARSE_JSON(SYSTEM$DRAFT_GLOSSARY_TERM('{"name": "Borrowers", "domainName": "Consumer Loan", "itemKind": "METRIC", "description": "Number of distinct Customers holding at least one Loan with outstanding principal at the reporting month end. Semi-additive: never sum across dates.", "synonyms": ["Borrowing Customers", "Customers With Loans"], "sourceType": "MANUAL", "formula": "COUNT(DISTINCT party_id WHERE outstanding_principal_gbp > 0) GROUP BY month_end_date", "formulaSource": "BANK_DEMO.SEMANTIC.RETAIL_BANKING_SV"}')):termId::STRING);
-- Consumer Loan.Days Past Due (TERM)
SET t_consumer_loan_days_past_due = (SELECT PARSE_JSON(SYSTEM$DRAFT_GLOSSARY_TERM('{"name": "Days Past Due", "domainName": "Consumer Loan", "itemKind": "TERM", "description": "Number of days the oldest scheduled repayment on a Loan is overdue at the reporting month end. Zero means the loan is up to date.", "synonyms": ["DPD", "Arrears Days", "Days in Arrears"], "sourceType": "MANUAL"}')):termId::STRING);
-- Consumer Loan.Loan (ENTITY)
SET t_consumer_loan_loan = (SELECT PARSE_JSON(SYSTEM$DRAFT_GLOSSARY_TERM('{"name": "Loan", "domainName": "Consumer Loan", "itemKind": "ENTITY", "description": "Principal that the bank lends to a Customer, repayable over a fixed term. Covers consumer loans (Personal Loan, individuals) and corporate loans (SME Term Loan, organisations). System of record: core banking platform.", "synonyms": ["Lending Facility", "Credit Facility"], "sourceType": "MANUAL"}')):termId::STRING);
-- Consumer Loan.Maturity Date (TERM)
SET t_consumer_loan_maturity_date = (SELECT PARSE_JSON(SYSTEM$DRAFT_GLOSSARY_TERM('{"name": "Maturity Date", "domainName": "Consumer Loan", "itemKind": "TERM", "description": "The date on which the final repayment of a Loan is due: the origination date plus the contractual term in months.", "synonyms": ["Final Repayment Date", "Loan End Date"], "sourceType": "MANUAL"}')):termId::STRING);
-- Consumer Loan.Outstanding Principal (METRIC)
SET t_consumer_loan_outstanding_principal = (SELECT PARSE_JSON(SYSTEM$DRAFT_GLOSSARY_TERM('{"name": "Outstanding Principal", "domainName": "Consumer Loan", "itemKind": "METRIC", "description": "Unpaid principal across all Loans at the reporting month end, in GBP, before provisions. Semi-additive: never sum across dates.", "synonyms": ["Gross Loans", "Loan Book", "Loans Outstanding", "Loan Portfolio", "Lending Book"], "sourceType": "MANUAL", "formula": "SUM(outstanding_principal_gbp) GROUP BY month_end_date", "formulaSource": "BANK_DEMO.SEMANTIC.RETAIL_BANKING_SV"}')):termId::STRING);
-- Consumer Loan.Residual Maturity Bucket (TERM)
SET t_consumer_loan_residual_maturity_bucket = (SELECT PARSE_JSON(SYSTEM$DRAFT_GLOSSARY_TERM('{"name": "Residual Maturity Bucket", "domainName": "Consumer Loan", "itemKind": "TERM", "description": "The time remaining from a Reporting Month End to a Loan''s Maturity Date, in bands: Under 1 year, 1-2 years, 2-3 years, 3-5 years and Over 5 years (Matured if the date has passed). Used for the maturity profile of the loan book. Measured from the reporting month end, not from toda…", "synonyms": ["Maturity Profile", "Maturity Band", "Time to Maturity", "Loan Maturity", "Maturity"], "sourceType": "MANUAL"}')):termId::STRING);
-- Regulatory Reporting.Loan-to-Deposit Ratio (METRIC)
SET t_regulatory_reporting_loan_to_deposit_ratio = (SELECT PARSE_JSON(SYSTEM$DRAFT_GLOSSARY_TERM('{"name": "Loan-to-Deposit Ratio", "domainName": "Regulatory Reporting", "itemKind": "METRIC", "description": "Outstanding Principal divided by Total Deposits at the same reporting month end. Indicates how much of the deposit base is lent out.", "synonyms": ["LDR", "Loan to Deposit Ratio"], "sourceType": "MANUAL", "formula": "SUM(outstanding_principal_gbp) / SUM(ledger_balance_gbp) GROUP BY month_end_date", "formulaSource": "BANK_DEMO.SEMANTIC.RETAIL_BANKING_SV"}')):termId::STRING);
-- Regulatory Reporting.NPL Ratio (METRIC)
SET t_regulatory_reporting_npl_ratio = (SELECT PARSE_JSON(SYSTEM$DRAFT_GLOSSARY_TERM('{"name": "NPL Ratio", "domainName": "Regulatory Reporting", "itemKind": "METRIC", "description": "Outstanding Principal on Non-Performing Loans divided by total Outstanding Principal, at one reporting month end.", "synonyms": ["Non-Performing Loan Ratio", "NPL Rate"], "sourceType": "MANUAL", "formula": "SUM(outstanding_principal_gbp WHERE days_past_due >= 90) / SUM(outstanding_principal_gbp) GROUP BY month_end_date", "formulaSource": "BANK_DEMO.SEMANTIC.RETAIL_BANKING_SV"}')):termId::STRING);
-- Regulatory Reporting.Non-Performing Loan (TERM)
SET t_regulatory_reporting_non_performing_loan = (SELECT PARSE_JSON(SYSTEM$DRAFT_GLOSSARY_TERM('{"name": "Non-Performing Loan", "domainName": "Regulatory Reporting", "itemKind": "TERM", "description": "A Loan that is 90 or more Days Past Due at the reporting month end. Demo simplification: the full prudential non-performing exposure definition also includes unlikely-to-pay exposures, which are not modelled here.", "synonyms": ["NPL", "Defaulted Loan"], "sourceType": "MANUAL"}')):termId::STRING);
-- Regulatory Reporting.Reporting Month End (TERM)
SET t_regulatory_reporting_reporting_month_end = (SELECT PARSE_JSON(SYSTEM$DRAFT_GLOSSARY_TERM('{"name": "Reporting Month End", "domainName": "Regulatory Reporting", "itemKind": "TERM", "description": "The last calendar day of a month, used as the as-at date for every balance and position the bank reports. When no date is given, use the latest closed month end.", "synonyms": ["Month End", "As At Date", "Snapshot Date", "Reporting Date"], "sourceType": "MANUAL"}')):termId::STRING);
-- Customer Engagement.Channel (TERM)
SET t_customer_engagement_channel = (SELECT PARSE_JSON(SYSTEM$DRAFT_GLOSSARY_TERM('{"name": "Channel", "domainName": "Customer Engagement", "itemKind": "TERM", "description": "The route a Customer Interaction takes. Digital channels: Mobile app and Online banking. Assisted channels: Branch and Contact centre.", "synonyms": ["Touchpoint", "Digital vs Assisted"], "sourceType": "MANUAL"}')):termId::STRING);
-- Customer Engagement.Complaint (TERM)
SET t_customer_engagement_complaint = (SELECT PARSE_JSON(SYSTEM$DRAFT_GLOSSARY_TERM('{"name": "Complaint", "domainName": "Customer Engagement", "itemKind": "TERM", "description": "A Customer Interaction in which the Customer expresses dissatisfaction with a product or service, recorded with interaction type Complaint.", "synonyms": ["Customer Complaint"], "sourceType": "MANUAL"}')):termId::STRING);
-- Customer Engagement.Complaint Rate (METRIC)
SET t_customer_engagement_complaint_rate = (SELECT PARSE_JSON(SYSTEM$DRAFT_GLOSSARY_TERM('{"name": "Complaint Rate", "domainName": "Customer Engagement", "itemKind": "METRIC", "description": "Complaints as a share of all Customer Interactions, for one Channel and period. A rising rate on one Channel is an early conduct and service warning.", "synonyms": ["Complaints Per Interaction"], "sourceType": "MANUAL", "formula": "SUM(IFF(interaction_type = ''Complaint'', 1, 0)) / COUNT(interaction_id) GROUP BY channel, interaction_month", "formulaSource": "BANK_DEMO.SEMANTIC.RETAIL_BANKING_SV"}')):termId::STRING);
-- Customer Engagement.Customer Interaction (ENTITY)
SET t_customer_engagement_customer_interaction = (SELECT PARSE_JSON(SYSTEM$DRAFT_GLOSSARY_TERM('{"name": "Customer Interaction", "domainName": "Customer Engagement", "itemKind": "ENTITY", "description": "A single contact between a Customer and the bank through a Channel: a login, payment, enquiry, product application or complaint.", "synonyms": ["Interaction", "Visit", "Visits", "Customer Activity", "Activity", "Contact"], "sourceType": "MANUAL"}')):termId::STRING);
-- Customer Engagement.Digital Share (METRIC)
SET t_customer_engagement_digital_share = (SELECT PARSE_JSON(SYSTEM$DRAFT_GLOSSARY_TERM('{"name": "Digital Share", "domainName": "Customer Engagement", "itemKind": "METRIC", "description": "Share of Customer Interactions made through Digital Channels (Mobile app and Online banking) in a period.", "synonyms": ["Digital Adoption"], "sourceType": "MANUAL", "formula": "SUM(IFF(channel IN (''Mobile app'', ''Online banking''), 1, 0)) / COUNT(interaction_id) GROUP BY interaction_month", "formulaSource": "BANK_DEMO.SEMANTIC.RETAIL_BANKING_SV"}')):termId::STRING);
-- Regulatory Reporting.Net Interest Margin (METRIC) -- stays DRAFT
SET t_regulatory_reporting_net_interest_margin = (SELECT PARSE_JSON(SYSTEM$DRAFT_GLOSSARY_TERM('{"name": "Net Interest Margin", "domainName": "Regulatory Reporting", "itemKind": "METRIC", "description": "Net interest income divided by average interest-earning assets, annualised. PROPOSED: not yet reviewed by Finance; no implementation exists yet.", "synonyms": ["NIM"], "sourceType": "MANUAL", "formula": "(interest_income - interest_expense) / AVG(interest_earning_assets)"}')):termId::STRING);

-- 3. Approve (the steward step)
SELECT SYSTEM$APPROVE_GLOSSARY_TERM($t_customer_active_customer);
SELECT SYSTEM$APPROVE_GLOSSARY_TERM($t_customer_customer);
SELECT SYSTEM$APPROVE_GLOSSARY_TERM($t_customer_customer_identifier);
SELECT SYSTEM$APPROVE_GLOSSARY_TERM($t_customer_customer_segment);
SELECT SYSTEM$APPROVE_GLOSSARY_TERM($t_customer_kyc_status);
SELECT SYSTEM$APPROVE_GLOSSARY_TERM($t_customer_relationship_manager);
SELECT SYSTEM$APPROVE_GLOSSARY_TERM($t_current_account_current_account);
SELECT SYSTEM$APPROVE_GLOSSARY_TERM($t_current_account_total_deposits);
SELECT SYSTEM$APPROVE_GLOSSARY_TERM($t_consumer_loan_borrowers);
SELECT SYSTEM$APPROVE_GLOSSARY_TERM($t_consumer_loan_days_past_due);
SELECT SYSTEM$APPROVE_GLOSSARY_TERM($t_consumer_loan_loan);
SELECT SYSTEM$APPROVE_GLOSSARY_TERM($t_consumer_loan_maturity_date);
SELECT SYSTEM$APPROVE_GLOSSARY_TERM($t_consumer_loan_outstanding_principal);
SELECT SYSTEM$APPROVE_GLOSSARY_TERM($t_consumer_loan_residual_maturity_bucket);
SELECT SYSTEM$APPROVE_GLOSSARY_TERM($t_regulatory_reporting_loan_to_deposit_ratio);
SELECT SYSTEM$APPROVE_GLOSSARY_TERM($t_regulatory_reporting_npl_ratio);
SELECT SYSTEM$APPROVE_GLOSSARY_TERM($t_regulatory_reporting_non_performing_loan);
SELECT SYSTEM$APPROVE_GLOSSARY_TERM($t_regulatory_reporting_reporting_month_end);
SELECT SYSTEM$APPROVE_GLOSSARY_TERM($t_customer_engagement_channel);
SELECT SYSTEM$APPROVE_GLOSSARY_TERM($t_customer_engagement_complaint);
SELECT SYSTEM$APPROVE_GLOSSARY_TERM($t_customer_engagement_complaint_rate);
SELECT SYSTEM$APPROVE_GLOSSARY_TERM($t_customer_engagement_customer_interaction);
SELECT SYSTEM$APPROVE_GLOSSARY_TERM($t_customer_engagement_digital_share);

-- 4. Relationships (direct-create, ACTIVE)
SELECT SYSTEM$CREATE_GLOSSARY_RELATIONSHIP($t_current_account_total_deposits, $t_current_account_current_account, 'MEASURES', '', 'MANUAL');
SELECT SYSTEM$CREATE_GLOSSARY_RELATIONSHIP($t_consumer_loan_residual_maturity_bucket, $t_consumer_loan_loan, 'CLASSIFIES', '', 'MANUAL');
SELECT SYSTEM$CREATE_GLOSSARY_RELATIONSHIP($t_customer_customer, $t_customer_engagement_customer_interaction, 'CUSTOM', 'has', 'MANUAL');
SELECT SYSTEM$CREATE_GLOSSARY_RELATIONSHIP($t_regulatory_reporting_reporting_month_end, $t_current_account_total_deposits, 'SCOPES', '', 'MANUAL');
SELECT SYSTEM$CREATE_GLOSSARY_RELATIONSHIP($t_customer_engagement_channel, $t_customer_engagement_digital_share, 'DERIVES', '', 'MANUAL');
SELECT SYSTEM$CREATE_GLOSSARY_RELATIONSHIP($t_regulatory_reporting_reporting_month_end, $t_consumer_loan_borrowers, 'SCOPES', '', 'MANUAL');
SELECT SYSTEM$CREATE_GLOSSARY_RELATIONSHIP($t_current_account_total_deposits, $t_regulatory_reporting_loan_to_deposit_ratio, 'DERIVES', '', 'MANUAL');
SELECT SYSTEM$CREATE_GLOSSARY_RELATIONSHIP($t_customer_active_customer, $t_customer_customer, 'MEASURES', '', 'MANUAL');
SELECT SYSTEM$CREATE_GLOSSARY_RELATIONSHIP($t_consumer_loan_days_past_due, $t_regulatory_reporting_non_performing_loan, 'DERIVES', '', 'MANUAL');
SELECT SYSTEM$CREATE_GLOSSARY_RELATIONSHIP($t_customer_customer_segment, $t_customer_customer, 'CLASSIFIES', '', 'MANUAL');
SELECT SYSTEM$CREATE_GLOSSARY_RELATIONSHIP($t_customer_engagement_channel, $t_customer_engagement_customer_interaction, 'CLASSIFIES', '', 'MANUAL');
SELECT SYSTEM$CREATE_GLOSSARY_RELATIONSHIP($t_customer_kyc_status, $t_customer_customer, 'CLASSIFIES', '', 'MANUAL');
SELECT SYSTEM$CREATE_GLOSSARY_RELATIONSHIP($t_regulatory_reporting_reporting_month_end, $t_consumer_loan_residual_maturity_bucket, 'SCOPES', '', 'MANUAL');
SELECT SYSTEM$CREATE_GLOSSARY_RELATIONSHIP($t_customer_engagement_complaint, $t_customer_engagement_complaint_rate, 'DERIVES', '', 'MANUAL');
SELECT SYSTEM$CREATE_GLOSSARY_RELATIONSHIP($t_consumer_loan_outstanding_principal, $t_regulatory_reporting_loan_to_deposit_ratio, 'DERIVES', '', 'MANUAL');
SELECT SYSTEM$CREATE_GLOSSARY_RELATIONSHIP($t_consumer_loan_maturity_date, $t_consumer_loan_residual_maturity_bucket, 'DERIVES', '', 'MANUAL');
SELECT SYSTEM$CREATE_GLOSSARY_RELATIONSHIP($t_regulatory_reporting_non_performing_loan, $t_regulatory_reporting_npl_ratio, 'DERIVES', '', 'MANUAL');
SELECT SYSTEM$CREATE_GLOSSARY_RELATIONSHIP($t_regulatory_reporting_non_performing_loan, $t_consumer_loan_loan, 'CLASSIFIES', '', 'MANUAL');
SELECT SYSTEM$CREATE_GLOSSARY_RELATIONSHIP($t_consumer_loan_outstanding_principal, $t_regulatory_reporting_npl_ratio, 'DERIVES', '', 'MANUAL');
SELECT SYSTEM$CREATE_GLOSSARY_RELATIONSHIP($t_customer_engagement_customer_interaction, $t_customer_engagement_complaint_rate, 'DERIVES', '', 'MANUAL');
SELECT SYSTEM$CREATE_GLOSSARY_RELATIONSHIP($t_customer_customer, $t_customer_customer_identifier, 'IDENTIFIED_BY', '', 'MANUAL');
SELECT SYSTEM$CREATE_GLOSSARY_RELATIONSHIP($t_customer_customer, $t_current_account_current_account, 'CUSTOM', 'holds', 'MANUAL');
SELECT SYSTEM$CREATE_GLOSSARY_RELATIONSHIP($t_consumer_loan_outstanding_principal, $t_consumer_loan_loan, 'MEASURES', '', 'MANUAL');
SELECT SYSTEM$CREATE_GLOSSARY_RELATIONSHIP($t_customer_relationship_manager, $t_customer_customer, 'CUSTOM', 'manages', 'MANUAL');
SELECT SYSTEM$CREATE_GLOSSARY_RELATIONSHIP($t_regulatory_reporting_reporting_month_end, $t_consumer_loan_outstanding_principal, 'SCOPES', '', 'MANUAL');
SELECT SYSTEM$CREATE_GLOSSARY_RELATIONSHIP($t_customer_engagement_complaint, $t_customer_engagement_customer_interaction, 'CLASSIFIES', '', 'MANUAL');
SELECT SYSTEM$CREATE_GLOSSARY_RELATIONSHIP($t_consumer_loan_borrowers, $t_customer_customer, 'MEASURES', '', 'MANUAL');
SELECT SYSTEM$CREATE_GLOSSARY_RELATIONSHIP($t_customer_engagement_customer_interaction, $t_customer_engagement_digital_share, 'DERIVES', '', 'MANUAL');
SELECT SYSTEM$CREATE_GLOSSARY_RELATIONSHIP($t_customer_customer, $t_consumer_loan_loan, 'CUSTOM', 'holds', 'MANUAL');

-- 5. Representations: bind each node to the objects that implement it
SELECT SYSTEM$CREATE_GLOSSARY_ASSOCIATION($t_consumer_loan_outstanding_principal, '{"refType": "SEMANTIC_VIEW", "fqn": "BANK_DEMO.SEMANTIC.RETAIL_BANKING_SV", "subObjectType": "METRIC", "entityQualifier": "LOAN_POSITION", "subObjectName": "OUTSTANDING_PRINCIPAL"}', 'RELATED_SEMANTIC_VIEW', 'MANUAL');
SELECT SYSTEM$CREATE_GLOSSARY_ASSOCIATION($t_consumer_loan_maturity_date, '{"refType": "SEMANTIC_VIEW", "fqn": "BANK_DEMO.SEMANTIC.RETAIL_BANKING_SV", "subObjectType": "DIMENSION", "entityQualifier": "LOAN", "subObjectName": "MATURITY_DATE"}', 'RELATED_SEMANTIC_VIEW', 'MANUAL');
SELECT SYSTEM$CREATE_GLOSSARY_ASSOCIATION($t_customer_kyc_status, '{"refType": "COLUMN", "fqn": "BANK_DEMO.SILVER.PARTY", "dimensionName": "KYC_STATUS"}', 'DESCRIBES', 'MANUAL');
SELECT SYSTEM$CREATE_GLOSSARY_ASSOCIATION($t_customer_relationship_manager, '{"refType": "SEMANTIC_VIEW", "fqn": "BANK_DEMO.SEMANTIC.RETAIL_BANKING_SV", "subObjectType": "ENTITY", "subObjectName": "RELATIONSHIP_MANAGER"}', 'RELATED_SEMANTIC_VIEW', 'MANUAL');
SELECT SYSTEM$CREATE_GLOSSARY_ASSOCIATION($t_current_account_current_account, '{"refType": "TABLE", "fqn": "BANK_DEMO.SILVER.CURRENT_ACCOUNT_ARRANGEMENT", "objectName": "CURRENT_ACCOUNT_ARRANGEMENT"}', 'DESCRIBES', 'MANUAL');
SELECT SYSTEM$CREATE_GLOSSARY_ASSOCIATION($t_current_account_current_account, '{"refType": "SEMANTIC_VIEW", "fqn": "BANK_DEMO.SEMANTIC.RETAIL_BANKING_SV", "subObjectType": "ENTITY", "subObjectName": "CURRENT_ACCOUNT"}', 'RELATED_SEMANTIC_VIEW', 'MANUAL');
SELECT SYSTEM$CREATE_GLOSSARY_ASSOCIATION($t_regulatory_reporting_reporting_month_end, '{"refType": "SEMANTIC_VIEW", "fqn": "BANK_DEMO.SEMANTIC.RETAIL_BANKING_SV", "subObjectType": "DIMENSION", "entityQualifier": "CALENDAR", "subObjectName": "MONTH_END_DATE"}', 'RELATED_SEMANTIC_VIEW', 'MANUAL');
SELECT SYSTEM$CREATE_GLOSSARY_ASSOCIATION($t_customer_engagement_customer_interaction, '{"refType": "TABLE", "fqn": "BANK_DEMO.SILVER.CUSTOMER_INTERACTION", "objectName": "CUSTOMER_INTERACTION"}', 'DESCRIBES', 'MANUAL');
SELECT SYSTEM$CREATE_GLOSSARY_ASSOCIATION($t_customer_customer, '{"refType": "SEMANTIC_VIEW", "fqn": "BANK_DEMO.SEMANTIC.RETAIL_BANKING_SV", "subObjectType": "ENTITY", "subObjectName": "PARTY"}', 'RELATED_SEMANTIC_VIEW', 'MANUAL');
SELECT SYSTEM$CREATE_GLOSSARY_ASSOCIATION($t_consumer_loan_loan, '{"refType": "TABLE", "fqn": "BANK_DEMO.SILVER.LOAN_ARRANGEMENT", "objectName": "LOAN_ARRANGEMENT"}', 'DESCRIBES', 'MANUAL');
SELECT SYSTEM$CREATE_GLOSSARY_ASSOCIATION($t_customer_customer_identifier, '{"refType": "COLUMN", "fqn": "BANK_DEMO.SILVER.PARTY", "dimensionName": "PARTY_ID"}', 'DESCRIBES', 'MANUAL');
SELECT SYSTEM$CREATE_GLOSSARY_ASSOCIATION($t_consumer_loan_loan, '{"refType": "SEMANTIC_VIEW", "fqn": "BANK_DEMO.SEMANTIC.RETAIL_BANKING_SV", "subObjectType": "ENTITY", "subObjectName": "LOAN"}', 'RELATED_SEMANTIC_VIEW', 'MANUAL');
SELECT SYSTEM$CREATE_GLOSSARY_ASSOCIATION($t_customer_relationship_manager, '{"refType": "COLUMN", "fqn": "BANK_DEMO.SILVER.PARTY", "dimensionName": "RM_ID"}', 'DESCRIBES', 'MANUAL');
SELECT SYSTEM$CREATE_GLOSSARY_ASSOCIATION($t_customer_engagement_complaint, '{"refType": "COLUMN", "fqn": "BANK_DEMO.SILVER.CUSTOMER_INTERACTION", "dimensionName": "INTERACTION_TYPE"}', 'DESCRIBES', 'MANUAL');
SELECT SYSTEM$CREATE_GLOSSARY_ASSOCIATION($t_consumer_loan_days_past_due, '{"refType": "COLUMN", "fqn": "BANK_DEMO.SILVER.LOAN_POSITION_SNAPSHOT", "dimensionName": "DAYS_PAST_DUE"}', 'DESCRIBES', 'MANUAL');
SELECT SYSTEM$CREATE_GLOSSARY_ASSOCIATION($t_customer_customer_segment, '{"refType": "COLUMN", "fqn": "BANK_DEMO.SILVER.PARTY", "dimensionName": "CUSTOMER_SEGMENT"}', 'DESCRIBES', 'MANUAL');
SELECT SYSTEM$CREATE_GLOSSARY_ASSOCIATION($t_regulatory_reporting_loan_to_deposit_ratio, '{"refType": "SEMANTIC_VIEW", "fqn": "BANK_DEMO.SEMANTIC.RETAIL_BANKING_SV", "subObjectType": "DERIVED_METRIC", "subObjectName": "LOAN_TO_DEPOSIT_RATIO"}', 'RELATED_SEMANTIC_VIEW', 'MANUAL');
SELECT SYSTEM$CREATE_GLOSSARY_ASSOCIATION($t_consumer_loan_residual_maturity_bucket, '{"refType": "SEMANTIC_VIEW", "fqn": "BANK_DEMO.SEMANTIC.RETAIL_BANKING_SV", "subObjectType": "DIMENSION", "entityQualifier": "LOAN_POSITION", "subObjectName": "MATURITY_BUCKET"}', 'RELATED_SEMANTIC_VIEW', 'MANUAL');
SELECT SYSTEM$CREATE_GLOSSARY_ASSOCIATION($t_customer_engagement_channel, '{"refType": "SEMANTIC_VIEW", "fqn": "BANK_DEMO.SEMANTIC.RETAIL_BANKING_SV", "subObjectType": "DIMENSION", "entityQualifier": "INTERACTION", "subObjectName": "CHANNEL"}', 'RELATED_SEMANTIC_VIEW', 'MANUAL');
SELECT SYSTEM$CREATE_GLOSSARY_ASSOCIATION($t_customer_relationship_manager, '{"refType": "TABLE", "fqn": "BANK_DEMO.SILVER.RELATIONSHIP_MANAGER", "objectName": "RELATIONSHIP_MANAGER"}', 'DESCRIBES', 'MANUAL');
SELECT SYSTEM$CREATE_GLOSSARY_ASSOCIATION($t_customer_engagement_complaint_rate, '{"refType": "SEMANTIC_VIEW", "fqn": "BANK_DEMO.SEMANTIC.RETAIL_BANKING_SV", "subObjectType": "DERIVED_METRIC", "subObjectName": "COMPLAINT_RATE"}', 'RELATED_SEMANTIC_VIEW', 'MANUAL');
SELECT SYSTEM$CREATE_GLOSSARY_ASSOCIATION($t_current_account_total_deposits, '{"refType": "SEMANTIC_VIEW", "fqn": "BANK_DEMO.SEMANTIC.RETAIL_BANKING_SV", "subObjectType": "METRIC", "entityQualifier": "ACCOUNT_BALANCE", "subObjectName": "TOTAL_DEPOSITS"}', 'RELATED_SEMANTIC_VIEW', 'MANUAL');
SELECT SYSTEM$CREATE_GLOSSARY_ASSOCIATION($t_consumer_loan_borrowers, '{"refType": "SEMANTIC_VIEW", "fqn": "BANK_DEMO.SEMANTIC.RETAIL_BANKING_SV", "subObjectType": "METRIC", "entityQualifier": "LOAN_POSITION", "subObjectName": "BORROWERS"}', 'RELATED_SEMANTIC_VIEW', 'MANUAL');
SELECT SYSTEM$CREATE_GLOSSARY_ASSOCIATION($t_consumer_loan_maturity_date, '{"refType": "COLUMN", "fqn": "BANK_DEMO.SILVER.LOAN_ARRANGEMENT", "dimensionName": "MATURITY_DATE"}', 'DESCRIBES', 'MANUAL');
SELECT SYSTEM$CREATE_GLOSSARY_ASSOCIATION($t_customer_engagement_channel, '{"refType": "COLUMN", "fqn": "BANK_DEMO.SILVER.CUSTOMER_INTERACTION", "dimensionName": "CHANNEL"}', 'DESCRIBES', 'MANUAL');
SELECT SYSTEM$CREATE_GLOSSARY_ASSOCIATION($t_regulatory_reporting_reporting_month_end, '{"refType": "COLUMN", "fqn": "BANK_DEMO.SILVER.MONTH_END_CALENDAR", "dimensionName": "MONTH_END_DATE"}', 'DESCRIBES', 'MANUAL');
SELECT SYSTEM$CREATE_GLOSSARY_ASSOCIATION($t_consumer_loan_days_past_due, '{"refType": "SEMANTIC_VIEW", "fqn": "BANK_DEMO.SEMANTIC.RETAIL_BANKING_SV", "subObjectType": "DIMENSION", "entityQualifier": "LOAN_POSITION", "subObjectName": "DAYS_PAST_DUE"}', 'RELATED_SEMANTIC_VIEW', 'MANUAL');
SELECT SYSTEM$CREATE_GLOSSARY_ASSOCIATION($t_customer_engagement_digital_share, '{"refType": "SEMANTIC_VIEW", "fqn": "BANK_DEMO.SEMANTIC.RETAIL_BANKING_SV", "subObjectType": "METRIC", "entityQualifier": "INTERACTION", "subObjectName": "DIGITAL_SHARE"}', 'RELATED_SEMANTIC_VIEW', 'MANUAL');
SELECT SYSTEM$CREATE_GLOSSARY_ASSOCIATION($t_customer_engagement_customer_interaction, '{"refType": "SEMANTIC_VIEW", "fqn": "BANK_DEMO.SEMANTIC.RETAIL_BANKING_SV", "subObjectType": "ENTITY", "subObjectName": "INTERACTION"}', 'RELATED_SEMANTIC_VIEW', 'MANUAL');
SELECT SYSTEM$CREATE_GLOSSARY_ASSOCIATION($t_customer_active_customer, '{"refType": "SEMANTIC_VIEW", "fqn": "BANK_DEMO.SEMANTIC.RETAIL_BANKING_SV", "subObjectType": "METRIC", "entityQualifier": "ACCOUNT_BALANCE", "subObjectName": "ACTIVE_CUSTOMERS"}', 'RELATED_SEMANTIC_VIEW', 'MANUAL');
SELECT SYSTEM$CREATE_GLOSSARY_ASSOCIATION($t_customer_customer, '{"refType": "TABLE", "fqn": "BANK_DEMO.SILVER.PARTY", "objectName": null}', 'DESCRIBES', 'MANUAL');
SELECT SYSTEM$CREATE_GLOSSARY_ASSOCIATION($t_regulatory_reporting_npl_ratio, '{"refType": "SEMANTIC_VIEW", "fqn": "BANK_DEMO.SEMANTIC.RETAIL_BANKING_SV", "subObjectType": "DERIVED_METRIC", "subObjectName": "NPL_RATIO"}', 'RELATED_SEMANTIC_VIEW', 'MANUAL');
SELECT SYSTEM$CREATE_GLOSSARY_ASSOCIATION($t_customer_customer_segment, '{"refType": "SEMANTIC_VIEW", "fqn": "BANK_DEMO.SEMANTIC.RETAIL_BANKING_SV", "subObjectType": "DIMENSION", "entityQualifier": "PARTY", "subObjectName": "CUSTOMER_SEGMENT"}', 'RELATED_SEMANTIC_VIEW', 'MANUAL');

-- 6. Read back. Expect: 5 domains, 23 active nodes, 1 draft, 29 relationships, 33 representations.
SELECT SYSTEM$GET_GLOSSARY_SUMMARY();
