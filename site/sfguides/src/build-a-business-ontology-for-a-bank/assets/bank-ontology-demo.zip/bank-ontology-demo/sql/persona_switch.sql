-- persona_switch.sql: switch the demo user between personas for CoWork, saved charts and dashboards.
-- Run ONE block in a Snowsight worksheet, then sign out of CoWork / Snowsight and sign back in (or open CoWork in
-- a fresh private window) so the new default role is picked up. Saved chart artifacts cache a snapshot per
-- viewer: press Refresh on the artifact after switching.
-- The row access policy reads CURRENT_ROLE() (the primary role), so the persona is decided by the default role
-- alone; secondary roles are switched off only to keep the session clean.
SET demo_user = CURRENT_USER();

-- Persona A: Sarah Collins, Relationship Manager (her own book only, full names)
ALTER USER IDENTIFIER($demo_user) SET DEFAULT_ROLE = BANK_RM DEFAULT_SECONDARY_ROLES = () DEFAULT_WAREHOUSE = BANK_DEMO_WH;

-- Persona B: Head of Lending (whole bank, names masked to initials + customer id)
ALTER USER IDENTIFIER($demo_user) SET DEFAULT_ROLE = BANK_HEAD_OF_LENDING DEFAULT_SECONDARY_ROLES = () DEFAULT_WAREHOUSE = BANK_DEMO_WH;

-- Restore after the demo: your own defaults, as saved by 00_setup.sql (reset/99_teardown.sql also does this).
USE ROLE ACCOUNTADMIN;
CALL BANK_DEMO.GOVERNANCE.RESTORE_USER_DEFAULTS();

-- Check which persona you are in (run inside the session you are demoing from)
SELECT CURRENT_ROLE(), CURRENT_SECONDARY_ROLES();
