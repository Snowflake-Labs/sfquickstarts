"""Ask a demo agent questions from SQL (SNOWFLAKE.CORTEX.DATA_AGENT_RUN) and print the tool trace + answer.

Usage:
  python tests/ask_agent.py RETAIL_BANKING_AGENT "What is our NPL ratio, and how is it defined?"
  python tests/ask_agent.py RETAIL_BANKING_AGENT --tour      # the tour questions
  python tests/ask_agent.py RETAIL_BANKING_AGENT --act3      # after the live act
Exit code is non-zero if a run errors.
Auth: SNOWFLAKE_PAT_FILE + SNOWFLAKE_ACCOUNT + SNOWFLAKE_USER (programmatic access token, never printed),
or SNOWFLAKE_CONNECTION_NAME (a connection in ~/.snowflake/connections.toml).
"""
import json
import os
import pathlib
import sys

import snowflake.connector

TOUR = [
    "What is our NPL ratio, and how is it defined?",
    "How many customers do we have by loan maturity?",
    "How many active customers do we have by segment?",
    "What is our Net Interest Margin?",
]
ACT3 = [
    "What is our Net Interest Margin?",
    "Why did Net Interest Margin fall between August and September 2026?",
]


def connect():
    pat_file = os.environ.get("SNOWFLAKE_PAT_FILE")
    if pat_file:
        return snowflake.connector.connect(
            account=os.environ["SNOWFLAKE_ACCOUNT"],
            user=os.environ["SNOWFLAKE_USER"],
            authenticator="PROGRAMMATIC_ACCESS_TOKEN",
            token=pathlib.Path(pat_file).expanduser().read_text().strip(),
        )
    return snowflake.connector.connect(connection_name=os.environ.get("SNOWFLAKE_CONNECTION_NAME", "default"))


def ask(cur, agent, question):
    body = json.dumps({
        "messages": [{"role": "user", "content": [{"type": "text", "text": question}]}],
        "stream": False,
    })
    assert "$$" not in body
    raw = cur.execute(
        f"SELECT SNOWFLAKE.CORTEX.DATA_AGENT_RUN('BANK_DEMO.SEMANTIC.{agent}', $${body}$$)"
    ).fetchone()[0]
    resp = json.loads(raw)
    if resp.get("code") or resp.get("error"):
        return None, [], json.dumps(resp)[:500]
    tools, text = [], []
    for item in resp.get("content", []):
        if item.get("type") == "tool_use":
            tu = item["tool_use"]
            detail = tu.get("input", {}).get("query") or tu.get("input", {}).get("sql") or ""
            tools.append(f"{tu.get('name')}: {str(detail)[:140]}")
        elif item.get("type") == "text":
            text.append(item["text"])
    return "\n".join(text), tools, None


def main():
    agent, rest = sys.argv[1], sys.argv[2:]
    questions = {"--tour": TOUR, "--act3": ACT3}.get(rest[0], rest) if rest else []
    cur = connect().cursor()
    cur.execute("USE WAREHOUSE BANK_DEMO_WH")
    failed = 0
    for q in questions:
        print("=" * 100, f"\nQ: {q}")
        answer, tools, err = ask(cur, agent, q)
        if err:
            failed += 1
            print("ERROR:", err)
            continue
        for t in tools:
            print("  tool ->", t)
        print("A:", answer.strip())
    sys.exit(1 if failed else 0)


if __name__ == "__main__":
    main()
