# Runbook (~25 min)

Facilitation notes for running the demo end to end. The bank is fictional and the data is synthetic.

The story in one line: **one approved meaning for every business concept, served to AI, with each person's access
enforced on the data, and a new data product added without remodelling anything.**

| Act | What it shows |
|---|---|
| **Act 1** | The agent cites the approved definition and refuses what isn't approved |
| **Act 2** | The same question returns a different answer per user, because access is enforced on the data |
| **Act 3** | One new data product: one semantic view change, one steward approval, nothing remodelled |

## Before the Session

1. **Baseline:** if Act 3 has been run before, run `reset/90_reset_live.sql`. Then `sql/06_verify.sql`: every row should say PASS.
2. **Search index:** `cortex search object "NPL ratio" --types=business-ontology` should return `Regulatory Reporting.NPL Ratio`.
3. **Warm up:** `python tests/ask_agent.py RETAIL_BANKING_AGENT --tour` (it also wakes the warehouse).
4. **Persona switching:** CoWork uses the user's default role after signing in again. Run a block of
   `sql/persona_switch.sql`, sign out and back in, and start a **new chat**. As the relationship manager,
   *"What are total deposits as at the latest month end?"* should give **£3,924,640**. If it shows £16.30m,
   CoWork hasn't picked up the role: use Snowsight's user menu > Switch role > `BANK_RM`.
5. **Windows open:** CoWork, Snowsight on Catalog » Business Ontology, the agent playground with **Retail Banking
   Agent (semantic view only)**, and Cortex Code with `live/COCO_PROMPTS.md`.

## Act 1: Governed Meaning (10 min)

**The ontology in Snowsight (4 min).** Catalog » Business Ontology: start with the list (five domains, one steward
each), then switch to **Graph**.

- *NPL Ratio*: its definition and formula, **derived** from Non-Performing Loan, which comes from Days Past Due (owned
  by Lending), and bound to `NPL_RATIO`. A change to Days Past Due shows which regulatory metrics are affected.
- *Residual Maturity Bucket*: measured from the reporting month end, not from today, a rule SQL can't carry.
- *Net Interest Margin*: still a **draft**, proposed but not approved by Finance.

**Ask in CoWork, as Head of Lending (4 min).**

| Question | Expected answer (30 Sep 2026) |
|---|---|
| What is our NPL ratio, and how is it defined? | **4.03%** (Aug 1.11%), citing `Regulatory Reporting.NPL Ratio` and the unlikely-to-pay caveat |
| What is the total loan portfolio by maturity? | **£6.58m**: under 1 year £391k, 1-2y £625k, 2-3y £1.70m, 3-5y £2.82m, over 5y £1.04m |
| How many customers do we have by loan maturity? | 248 borrowers: 33, 47, 63, 95 and 10 |
| What is our Net Interest Margin? | **Refuses**: there's no approved definition, and it doesn't invent one |

**The comparison (2 min).** In the agent playground, ask the **semantic view only** agent *"How many active customers
do we have by segment?"*. It says "active" isn't defined. The governed agent answers **598** (Retail 436, Premier 107,
SME 55) and cites `Customer.Active Customer`.

## Act 2: Access Defined Once, Inherited by AI (6 min)

1. As Head of Lending: *"Which customers have balances over £120k?"* → **41**, all SME, led by **P. D. P.
   (PTY-000549) at £257,022**. Names are masked for this role.
2. Switch to the relationship manager (`sql/persona_switch.sql`, sign in again, new chat) and ask the same question
   → **none**. Then *"What about over £50k?"* → **30, led by Grace Thompson at £88,056**, with full names, because
   they're her own customers. Her deposits are **£3,924,640**, against £16,303,946 for the bank.
3. *"Create an HTML report of customer visits and activity by channel over the last six months, highlighting the
   contact centre complaints."* The report opens inline, built only from the rows she's allowed to see.

Key point: same question, same definition, different answer. The access rules live on the tables, not in the agent
or the report.

## Act 3: Add One Data Product, Live (8 min)

Follow `live/COCO_PROMPTS.md`: interest accruals land in Silver with the same row access policy, CoCo extends the
semantic view, the agent **still refuses** NIM, Finance approves Net Interest Margin with the business-ontology
skill, and the agent answers **3.40%** (3.61% in August) and explains the fall from its governed inputs.

Key point: **the definition, the computation and the answer have three different owners**, and adding a data product
touched each of them once.

## Wrapping Up (1 min)

- The ontology owns what it *means* (business steward), the semantic view owns how it's *computed* (technical
  steward), and the agent uses both, as the user. Rebuilding the view leaves the definition in place.
- Proposing isn't publishing: `SUGGEST` vs `MODIFY` on each domain gives maker-checker on meaning.

## Known Limitations

- **Business Ontology is in Private Preview.** File generation in CoWork is in preview too.
- **Search lags edits and grants by up to ~6 hours.** In Act 3, the trace shows the search missing the new node and
  the agent reading the approved list directly.
- **Clients:** the docs only guarantee ontology search in the agent playground and through `DATA_AGENT_RUN`. It also
  worked in CoWork on the demo account; test from the app your users will use.
- **Formulas are documentation:** the semantic view does the computing, so the two need keeping in line (there's no
  automatic drift check yet).
- **It isn't OWL reasoning, a graph database, or an action layer.** NIM is simplified for the demo.
- **Models:** check which Claude models are available in your region.

## Troubleshooting

| Symptom | Fix |
|---|---|
| The relationship manager sees £16.30m in CoWork | Snowsight user menu > Switch role > `BANK_RM`, then a new chat |
| CoCo goes off-script in Act 3 | Run the matching fallback file in `live/` |
| NIM is still refused after approval | The summary should show 24 active / 0 drafts; re-run `live/12_ontology_nim.sql` |
| Anything else during Act 3 | `reset/90_reset_live.sql` puts everything back in about 30 seconds |
| Stuck on a persona after the demo | Run the last block of `sql/persona_switch.sql` |
