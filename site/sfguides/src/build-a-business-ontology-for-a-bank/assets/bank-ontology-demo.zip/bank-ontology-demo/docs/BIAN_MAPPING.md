# How This Demo Maps to BIAN

The demo uses plain-English names so anyone can read it. This page maps each domain and node to its BIAN equivalent,
for banks that work to BIAN.

> **Please note:** this is an **illustrative** mapping for the demo, not a Snowflake BIAN accelerator. The names follow
> BIAN conventions; check them against the BIAN release you work to before reusing any of it.

## Domains and BIAN Service Domains

| Demo domain | BIAN service domain (illustrative) | Steward in the demo | System of record |
|---|---|---|---|
| Customer | Party Reference Data Management | Customer Data Owner | CRM |
| Current Account | Current Account | Deposits Product Owner | Core banking |
| Consumer Loan | Consumer Loan | Lending Product Owner | Core banking |
| Regulatory Reporting | Regulatory Reporting | Finance and Risk Reporting | (derived) |
| Customer Engagement | Customer Contact / Channel Activity Analysis (illustrative) | Channels and Service Owner | Channel platforms |

Having one domain per service domain gives each a natural steward and a natural access boundary
(`GRANT READ | SUGGEST | MODIFY ON ONTOLOGY DOMAIN ...`). Giving `SUGGEST` and `MODIFY` to different roles separates
proposing a definition from approving it (maker-checker).

## Nodes and the BIAN Business Object Model

| Demo node (kind) | BIAN business object / concept (illustrative) | Physical object in Silver |
|---|---|---|
| Customer.Customer (ENTITY) | Party (in a customer role) | `SILVER.PARTY` |
| Customer.Customer Identifier | Party Identification | `PARTY.PARTY_ID` |
| Customer.Customer Segment | Party classification / customer segment | `PARTY.CUSTOMER_SEGMENT` |
| Customer.KYC Status | Customer due-diligence outcome | `PARTY.KYC_STATUS` |
| Customer.Active Customer (METRIC) | Bank-specific KPI | SV `ACTIVE_CUSTOMERS` |
| Customer.Relationship Manager (ENTITY) | Party (in an employee / relationship-manager role) | `SILVER.RELATIONSHIP_MANAGER`, `PARTY.RM_ID` |
| Current Account.Current Account (ENTITY) | Current Account Arrangement | `SILVER.CURRENT_ACCOUNT_ARRANGEMENT` |
| Current Account.Total Deposits (METRIC) | Arrangement balance (aggregated) | SV `TOTAL_DEPOSITS` |
| Consumer Loan.Loan (ENTITY) | Loan Arrangement | `SILVER.LOAN_ARRANGEMENT` |
| Consumer Loan.Days Past Due | Arrangement delinquency | `LOAN_POSITION_SNAPSHOT.DAYS_PAST_DUE` |
| Consumer Loan.Outstanding Principal (METRIC) | Outstanding loan balance | SV `OUTSTANDING_PRINCIPAL` |
| Consumer Loan.Maturity Date | Loan arrangement maturity date | `LOAN_ARRANGEMENT.MATURITY_DATE` |
| Consumer Loan.Residual Maturity Bucket | Residual maturity band (reporting) | SV `MATURITY_BUCKET` |
| Consumer Loan.Borrowers (METRIC) | Bank-specific KPI | SV `BORROWERS` |
| Regulatory Reporting.Reporting Month End | Reporting period | `MONTH_END_CALENDAR.MONTH_END_DATE` |
| Regulatory Reporting.Non-Performing Loan | Non-performing exposure (simplified: 90+ DPD only) | (rule on DPD) |
| Regulatory Reporting.NPL Ratio (METRIC) | Prudential ratio | SV `NPL_RATIO` |
| Regulatory Reporting.Loan-to-Deposit Ratio (METRIC) | Prudential ratio | SV `LOAN_TO_DEPOSIT_RATIO` |
| Regulatory Reporting.Net Interest Margin (METRIC) | Financial KPI (Act 3) | SV `NET_INTEREST_MARGIN` |
| Customer Engagement.Customer Interaction (ENTITY) | Contact / customer event | `SILVER.CUSTOMER_INTERACTION` |
| Customer Engagement.Channel | Channel | `CUSTOMER_INTERACTION.CHANNEL` |
| Customer Engagement.Complaint | Customer complaint (contact type) | `CUSTOMER_INTERACTION.INTERACTION_TYPE` |
| Customer Engagement.Complaint Rate (METRIC) | Service / conduct KPI | SV `COMPLAINT_RATE` |
| Customer Engagement.Digital Share (METRIC) | Channel KPI | SV `DIGITAL_SHARE` |

The physical Silver tables keep BIAN-style names (`PARTY`, `*_ARRANGEMENT`). The ontology gives
business users the plain name and binds it to the conformed table, so you can rename one without breaking the other.

## Relationships Worth Showing

- Customer *holds* (CUSTOM) Current Account / Loan: crosses service-domain boundaries.
- Customer `IDENTIFIED_BY` Customer Identifier: the cross-system join key (not the CRM record id).
- Days Past Due `DERIVES` Non-Performing Loan `DERIVES` NPL Ratio: a regulatory metric traced to an operational field.
- Reporting Month End `SCOPES` Total Deposits / Outstanding Principal: the semi-additivity rule, stated once.
