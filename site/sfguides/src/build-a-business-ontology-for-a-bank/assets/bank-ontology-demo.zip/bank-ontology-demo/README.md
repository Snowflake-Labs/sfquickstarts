# Business Ontology in Production: An End-to-End Bank Demo

*Alexandre Levret, Senior Solution Engineer, Snowflake*

This repo builds a **Business Ontology** on Snowflake, end to end, on a synthetic retail bank. It shows how to:

- Govern what each business concept *means*, once, for the whole bank
- Bind those definitions to the data that implements them
- Build an agent that cites the approved definition, and refuses when there isn't one
- Give every user the right answer for *their* access, without building anything twice
- Add a new data product and take a metric from *refused* to *governed and answered*

> **Please note:** Business Ontology is currently in **Private Preview** and available to selected accounts. Everything
> here was built and tested on a preview-enabled account in November 2026. All data is synthetic.

---

## Why Does a Bank Need It?

Different teams often define the same term differently. Retail counts anyone with an open account as an *active
customer*, Compliance only counts KYC-verified customers, and Finance leaves out customers who only hold a loan. A
self-service agent has to pick one, with no way of knowing which one the business approved.

A **Semantic View** already solves *how* a metric is computed for one data product. A **Business Ontology** adds the
layer above: what the metric *means* across the bank, who approved it, what it depends on, and which asset
implements it.

The three layers:

| | **Business Ontology** | **Semantic View** | **AI agent** |
|---|---|---|---|
| Answers | What does it *mean*? | How is it *computed*? | What does *this user* need? |
| Owner | Business steward | Technical steward | Platform team |
| Scope | Account-wide, by domain | One data product | One audience |
| Runs SQL? | No: the formula is documentation | Yes | Yes, as the user |

![Snowsight: the ontology graph across five domains, NPL Ratio selected](docs/img/01-ontology-graph.png)

---

## How It Fits Together

Each question follows two steps: the agent reads the approved definition from the ontology, then queries the bound
semantic view as the user.

```mermaid
flowchart TB
    U(["Head of Lending / Relationship manager"]) --> A["Retail Banking Agent<br/>(CoWork)"]
    A -- "1. What does it mean?" --> BO["Business Ontology<br/>5 domains, 23 approved definitions"]
    A -- "2. Get the number, as the user" --> SV["Semantic View<br/>RETAIL_BANKING_SV"]
    BO -. "each definition is bound to<br/>the metric that computes it" .-> SV
    SV --> D[("Silver tables<br/>row access + masking policies")]
```

---

## What's Governed

Five domains, one per team that owns the meaning. Each maps to a BIAN service domain in
[`docs/BIAN_MAPPING.md`](docs/BIAN_MAPPING.md).

| Domain | Steward | Governed nodes (examples) |
|---|---|---|
| Customer | Customer Data Owner | Customer, Customer Identifier, KYC Status, Active Customer, Relationship Manager |
| Current Account | Deposits Product Owner | Current Account, Total Deposits |
| Consumer Loan | Lending Product Owner | Loan, Days Past Due, Outstanding Principal, Maturity Date, Residual Maturity Bucket, Borrowers |
| Regulatory Reporting | Finance and Risk Reporting | Reporting Month End, Non-Performing Loan, NPL Ratio, Loan-to-Deposit Ratio, *Net Interest Margin (draft)* |
| Customer Engagement | Channels and Service Owner | Customer Interaction, Channel, Complaint, Complaint Rate, Digital Share |

Definitions are written for humans, including the traps a SQL expression can't carry. For example:

> **Regulatory Reporting.Non-Performing Loan**: *A Loan that is 90 or more Days Past Due at the reporting month end.
> Simplification: the full prudential definition also includes unlikely-to-pay exposures, which are not modelled here.*

Relationships make cross-team dependencies explicit. *Days Past Due* (owned by Lending) **derives** *Non-Performing
Loan*, which **derives** *NPL Ratio* (owned by Finance). A change to Days Past Due shows which regulatory metrics are
affected.

![Snowsight: the NPL Ratio node with definition, formula, relationships and bound semantic view metric](docs/img/02-node-detail.png)

---

## What the Business User Sees

**The agent cites the approved definition it used, by name.** Here it searches the ontology, reads *Regulatory
Reporting.NPL Ratio*, queries the semantic view, and passes on the unlikely-to-pay caveat:

![CoWork: NPL ratio answer citing Regulatory Reporting.NPL Ratio, trace showing the ontology search](docs/img/03-cowork-governed-answer.png)

**Same question, same definition, different answer.** Access is defined once, on the tables, and the agent runs as
the user, so it inherits it. There's no separate report and no entitlement logic in the agent.

| "Which customers have balances over £120k?" (30 Sep 2026) | Head of Lending | Relationship manager |
|---|---|---|
| Customers | 41, all SME, names masked to initials | None: her book is Premier, top balance £88,056 |
| Total deposits | £16,303,946 | £3,924,640 (her book) |

![CoWork: the same question as Head of Lending (left) and relationship manager (right)](docs/img/04-personas-side-by-side.png)

**It refuses what isn't approved.** *Net Interest Margin* only exists as a draft, so the agent declines to compute
it rather than use a textbook formula.

---

## Running It in Production

Adding one new data product touches three owners, once each:

```mermaid
sequenceDiagram
    autonumber
    participant DE as Data engineering
    participant TS as Technical steward
    participant BS as Business steward (Finance)
    participant AI as Agent
    DE->>DE: Land INTEREST_ACCRUAL_MONTHLY in Silver<br/>(same row access policy)
    TS->>TS: Add NET_INTEREST_MARGIN to the semantic view
    Note over AI: Still refuses NIM: the number exists,<br/>nobody has approved what it means
    BS->>BS: Review draft, approve, add DERIVES edges,<br/>bind to the new metric
    AI-->>AI: Answers 3.40% (Aug 3.61%)<br/>and explains the fall from governed inputs
```

![CoWork: Net Interest Margin refused before approval (left) and answered after (right)](docs/img/05-nim-before-after.png)

What this gives a bank:

- **Maker-checker on meaning.** Grant `SUGGEST` to analysts and `MODIFY` to stewards, per domain. Proposing isn't
  publishing, and only approved nodes are served to AI. Please note that `MODIFY` alone can approve its own drafts,
  so keep the two with different roles.
- **Access defined once.** Row access and masking on the data apply to SQL, the semantic view, the agent, and the
  files it generates.
- **Change without re-modelling.** Rebuild a semantic view or swap a source system: the approved definition stays
  where it is, and you only re-point the binding.
- **Reports built from governed numbers.** The agent can produce an HTML, PDF or PowerPoint report in CoWork, using
  only figures it fetched as the user.

![CoWork: HTML report of channel activity, generated inline](docs/img/06-html-report.png)

---

## Key Takeaways

- **A Semantic View computes, a Business Ontology governs meaning.** They have different owners, and they work best together.
- **A domain is an organisational decision.** Map it to a real steward: it's both your access boundary and your approval boundary.
- **Access defined once on the data reaches AI automatically.** Same question, same definition, the right answer for each person.
- **Approval is what makes AI answers defensible.** Drafts are invisible to the agent: proposing isn't publishing.

---

## Deploy It in Your Account

If you want to have it deployed in your account and start exploring the possibilities, here's the guide. It's seven
SQL files, run in order. You'll need a Business Ontology preview-enabled account.

Run each file in full, in one session, as `ACCOUNTADMIN` (a Snowsight worksheet works fine). The ontology is
account-wide, so `03_ontology.sql` first checks that the five domain names are free and stops before creating
anything if they aren't.

| Step | File | What it does |
|---|---|---|
| 1 | `sql/00_setup.sql` | Warehouse `BANK_DEMO_WH`, `BANK_DEMO`, schemas, the persona roles `BANK_RM` / `BANK_HEAD_OF_LENDING` (granted to you), and a copy of your user defaults |
| 2 | `sql/01_silver_data.sql` | 8 Silver tables with deterministic synthetic data |
| 3 | `sql/02_semantic_view.sql` | `RETAIL_BANKING_SV`, with verified queries |
| 4 | `sql/03_ontology.sql` | 5 domains, 23 nodes plus 1 draft, 29 relationships, 33 representations |
| 5 | `sql/04_agents.sql` | The governed agent (added to CoWork) and a semantic-view-only agent for comparison |
| 6 | `sql/05_governance.sql` | Row access and masking policies, plus data and ontology `READ` grants for both personas |
| 7 | `sql/06_verify.sql` | Checks the whole bank and both personas: every row should say **PASS** |

Then give the search index time to catch up (up to ~6 hours). In Cortex Code,
`cortex search object "NPL ratio" --types=business-ontology` should return the node when it's ready.

Once it's in, here's where to go next:

- **Demo flow, timings and expected answers:** [`docs/RUNBOOK.md`](docs/RUNBOOK.md)
- **The live act (adding Net Interest Margin):** [`live/COCO_PROMPTS.md`](live/COCO_PROMPTS.md), with scripted fallbacks in `live/`
- **Switching persona in CoWork:** `sql/persona_switch.sql` (its last block restores your own defaults)
- **Resetting after each run:** `reset/90_reset_live.sql`, then `sql/06_verify.sql`
- **Removing everything:** `reset/99_teardown.sql` deletes the demo domains (only those carrying its marker), the
  database, the persona roles and the warehouse, and restores your user defaults

You can also test the agent from SQL:

```bash
pip install snowflake-connector-python
export SNOWFLAKE_CONNECTION_NAME=<your connection>
python tests/ask_agent.py RETAIL_BANKING_AGENT --tour
python tests/ask_agent.py SV_ONLY_AGENT "How many active customers do we have by segment?"
```

---

## Learn More

- Explore the [Business Ontology documentation](https://docs.snowflake.com/en/LIMITEDACCESS/snowflake-horizon/business-ontology) (Private Preview), including
  [access control](https://docs.snowflake.com/en/LIMITEDACCESS/snowflake-horizon/business-ontology-access-control) and
  [use with Cortex Agents](https://docs.snowflake.com/en/LIMITEDACCESS/snowflake-horizon/business-ontology-agents)
- Read the [Overview of Semantic Views](https://docs.snowflake.com/user-guide/views-semantic/overview)
- See [Document generation in Snowflake CoWork](https://docs.snowflake.com/user-guide/snowflake-cortex/snowflake-cowork/document-generation)
