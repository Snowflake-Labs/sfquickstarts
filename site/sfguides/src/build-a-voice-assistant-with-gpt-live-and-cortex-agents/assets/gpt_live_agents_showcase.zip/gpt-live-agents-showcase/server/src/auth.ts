import fs from "node:fs";
import type { Config } from "./config.js";

/** Header SPCS ingress adds with the signed-in user's name: shown on the page, and the key for the call limit. */
export const SIGNED_IN_USER_HEADER = "sf-context-current-user";

export class AuthError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "AuthError";
  }
}

/**
 * Authorization headers for one Snowflake REST call on SPCS.
 *
 * The service token is re-read on every call because Snowflake refreshes the
 * file in place. Nothing here is ever sent to the browser.
 */
export function snowflakeAuthHeaders(
  config: Config,
  readFile: (p: string) => string = (p) => fs.readFileSync(p, "utf8"),
): Record<string, string> {
  // Local runs sign in with OAuth; their headers come from OAuthSession (oauth.ts).
  if (config.authMode === "oauth") throw new AuthError("Local runs use OAuthSession.headers(), not the SPCS token.");

  const serviceToken = readFile(config.spcsTokenFile).trim();
  if (!serviceToken) throw new AuthError(`SPCS token file is empty: ${config.spcsTokenFile}`);

  return {
    Authorization: `Bearer ${serviceToken}`,
    "X-Snowflake-Authorization-Token-Type": "OAUTH",
  };
}
