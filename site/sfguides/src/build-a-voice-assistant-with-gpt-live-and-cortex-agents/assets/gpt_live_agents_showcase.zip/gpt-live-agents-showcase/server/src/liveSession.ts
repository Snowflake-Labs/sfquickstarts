import type { Config } from "./config.js";
import { errorText } from "./errors.js";
import { liveInstructions } from "./persona.js";

export type CreatedLiveSession = {
  /** openai-gpt-live-1 session id, `live_` prefix included. */
  sessionId: string;
  /** The provider's SDP answer. The browser applies it and connects directly. */
  answerSdp: string;
};

export class LiveSessionError extends Error {
  constructor(
    message: string,
    readonly status: number,
    options?: ErrorOptions,
  ) {
    super(message, options);
    this.name = "LiveSessionError";
  }
}

/** Session create normally takes 1–3 s; past this the gateway is stuck. */
export const SESSION_CREATE_TIMEOUT_MS = 20_000;

export function liveSessionsUrl(config: Config): string {
  return `${config.snowflakeUrl}/api/v2/aigateways/${encodeURIComponent(config.aiGatewayName)}/v1/live/sessions`;
}

/** The request body for POST .../v1/live/sessions. `brief`: today's precomputed briefing, if any. */
export function liveSessionBody(config: Config, offerSdp: string, brief?: string): Record<string, unknown> {
  return {
    session: {
      model: config.liveModel,
      instructions: liveInstructions(brief),
      // Fixed for the session once created; omitting it falls back to a default voice.
      audio: { output: { voice: config.voice } },
      // This application is the backend: openai-gpt-live-1 hands data questions to the
      // browser as session.delegation.created events.
      delegation: { type: "client" },
    },
    // The provider rejects an SDP whose last line has no terminator.
    transport: { type: "webrtc", sdp: offerSdp.endsWith("\r\n") ? offerSdp : `${offerSdp}\r\n` },
  };
}

function hint(status: number, gatewayName: string): string {
  switch (status) {
    case 401:
      // An empty-body 401 is also what the gateway returns when the account may
      // not use the model, so a valid token is not enough to rule this out.
      return (
        " The token was refused, or this account may not use the openai-gpt-live-1 model yet. " +
        "Check \"Enable openai-gpt-live-1 on your account\" in the README (Private Preview)."
      );
    case 403:
      return " The role may not use the gateway or the model. Check \"Enable openai-gpt-live-1 on your account\" in the README.";
    case 404:
      return ` No openai-gpt-live-1 route on AI Gateway "${gatewayName}". Check AI_GATEWAY_NAME and that openai-gpt-live-1 is enabled for the account.`;
    default:
      return "";
  }
}

/**
 * Create an openai-gpt-live-1 call through the account's AI Gateway.
 *
 * This is the only provider call the server makes. Audio and the event data
 * channel then run directly between the browser and the model provider; the
 * server never carries media.
 */
export async function createLiveSession(
  config: Config,
  offerSdp: string,
  authHeaders: Record<string, string>,
  fetchImpl: typeof fetch = fetch,
  brief?: string,
): Promise<CreatedLiveSession> {
  const url = liveSessionsUrl(config);
  let response: Response;
  try {
    response = await fetchImpl(url, {
      method: "POST",
      headers: { ...authHeaders, "Content-Type": "application/json", Accept: "application/json" },
      body: JSON.stringify(liveSessionBody(config, offerSdp, brief)),
      // A gateway that never answers must not leave the page on "Connecting…".
      signal: AbortSignal.timeout(SESSION_CREATE_TIMEOUT_MS),
    });
  } catch (error) {
    // fetch's own message is a bare "fetch failed"; say what was being reached.
    throw new LiveSessionError(`openai-gpt-live-1 session create: no response from ${new URL(url).host} (${errorText(error)}).`, 502, {
      cause: error,
    });
  }
  let text: string;
  try {
    text = await response.text();
  } catch (error) {
    // The timeout also covers the body: a gateway can send headers, then stall.
    throw new LiveSessionError(`openai-gpt-live-1 session create: the response from ${new URL(url).host} broke off (${errorText(error)}).`, 502, {
      cause: error,
    });
  }

  if (!response.ok) {
    const requestId = response.headers.get("x-snowflake-request-id");
    throw new LiveSessionError(
      `openai-gpt-live-1 session create failed (${response.status}).` +
        hint(response.status, config.aiGatewayName) +
        (requestId ? ` Request id ${requestId}.` : "") +
        (text ? ` Body: ${text.slice(0, 300)}` : " Empty body."),
      response.status,
    );
  }

  let parsed: { session?: { id?: string }; transport?: { sdp?: string } };
  try {
    parsed = JSON.parse(text);
  } catch {
    throw new LiveSessionError(`openai-gpt-live-1 returned a non-JSON body: ${text.slice(0, 200)}`, 502);
  }
  const sessionId = parsed.session?.id;
  const answerSdp = parsed.transport?.sdp;
  if (!sessionId || !answerSdp) {
    throw new LiveSessionError("openai-gpt-live-1 response had no session.id or transport.sdp.", 502);
  }
  return { sessionId, answerSdp };
}
