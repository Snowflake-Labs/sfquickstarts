import { describe, expect, it } from "vitest";
import { loadConfig } from "./config.js";
import { liveSessionBody } from "./liveSession.js";
import { liveInstructions } from "./persona.js";

const local = loadConfig({ SNOWFLAKE_ACCOUNT_URL: "https://acct.snowflakecomputing.com", SNOWFLAKE_OAUTH_CLIENT_ID: "client-id" }, () => false);

describe("liveInstructions", () => {
  it("is the plain prompt without a briefing", () => {
    const text = liveInstructions();
    expect(text).not.toMatch(/briefing/i);
    expect(text).not.toContain("{{");
  });

  it("adds the briefing as facts, and says to answer from it without a lookup", () => {
    const text = liveInstructions("Today is Fri 2026-01-16.");
    expect(text).toContain("<briefing>\nToday is Fri 2026-01-16.\n</briefing>");
    expect(text).toContain("- The briefing below answers it.");
    expect(text).toMatch(/answer straight away from it, without generating <\|SpawnThinking\|>/);
    // A past visit is not in the briefing, even though "last" also fits today's last meeting.
    expect(text).toMatch(/"my last visit".*mean a past meeting, which is not in it/);
    expect(text).not.toContain("{{");
  });

  it("opens with the day when there is a briefing, and never asks who the rep is meeting", () => {
    expect(liveInstructions()).toContain('"Hi, I\'m ready to help you prep. What would you like to go over?"');
    const briefed = liveInstructions("Today is Fri.");
    expect(briefed).toMatch(/greet the rep by first name .* how many visits/);
    // The greeting comes after the briefing it draws on.
    expect(briefed.indexOf("To open the conversation")).toBeGreaterThan(briefed.indexOf("</briefing>"));
    for (const text of [liveInstructions(), briefed]) expect(text).not.toMatch(/Who are you meeting today/);
  });

  it("goes into the session create body", () => {
    const body = liveSessionBody(local, "v=0", "Today is Fri.") as { session: { instructions: string } };
    expect(body.session.instructions).toContain("<briefing>\nToday is Fri.\n</briefing>");
  });
});
