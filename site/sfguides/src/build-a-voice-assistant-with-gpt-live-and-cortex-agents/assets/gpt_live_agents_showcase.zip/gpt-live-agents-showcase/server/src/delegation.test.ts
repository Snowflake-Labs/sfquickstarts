import { describe, expect, it } from "vitest";
import type { AgentRunCallbacks } from "./agent.js";
import { forSpeech, runDelegation, toAgentMessages, type DelegationEvent } from "./delegation.js";

const text = (messages: ReturnType<typeof toAgentMessages>) => messages.map((m) => `${m.role}:${m.content[0].text}`);

describe("toAgentMessages", () => {
  it("drops the leading greeting and trailing acknowledgement, and merges same-role fragments", () => {
    const messages = toAgentMessages([
      { role: "assistant", text: "Hi, who are you meeting?" },
      { role: "user", text: "Dr. Smith." },
      { role: "user", text: "How many scripts last month?" },
      { role: "assistant", text: "Let me check that in Snowflake." },
    ]);
    expect(text(messages)).toEqual(["user:Dr. Smith. How many scripts last month?"]);
  });

  it("keeps earlier turns so follow-ups resolve", () => {
    const messages = toAgentMessages([
      { role: "user", text: "Scripts for Dr. Smith in May?" },
      { role: "assistant", text: "About forty." },
      { role: "user", text: "And June?" },
    ]);
    expect(text(messages)).toEqual(["user:Scripts for Dr. Smith in May?", "assistant:About forty.", "user:And June?"]);
  });

  it("windows to the last turns and still starts on a user turn", () => {
    const turns = Array.from({ length: 10 }, (_, i) => ({ role: i % 2 ? "assistant" : "user", text: `t${i}` }) as const);
    const messages = toAgentMessages([...turns, { role: "user", text: "last" }], 4);
    expect(messages[0].role).toBe("user");
    expect(messages.at(-1)?.content[0].text).toBe("last");
    expect(messages.length).toBeLessThanOrEqual(4);
  });

  it("returns nothing when no user turn exists, and ignores malformed turns", () => {
    expect(toAgentMessages([{ role: "assistant", text: "Hello" }])).toEqual([]);
    expect(toAgentMessages([{ role: "system" as never, text: "x" }, { role: "user", text: "  " }])).toEqual([]);
  });
});

describe("forSpeech", () => {
  it("strips markdown, tables, links and citations", () => {
    const out = forSpeech("**Dr. Lee** wrote 42 scripts [1].\n\n| a | b |\n|---|---|\n- see [the report](https://x.example/y)");
    expect(out).toBe("Dr. Lee wrote 42 scripts . see the report");
  });

  it("caps very long answers", () => {
    expect(forSpeech("word ".repeat(1000)).length).toBeLessThanOrEqual(1500);
  });

  it("keeps > and _ that are part of the answer, but drops them as markdown", () => {
    expect(forSpeech("TRx > 5 in 3 months for ICS_LABA")).toBe("TRx > 5 in 3 months for ICS_LABA");
    expect(forSpeech("## Summary\n> He wrote _about_ __five__.")).toBe("Summary He wrote about five.");
    // A leading ">" before a number is "more than", not a quote marker.
    expect(forSpeech("> 5 scripts in December")).toBe("> 5 scripts in December");
    expect(forSpeech(">= 5 scripts")).toBe(">= 5 scripts");
  });
});

describe("runDelegation", () => {
  const collect = async (
    turns: Parameters<typeof runDelegation>[0],
    agent: (cb: AgentRunCallbacks) => Promise<{ text: string; toolTypes: string[]; totalMs: number }>,
  ) => {
    const events: DelegationEvent[] = [];
    await runDelegation(turns, (_m, cb) => agent(cb), (e) => events.push(e), new AbortController().signal);
    return events;
  };

  it("reports each phase once, then the answer", async () => {
    const events = await collect([{ role: "user", text: "How is the territory doing?" }], async (cb) => {
      cb.onStatus?.("planning");
      cb.onStatus?.("planning");
      cb.onStatus?.("executing_tools");
      cb.onStatus?.("reevaluating_plan");
      cb.onStatus?.("proceeding_to_answer");
      return { text: "Up **5%** this quarter.", toolTypes: ["cortex_analyst_text_to_sql"], totalMs: 900 };
    });
    expect(events.filter((e) => e.type === "progress").map((e) => e.text.match(/phase=(\S+)/)?.[1])).toEqual([
      "started",
      "planning",
      "querying_data",
      "writing_answer",
    ]);
    expect(events.at(-1)).toEqual({
      type: "answer",
      text: "Up 5% this quarter.",
      toolTypes: ["cortex_analyst_text_to_sql"],
      totalMs: 900,
    });
  });

  it("answers without calling the agent when there is no question", async () => {
    let called = false;
    const events = await collect([{ role: "assistant", text: "Hi" }], async () => {
      called = true;
      return { text: "", toolTypes: [], totalMs: 0 };
    });
    expect(called).toBe(false);
    expect(events).toHaveLength(1);
    expect(events[0].type).toBe("answer");
  });

  it("turns a failure into something speakable, keeping the detail off the spoken text", async () => {
    const events = await collect([{ role: "user", text: "q" }], async () => {
      throw new Error("403 role may not use agent");
    });
    const last = events.at(-1);
    expect(last?.type).toBe("error");
    if (last?.type !== "error") return;
    expect(last.text).not.toContain("403");
    expect(last.detail).toContain("403");
  });

  it("emits nothing after the browser hangs up", async () => {
    const controller = new AbortController();
    const events: DelegationEvent[] = [];
    await runDelegation(
      [{ role: "user", text: "q" }],
      async () => {
        controller.abort();
        return { text: "late", toolTypes: [], totalMs: 1 };
      },
      (e) => events.push(e),
      controller.signal,
    );
    expect(events.map((e) => e.type)).toEqual(["progress"]);
  });
});
