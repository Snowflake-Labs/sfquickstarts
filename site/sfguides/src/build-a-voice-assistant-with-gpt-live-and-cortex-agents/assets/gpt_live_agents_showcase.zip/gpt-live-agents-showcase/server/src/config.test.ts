import { describe, expect, it } from "vitest";
import { loadConfig } from "./config.js";

const noSpcs = () => false;

describe("account URL", () => {
  it("adds https:// when it is missing and drops a trailing slash", () => {
    const config = loadConfig({ SNOWFLAKE_ACCOUNT_URL: "myorg-myacct.snowflakecomputing.com/", SNOWFLAKE_OAUTH_CLIENT_ID: "client-id" }, noSpcs);
    expect(config.snowflakeUrl).toBe("https://myorg-myacct.snowflakecomputing.com");
  });

  it("refuses plain http, which would send the token unencrypted", () => {
    expect(() => loadConfig({ SNOWFLAKE_ACCOUNT_URL: "http://myorg-myacct.snowflakecomputing.com", SNOWFLAKE_OAUTH_CLIENT_ID: "client-id" }, noSpcs)).toThrow(
      /https/,
    );
  });
});

describe("local listen address", () => {
  const base = { SNOWFLAKE_ACCOUNT_URL: "acct.snowflakecomputing.com", SNOWFLAKE_OAUTH_CLIENT_ID: "client-id" };

  it("stays on loopback, since the server holds the user's sign-in", () => {
    expect(loadConfig(base, noSpcs).host).toBe("127.0.0.1");
    expect(loadConfig({ ...base, LISTEN_HOST: "localhost" }, noSpcs).host).toBe("localhost");
    expect(() => loadConfig({ ...base, LISTEN_HOST: "0.0.0.0" }, noSpcs)).toThrow(/LISTEN_HOST/);
  });

  it("may listen on every interface on SPCS, where ingress signs users in", () => {
    expect(loadConfig({ SNOWFLAKE_HOST: "h" }, () => true).host).toBe("0.0.0.0");
  });
});
