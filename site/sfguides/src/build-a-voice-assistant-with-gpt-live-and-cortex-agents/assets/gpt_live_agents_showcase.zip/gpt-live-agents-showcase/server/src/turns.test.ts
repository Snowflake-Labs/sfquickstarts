import { describe, expect, it } from "vitest";
// Browser module: plain JS, no DOM, so it runs under Node as is.
import { addTurn, lastRequest, needsNewTurn } from "../../web/turns.js";

describe("needsNewTurn", () => {
  const opts = { transcribing: false, now: 10_000, staleMs: 6000 };

  it("waits while the user is still being transcribed", () => {
    expect(needsNewTurn([], { ...opts, transcribing: true })).toBe(true);
  });

  it("takes a fresh user turn", () => {
    expect(needsNewTurn([{ role: "user", at: 9000 }], opts)).toBe(false);
    // The assistant's "Let me check" right after it doesn't make it stale.
    expect(needsNewTurn([{ role: "user", at: 9000 }, { role: "assistant", at: 9500 }], opts)).toBe(false);
  });

  it("waits when the newest user turn is old and already answered", () => {
    expect(needsNewTurn([{ role: "user", at: 1000 }, { role: "assistant", at: 2000 }], opts)).toBe(true);
  });

  it("takes an old user turn that nobody has answered yet", () => {
    expect(needsNewTurn([{ role: "user", at: 1000 }], opts)).toBe(false);
  });
});

type Turn = { role: string; text: string; began: number; at: number };
const turn = (role: string, text: string, began: number, at = began + 1000): Turn => ({ role, text, began, at });

describe("addTurn", () => {
  it("keeps turns in the order they began, not the order they closed", () => {
    // The user starts first; the assistant's short reply closes first.
    const turns: Turn[] = [];
    addTurn(turns, turn("assistant", "Sure.", 200, 900));
    addTurn(turns, turn("user", "Okay, and what about December", 100, 1500));
    expect(turns.map((t) => t.text)).toEqual(["Okay, and what about December", "Sure."]);
  });

  it("appends a turn that began last", () => {
    const turns = [turn("user", "a", 1), turn("assistant", "b", 2)];
    addTurn(turns, turn("user", "c", 3));
    expect(turns.map((t) => t.text)).toEqual(["a", "b", "c"]);
  });

  it("drops the oldest turns past the limit", () => {
    const turns: Turn[] = [];
    for (let i = 0; i < 5; i++) addTurn(turns, turn("user", String(i), i), 3);
    expect(turns.map((t) => t.text)).toEqual(["2", "3", "4"]);
  });
});

describe("lastRequest", () => {
  it("joins what the user said since the assistant last spoke", () => {
    const turns = [
      turn("user", "thanks", 1),
      turn("assistant", "You're welcome.", 2),
      turn("user", "How much did he prescribe", 3),
      turn("user", "in December", 4),
    ];
    expect(lastRequest(turns)).toBe("How much did he prescribe in December");
  });

  it("skips the assistant's reply that began after the question", () => {
    const turns = [
      turn("assistant", "Hi, who are you meeting today?", 1),
      turn("user", "Who am I seeing", 2),
      turn("user", "today", 3),
      turn("assistant", "Let me check that.", 4),
    ];
    expect(lastRequest(turns)).toBe("Who am I seeing today");
  });

  it("is empty when the user hasn't spoken", () => {
    expect(lastRequest([turn("assistant", "Hello.", 1)])).toBe("");
  });
});
