import { describe, expect, it } from "vitest";
import { snowflakeAuthHeaders } from "./auth.js";
import { loadConfig } from "./config.js";
import { createLiveSession, LiveSessionError, liveSessionsUrl } from "./liveSession.js";

const networkFailure = (async () => {
  throw new TypeError("fetch failed", { cause: new Error("getaddrinfo ENOTFOUND") });
}) as unknown as typeof fetch;

const local = loadConfig(
  { SNOWFLAKE_ACCOUNT_URL: "https://myorg-myacct.snowflakecomputing.com/", SNOWFLAKE_OAUTH_CLIENT_ID: "client-id" },
  () => false,
);

describe("loadConfig", () => {
  it("signs in with OAuth against the account URL off SPCS", () => {
    expect(local.authMode).toBe("oauth");
    expect(local.oauthClientId).toBe("client-id");
    expect(local.oauthRedirectUri).toBe("http://127.0.0.1:3000/oauth/callback");
    expect(local.snowflakeUrl).toBe("https://myorg-myacct.snowflakecomputing.com");
    expect(local.host).toBe("127.0.0.1");
  });

  it("uses the mounted token and injected host on SPCS, ignoring any OAuth client", () => {
    const spcs = loadConfig({ SNOWFLAKE_HOST: "abc.snowflakecomputing.com", SNOWFLAKE_OAUTH_CLIENT_ID: "ignored" }, () => true);
    expect(spcs.authMode).toBe("service");
    expect(spcs.oauthClientId).toBeUndefined();
    expect(spcs.snowflakeUrl).toBe("https://abc.snowflakecomputing.com");
    expect(spcs.host).toBe("0.0.0.0");
  });

  it("fails fast without the OAuth client ID", () => {
    expect(() => loadConfig({ SNOWFLAKE_ACCOUNT_URL: "x" }, () => false)).toThrow(/SNOWFLAKE_OAUTH_CLIENT_ID/);
  });

  it("rejects numbers that would turn into NaN", () => {
    const base = { SNOWFLAKE_ACCOUNT_URL: "x", SNOWFLAKE_OAUTH_CLIENT_ID: "c" };
    expect(() => loadConfig({ ...base, AGENT_TIMEOUT_MS: "2m" }, () => false)).toThrow(/AGENT_TIMEOUT_MS/);
    expect(() => loadConfig({ ...base, LISTEN_PORT: "-1" }, () => false)).toThrow(/LISTEN_PORT/);
    expect(loadConfig({ ...base, LISTEN_PORT: "3210" }, () => false).port).toBe(3210);
  });

  it("ignores generic PORT and HOST variables", () => {
    const config = loadConfig({ SNOWFLAKE_ACCOUNT_URL: "x", SNOWFLAKE_OAUTH_CLIENT_ID: "c", PORT: "8787", HOST: "myhost" }, () => false);
    expect(config.port).toBe(3000);
    expect(config.host).toBe("127.0.0.1");
  });
});

describe("snowflakeAuthHeaders", () => {
  const spcs = loadConfig({ SNOWFLAKE_HOST: "h" }, () => true);
  const read = () => "service-token\n";

  it("is not used for local runs, which sign in with OAuth", () => {
    expect(() => snowflakeAuthHeaders(local)).toThrow(/OAuthSession/);
  });

  it("sends the SPCS service token as OAuth", () => {
    expect(snowflakeAuthHeaders(spcs, read)).toEqual({
      Authorization: "Bearer service-token",
      "X-Snowflake-Authorization-Token-Type": "OAUTH",
    });
  });
});

describe("createLiveSession", () => {
  it("posts a client-delegation session to the gateway and returns the SDP answer", async () => {
    let body: Record<string, any> = {};
    let url = "";
    const fetchImpl = (async (u: string, init: RequestInit) => {
      url = u;
      body = JSON.parse(String(init.body));
      return new Response(JSON.stringify({ session: { id: "live_123" }, transport: { sdp: "v=0 answer" } }), { status: 201 });
    }) as unknown as typeof fetch;

    const created = await createLiveSession(local, "v=0\r\noffer", {}, fetchImpl);

    expect(url).toBe(liveSessionsUrl(local));
    expect(url).toBe("https://myorg-myacct.snowflakecomputing.com/api/v2/aigateways/snowflake/v1/live/sessions");
    expect(body.session.model).toBe("openai-gpt-live-1");
    expect(body.session.delegation).toEqual({ type: "client" });
    expect(body.session.tools).toBeUndefined();
    expect(body.transport).toEqual({ type: "webrtc", sdp: "v=0\r\noffer\r\n" });
    expect(created).toEqual({ sessionId: "live_123", answerSdp: "v=0 answer" });
  });

  it("explains an empty 401 and includes the request id", async () => {
    const fetchImpl = (async () =>
      new Response("", { status: 401, headers: { "x-snowflake-request-id": "rid-1" } })) as unknown as typeof fetch;
    await expect(createLiveSession(local, "v=0", {}, fetchImpl)).rejects.toThrow(/Enable openai-gpt-live-1 on your account.*rid-1.*Empty body/);
  });

  it("names the host and operation when the request never gets a response, keeping the cause", async () => {
    const error = await createLiveSession(local, "v=0", {}, networkFailure).catch((e: unknown) => e);
    expect(error).toBeInstanceOf(LiveSessionError);
    expect((error as Error).message).toMatch(/openai-gpt-live-1 session create: no response from myorg-myacct\.snowflakecomputing\.com .*ENOTFOUND/);
    expect((error as Error).cause).toBeInstanceOf(TypeError);
  });
});
