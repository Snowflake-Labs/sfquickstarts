import fs from "node:fs";

/**
 * Who the server acts as when it calls Snowflake.
 *
 *   oauth    Local runs. The user signs in with Snowflake OAuth in the browser;
 *            the server keeps the token in memory (see oauth.ts).
 *   service  SPCS. The token Snowflake mounts at /snowflake/session/token, so
 *            every call runs as the service's owner role.
 */
export type AuthMode = "oauth" | "service";

export type Config = {
  port: number;
  host: string;
  /** Base URL for every Snowflake REST call, no trailing slash. */
  snowflakeUrl: string;
  authMode: AuthMode;
  /** Local only: the public OAuth client setup.sql creates. Not a secret. */
  oauthClientId?: string;
  /** Local only: where Snowflake sends the browser back after sign-in. Must match the integration. */
  oauthRedirectUri: string;
  spcsTokenFile: string;
  aiGatewayName: string;
  liveModel: string;
  voice: string;
  agentDatabase: string;
  agentSchema: string;
  agentName: string;
  agentTimeoutMs: number;
  /**
   * The view with today's precomputed briefing (one row, column BRIEF), read
   * when a call starts and added to openai-gpt-live-1's instructions. Empty when BRIEF_VIEW is off.
   */
  briefView: string;
  /** Warehouse for reading the briefing. */
  warehouse: string;
  /**
   * The role the local sign-in asks for, which also reads the briefing.
   * Empty: the user's default role.
   */
  role: string;
};

export const SPCS_TOKEN_FILE = "/snowflake/session/token";


function required(env: NodeJS.ProcessEnv, name: string): string {
  const value = env[name]?.trim();
  if (!value) throw new Error(`${name} is required. See .env.example.`);
  return value;
}

/** The account's base URL. HTTPS only: the token goes in every request to it. */
function baseUrl(raw: string): string {
  if (/^http:\/\//i.test(raw)) throw new Error(`The Snowflake URL must use https://, not "${raw}".`);
  const withScheme = /^https:\/\//i.test(raw) ? raw : `https://${raw}`;
  return withScheme.replace(/\/+$/, "");
}

/**
 * Read configuration from the environment.
 *
 * On SPCS, Snowflake injects SNOWFLAKE_HOST and mounts the service token; the
 * token is only valid against that host, so it wins over SNOWFLAKE_ACCOUNT_URL.
 */
export function loadConfig(
  env: NodeJS.ProcessEnv = process.env,
  fileExists: (p: string) => boolean = fs.existsSync,
): Config {
  const spcsTokenFile = env.SNOWFLAKE_TOKEN_FILE?.trim() || SPCS_TOKEN_FILE;
  const onSpcs = fileExists(spcsTokenFile);

  // LISTEN_* rather than PORT/HOST: shells often export those for other tools.
  const port = positiveInt(env, "LISTEN_PORT", 3000);
  let authMode: AuthMode;
  let oauthClientId: string | undefined;
  let snowflakeUrl: string;
  if (onSpcs) {
    authMode = "service";
    snowflakeUrl = baseUrl(required(env, "SNOWFLAKE_HOST"));
  } else {
    authMode = "oauth";
    oauthClientId = required(env, "SNOWFLAKE_OAUTH_CLIENT_ID");
    snowflakeUrl = baseUrl(required(env, "SNOWFLAKE_ACCOUNT_URL"));
  }

  const host = env.LISTEN_HOST?.trim() || (onSpcs ? "0.0.0.0" : "127.0.0.1");
  // Locally the server holds your Snowflake sign-in. Its Host check stops other
  // web pages, not other machines, so it must not listen beyond this machine.
  if (authMode === "oauth" && !["127.0.0.1", "localhost", "::1"].includes(host)) {
    throw new Error(`LISTEN_HOST must be 127.0.0.1, localhost or ::1 for local runs, not "${host}": the server holds your Snowflake sign-in.`);
  }

  return {
    port,
    host,
    snowflakeUrl,
    authMode,
    oauthClientId,
    oauthRedirectUri: env.OAUTH_REDIRECT_URI?.trim() || `http://127.0.0.1:${port}/oauth/callback`,
    spcsTokenFile,
    aiGatewayName: env.AI_GATEWAY_NAME?.trim() || "snowflake",
    liveModel: env.GPT_LIVE_MODEL?.trim() || "openai-gpt-live-1",
    voice: env.GPT_LIVE_VOICE?.trim() || "marin",
    agentDatabase: env.AGENT_DATABASE?.trim() || "GPT_LIVE_SHOWCASE",
    agentSchema: env.AGENT_SCHEMA?.trim() || "FIELD_SALES",
    agentName: env.AGENT_NAME?.trim() || "FIELD_SALES_AGENT",
    agentTimeoutMs: positiveInt(env, "AGENT_TIMEOUT_MS", 120_000),
    briefView: objectName(env, "BRIEF_VIEW", "GPT_LIVE_SHOWCASE.FIELD_SALES.DAY_BRIEF"),
    warehouse: objectName(env, "SNOWFLAKE_WAREHOUSE", "GPT_LIVE_SHOWCASE_WH"),
    role: objectName(env, "SNOWFLAKE_ROLE", "GPT_LIVE_SHOWCASE_ROLE"),
  };
}

/**
 * A Snowflake object name from the environment, used inside SQL. Only plain
 * (optionally dotted) identifiers are allowed, so a setting can't inject SQL.
 * Set to "" or "off" to turn the feature off.
 */
function objectName(env: NodeJS.ProcessEnv, name: string, fallback: string): string {
  const raw = env[name];
  if (raw === undefined) return fallback;
  const value = raw.trim();
  if (value === "" || value.toLowerCase() === "off") return "";
  if (!/^[A-Za-z_][A-Za-z0-9_$]*(\.[A-Za-z_][A-Za-z0-9_$]*){0,2}$/.test(value)) {
    throw new Error(`${name} must be a Snowflake object name such as DB.SCHEMA.NAME, not "${raw}".`);
  }
  return value;
}

function positiveInt(env: NodeJS.ProcessEnv, name: string, fallback: number): number {
  const raw = env[name]?.trim();
  if (!raw) return fallback;
  const value = Number(raw);
  if (!Number.isInteger(value) || value <= 0) {
    throw new Error(`${name} must be a positive whole number, not "${raw}".`);
  }
  return value;
}

/** Load ./.env if present. Variables already set in the shell win. */
export function loadDotEnv(file = ".env"): void {
  if (fs.existsSync(file)) process.loadEnvFile(file);
}
