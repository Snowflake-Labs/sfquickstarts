import crypto from "node:crypto";
import { describe, expect, it } from "vitest";
import { AuthError } from "./auth.js";
import { loadConfig } from "./config.js";
import { MAX_PENDING_SIGN_INS, OAuthSession, REFRESH_EARLY_MS, SIGN_IN_WAIT_MS } from "./oauth.js";

const config = loadConfig(
  { SNOWFLAKE_ACCOUNT_URL: "https://acct.snowflakecomputing.com", SNOWFLAKE_OAUTH_CLIENT_ID: "client-id" },
  () => false,
);

type Sent = { url: string; form: URLSearchParams };

/** A token endpoint that records each request and answers with the next reply. */
function tokenEndpoint(replies: Array<{ status?: number; body: Record<string, unknown> }>) {
  const sent: Sent[] = [];
  const fetchImpl = (async (url: string, init: RequestInit) => {
    sent.push({ url, form: new URLSearchParams(String(init.body)) });
    const reply = replies.shift() ?? { status: 500, body: {} };
    return new Response(JSON.stringify(reply.body), { status: reply.status ?? 200 });
  }) as unknown as typeof fetch;
  return { sent, fetchImpl };
}

const granted = (access: string, expiresIn = 600) => ({
  body: { access_token: access, refresh_token: "refresh-1", expires_in: expiresIn, username: "ANA" },
});

function signInParams(session: OAuthSession) {
  return new URL(session.loginUrl()).searchParams;
}

describe("OAuthSession sign-in", () => {
  it("sends the browser to Snowflake with PKCE, a state and the app role only", () => {
    const params = new URL(new OAuthSession(config).loginUrl());
    expect(params.origin + params.pathname).toBe("https://acct.snowflakecomputing.com/oauth/authorize");
    expect(params.searchParams.get("client_id")).toBe("client-id");
    expect(params.searchParams.get("response_type")).toBe("code");
    expect(params.searchParams.get("redirect_uri")).toBe("http://127.0.0.1:3000/oauth/callback");
    expect(params.searchParams.get("scope")).toBe("session:role:GPT_LIVE_SHOWCASE_ROLE refresh_token");
    expect(params.searchParams.get("code_challenge_method")).toBe("S256");
    expect(params.searchParams.get("state")?.length).toBeGreaterThan(20);
  });

  it("exchanges the code with the matching PKCE verifier, and then sends the token as OAuth", async () => {
    const { sent, fetchImpl } = tokenEndpoint([granted("access-1")]);
    const session = new OAuthSession(config, fetchImpl);
    const params = signInParams(session);

    const browserKey = await session.completeSignIn("the-code", params.get("state")!);

    expect(sent[0].url).toBe("https://acct.snowflakecomputing.com/oauth/token-request");
    expect(sent[0].form.get("grant_type")).toBe("authorization_code");
    expect(sent[0].form.get("code")).toBe("the-code");
    const verifier = sent[0].form.get("code_verifier")!;
    expect(crypto.createHash("sha256").update(verifier).digest("base64url")).toBe(params.get("code_challenge"));
    expect(session.signedIn).toBe(true);
    expect(session.user).toBe("ANA");
    expect(await session.headers()).toEqual({
      Authorization: "Bearer access-1",
      "X-Snowflake-Authorization-Token-Type": "OAUTH",
    });
    expect(session.owns(browserKey)).toBe(true);
  });

  it("belongs only to the browser that completed it, and a new sign-in replaces the old one", async () => {
    const { fetchImpl } = tokenEndpoint([granted("access-1"), granted("access-2")]);
    const session = new OAuthSession(config, fetchImpl);
    const first = await session.completeSignIn("code", signInParams(session).get("state")!);
    expect(session.owns(undefined)).toBe(false);
    expect(session.owns("someone-else")).toBe(false);
    expect(session.owns(first.slice(0, -1))).toBe(false);

    const second = await session.completeSignIn("code", signInParams(session).get("state")!);
    expect(session.owns(second)).toBe(true);
    expect(session.owns(first)).toBe(false);
  });

  it("refuses a state it didn't start, a reused one, or one that waited too long", async () => {
    let now = 0;
    const { fetchImpl } = tokenEndpoint([granted("access-1")]);
    const session = new OAuthSession(config, fetchImpl, () => now);
    await expect(session.completeSignIn("code", "made-up")).rejects.toBeInstanceOf(AuthError);

    const state = signInParams(session).get("state")!;
    await session.completeSignIn("code", state);
    await expect(session.completeSignIn("code", state)).rejects.toBeInstanceOf(AuthError);

    const late = signInParams(session).get("state")!;
    now = SIGN_IN_WAIT_MS + 1;
    await expect(session.completeSignIn("code", late)).rejects.toBeInstanceOf(AuthError);
  });

  it("keeps only the newest sign-ins waiting, so a page that starts many can't pile them up", async () => {
    const { fetchImpl } = tokenEndpoint([granted("access-1")]);
    const session = new OAuthSession(config, fetchImpl);
    const first = signInParams(session).get("state")!;
    for (let i = 0; i < MAX_PENDING_SIGN_INS; i++) signInParams(session);
    await expect(session.completeSignIn("code", first)).rejects.toBeInstanceOf(AuthError);
  });

  it("is signed out until a sign-in completes", async () => {
    const session = new OAuthSession(config);
    expect(session.signedIn).toBe(false);
    expect(session.owns("any")).toBe(false);
    await expect(session.headers()).rejects.toThrow(/Sign in with Snowflake/);
  });

  it("reports a refused token request without echoing anything secret", async () => {
    const { fetchImpl } = tokenEndpoint([{ status: 400, body: { error: "invalid_grant", message: "Authorization code expired" } }]);
    const session = new OAuthSession(config, fetchImpl);
    const error = await session.completeSignIn("code", signInParams(session).get("state")!).catch((e: unknown) => e);
    expect(error).toBeInstanceOf(AuthError);
    expect(String(error)).toMatch(/\(400\): Authorization code expired/);
    expect(session.signedIn).toBe(false);
  });
});

describe("OAuthSession refresh", () => {
  it("refreshes shortly before the access token expires, once for calls that arrive together", async () => {
    let now = 0;
    const { sent, fetchImpl } = tokenEndpoint([granted("access-1", 600), granted("access-2", 600)]);
    const session = new OAuthSession(config, fetchImpl, () => now);
    await session.completeSignIn("code", signInParams(session).get("state")!);

    now = 600_000 - REFRESH_EARLY_MS;
    const [a, b] = await Promise.all([session.headers(), session.headers()]);

    expect(sent).toHaveLength(2);
    expect(sent[1].form.get("grant_type")).toBe("refresh_token");
    expect(sent[1].form.get("refresh_token")).toBe("refresh-1");
    expect(a.Authorization).toBe("Bearer access-2");
    expect(b.Authorization).toBe("Bearer access-2");
  });

  it("signs out when the refresh is refused", async () => {
    let now = 0;
    const { fetchImpl } = tokenEndpoint([granted("access-1", 600), { status: 400, body: { error: "invalid_grant" } }]);
    const session = new OAuthSession(config, fetchImpl, () => now);
    await session.completeSignIn("code", signInParams(session).get("state")!);

    now = 600_000;
    await expect(session.headers()).rejects.toBeInstanceOf(AuthError);
    expect(session.signedIn).toBe(false);
  });
});
