import type { Config } from "./config.js";
import { errorText } from "./errors.js";

/** One Cortex Agents message. The API takes only user and assistant roles. */
export type AgentMessage = {
  role: "user" | "assistant";
  content: { type: "text"; text: string }[];
};

/** What the delegation layer needs to hear about a run as it streams. */
export type AgentRunCallbacks = {
  /** A response.status event: planning, executing_tools, proceeding_to_answer, … */
  onStatus?: (status: string, message?: string) => void;
  /** A response.tool_use event, by tool type (e.g. cortex_analyst_text_to_sql). */
  onToolUse?: (toolType: string) => void;
};

export type AgentRunResult = {
  text: string;
  toolTypes: string[];
  totalMs: number;
};

export class AgentError extends Error {
  constructor(
    message: string,
    readonly status?: number,
    options?: ErrorOptions,
  ) {
    super(message, options);
    this.name = "AgentError";
  }
}

export type SseFrame = { event?: string; data: string };

/**
 * Split complete SSE frames off a growing buffer.
 *
 * Frames end at a blank line, `data:` may repeat and is joined with a newline,
 * and lines starting with ':' are keepalive comments.
 */
export function parseFrames(buffer: string): { frames: SseFrame[]; rest: string } {
  const chunks = buffer.replace(/\r\n/g, "\n").split("\n\n");
  const rest = chunks.pop() ?? "";
  const frames: SseFrame[] = [];
  for (const chunk of chunks) {
    let event: string | undefined;
    const data: string[] = [];
    for (const line of chunk.split("\n")) {
      if (!line || line.startsWith(":")) continue;
      if (line.startsWith("event:")) event = line.slice(6).trim();
      else if (line.startsWith("data:")) data.push(line.slice(5).trim());
    }
    if (data.length > 0) frames.push({ event, data: data.join("\n") });
  }
  return { frames, rest };
}

type RunState = { text: string; finalText?: string; toolTypes: string[]; textBlock?: unknown };

/**
 * Apply one Agents API frame. Unknown event types are ignored: the stream
 * carries many (thinking, tables, charts, annotations) that a voice answer does
 * not use, and new ones appear without notice.
 */
export function applyFrame(frame: SseFrame, state: RunState, callbacks: AgentRunCallbacks): void {
  if (frame.data === "[DONE]") return;
  let payload: Record<string, unknown>;
  try {
    payload = JSON.parse(frame.data);
  } catch {
    return;
  }
  const type = frame.event || (typeof payload.type === "string" ? payload.type : "");

  switch (type) {
    case "response.text.delta": {
      // Text blocks with no tool call between them are one answer: keep both,
      // with a space between.
      const block = payload.content_index;
      if (state.text && block !== undefined && block !== state.textBlock) state.text += " ";
      state.textBlock = block;
      state.text += String(payload.text ?? payload.delta ?? "");
      break;
    }
    case "response.text":
      // Some runs send the whole answer once instead of, or as well as, deltas.
      if (typeof payload.text === "string") state.finalText = payload.text;
      break;
    case "response.status": {
      const status = String(payload.status ?? "");
      if (status) callbacks.onStatus?.(status, payload.message != null ? String(payload.message) : undefined);
      break;
    }
    case "response.tool_use": {
      // Text written before a tool call is the agent thinking aloud ("No name
      // given, so use the next meeting's prescriber."), not the answer: the
      // answer is the text after the last tool call.
      state.text = "";
      state.finalText = undefined;
      const toolUse = payload.tool_use as Record<string, unknown> | undefined;
      const toolType = String(payload.tool_type ?? toolUse?.type ?? payload.type ?? "tool");
      if (!state.toolTypes.includes(toolType)) state.toolTypes.push(toolType);
      callbacks.onToolUse?.(toolType);
      break;
    }
    case "error": {
      const nested = payload.error as { message?: unknown } | undefined;
      throw new AgentError(`Cortex Agent error: ${String(payload.message ?? nested?.message ?? frame.data)}`);
    }
    default:
      break;
  }
}

export function agentRunUrl(config: Config): string {
  return (
    `${config.snowflakeUrl}/api/v2/databases/${encodeURIComponent(config.agentDatabase)}` +
    `/schemas/${encodeURIComponent(config.agentSchema)}` +
    `/agents/${encodeURIComponent(config.agentName)}:run`
  );
}

function describeHttpError(status: number, body: string, config: Config): string {
  const target = `${config.agentDatabase}.${config.agentSchema}.${config.agentName}`;
  const detail = body.slice(0, 300);
  if (status === 401) return `Cortex Agents refused the token (401). ${detail}`;
  if (status === 403) return `The role may not use agent ${target} (403). Check the grants in setup.sql. ${detail}`;
  if (status === 404) return `Agent ${target} not found (404). Run snowflake/setup.sql or check AGENT_*. ${detail}`;
  return `Cortex Agents request failed (${status}). ${detail}`;
}

/** Run the agent once, streaming, and return its final text. */
export async function runAgent(
  config: Config,
  messages: AgentMessage[],
  authHeaders: Record<string, string>,
  callbacks: AgentRunCallbacks = {},
  signal?: AbortSignal,
  fetchImpl: typeof fetch = fetch,
): Promise<AgentRunResult> {
  const startedAt = Date.now();
  const timeout = AbortSignal.timeout(config.agentTimeoutMs);
  const combined = signal ? AbortSignal.any([signal, timeout]) : timeout;

  const url = agentRunUrl(config);
  let response: Response;
  try {
    response = await fetchImpl(url, {
      method: "POST",
      headers: { ...authHeaders, "Content-Type": "application/json", Accept: "text/event-stream" },
      body: JSON.stringify({ messages, stream: true }),
      signal: combined,
    });
  } catch (error) {
    throw new AgentError(`Cortex Agents run: no response from ${new URL(url).host} (${errorText(error)}).`, undefined, {
      cause: error,
    });
  }
  if (!response.ok) {
    throw new AgentError(describeHttpError(response.status, await response.text().catch(() => ""), config), response.status);
  }
  if (!response.body) throw new AgentError("Cortex Agents returned no body.");

  const state: RunState = { text: "", toolTypes: [] };
  const decoder = new TextDecoder();
  const reader = response.body.getReader();
  let buffer = "";
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const parsed = parseFrames(buffer);
    buffer = parsed.rest;
    for (const frame of parsed.frames) applyFrame(frame, state, callbacks);
  }
  for (const frame of parseFrames(`${buffer}\n\n`).frames) applyFrame(frame, state, callbacks);

  return {
    text: (state.text || state.finalText || "").trim(),
    toolTypes: state.toolTypes,
    totalMs: Date.now() - startedAt,
  };
}
