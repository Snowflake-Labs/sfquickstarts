import type { Config } from "./config.js";
import { errorText } from "./errors.js";

/**
 * Today's precomputed briefing: one line per scheduled visit, built
 * by the DAY_BRIEF view in setup.sql and read through the Snowflake SQL API
 * when a call starts. openai-gpt-live-1 gets it in its instructions, so questions it
 * covers are answered at once instead of through a Cortex Agent lookup.
 *
 * Optional by design: if the view is missing or slow, the call starts without
 * a briefing and every data question goes to the agent.
 */

/** Reading the view normally takes 1–2 s; the call must not wait much longer. */
export const BRIEF_TIMEOUT_MS = 5000;
/** The briefing describes a day, so reuse it for a while across calls. */
export const BRIEF_TTL_MS = 10 * 60_000;
/** After a failure, don't make every call start wait for the same failure. */
export const BRIEF_RETRY_MS = 60_000;
/** Keep the instructions well inside openai-gpt-live-1's limit. */
export const BRIEF_MAX_CHARS = 6000;

export function statementsUrl(config: Config): string {
  return `${config.snowflakeUrl}/api/v2/statements`;
}

/** The text of the first column of the first row of a SQL API response, if any. */
export function briefFromResponse(body: unknown): string | undefined {
  const data = (body as { data?: unknown })?.data;
  const value = Array.isArray(data) && Array.isArray(data[0]) ? data[0][0] : undefined;
  if (typeof value !== "string" || !value.trim()) return undefined;
  const text = value.trim();
  return text.length <= BRIEF_MAX_CHARS ? text : `${text.slice(0, BRIEF_MAX_CHARS - 1).trimEnd()}…`;
}

/** Read the briefing once. Throws on any failure; see BriefCache for the forgiving path. */
export async function fetchBrief(
  config: Config,
  authHeaders: Record<string, string>,
  fetchImpl: typeof fetch = fetch,
): Promise<string | undefined> {
  const response = await fetchImpl(statementsUrl(config), {
    method: "POST",
    headers: { ...authHeaders, "Content-Type": "application/json", Accept: "application/json" },
    // config.briefView is validated as an object name in config.ts.
    // timeout: Snowflake's own limit, in seconds; BRIEF_TIMEOUT_MS gives up sooner here.
    // An explicit role, so the read doesn't depend on the user's default role.
    body: JSON.stringify({
      statement: `SELECT BRIEF FROM ${config.briefView}`,
      // "off" for either leaves it to the user's default.
      ...(config.warehouse ? { warehouse: config.warehouse } : {}),
      ...(config.role ? { role: config.role } : {}),
      timeout: 10,
    }),
    signal: AbortSignal.timeout(BRIEF_TIMEOUT_MS),
  });
  const body: unknown = await response.json().catch(() => ({}));
  if (!response.ok) {
    const message = (body as { message?: unknown })?.message;
    throw new Error(`Briefing query failed (${response.status})${typeof message === "string" ? `: ${message.slice(0, 300)}` : ""}`);
  }
  return briefFromResponse(body);
}

/**
 * The briefing, cached for BRIEF_TTL_MS. Never throws: a failure is reported
 * through `onError` and the call goes on without a briefing.
 */
export class BriefCache {
  private value: string | undefined;
  /** When the briefing was last read; undefined: not yet. */
  private readAt: number | undefined;
  /** When the last read failed; undefined: no failure yet. */
  private failedAt: number | undefined;

  constructor(
    private readonly config: Config,
    private readonly onError: (message: string) => void,
    private readonly fetchImpl: typeof fetch = fetch,
    private readonly now: () => number = Date.now,
  ) {}

  async get(authHeaders: Record<string, string>): Promise<string | undefined> {
    if (!this.config.briefView) return undefined;
    if (this.readAt !== undefined && this.now() - this.readAt < BRIEF_TTL_MS) return this.value;
    if (this.failedAt !== undefined && this.now() - this.failedAt < BRIEF_RETRY_MS) return undefined;
    try {
      const value = await fetchBrief(this.config, authHeaders, this.fetchImpl);
      this.value = value;
      this.readAt = this.now();
      return value;
    } catch (error) {
      this.failedAt = this.now();
      this.onError(errorText(error));
      return undefined;
    }
  }
}
