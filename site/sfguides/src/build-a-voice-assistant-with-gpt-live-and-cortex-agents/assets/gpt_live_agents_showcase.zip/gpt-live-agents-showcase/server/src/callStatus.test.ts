import { describe, expect, it } from "vitest";
// Browser module: plain JS, no DOM, so it runs under Node as is.
import { callStatus, formatDuration, startError } from "../../web/callStatus.js";

describe("startError", () => {
  it("ends any other message with one full stop before the retry prompt", () => {
    expect(startError(new Error("Could not start audio source"))).toBe("Could not start audio source. Try again.");
    expect(startError(new Error("Something broke."))).toBe("Something broke. Try again.");
  });

  it("says what to do about the microphone", () => {
    expect(startError(Object.assign(new Error("x"), { name: "NotAllowedError" }))).toMatch(/blocked.*address bar/);
    expect(startError(Object.assign(new Error("x"), { name: "NotFoundError" }))).toMatch(/No microphone/);
    expect(startError(Object.assign(new Error("x"), { name: "NotReadableError" }))).toMatch(/in use by another app/);
  });

  it("explains a server that can't be reached", () => {
    expect(startError(new TypeError("Failed to fetch"))).toMatch(/Can't reach the app server/);
    expect(startError(new TypeError("Load failed"))).toMatch(/Can't reach the app server/);
    // A TypeError from a bug is not a network problem.
    expect(startError(new TypeError("Cannot read properties of null"))).toBe("Cannot read properties of null. Try again.");
  });

  it("turns a session create failure into a retry prompt", () => {
    expect(startError(new Error("openai-gpt-live-1 session create failed (400). Details are in the server logs."))).toBe(
      "The voice service didn't start the call (400). Try again. Details are in the server logs.",
    );
  });
});

describe("callStatus", () => {
  it("says connecting before anything else", () => {
    expect(callStatus({ connecting: true, userSpeaking: true, lookups: 2 })).toMatchObject({ state: "connecting", text: "Connecting…" });
  });

  it("tells the user it is their turn when nothing is going on", () => {
    expect(callStatus({})).toMatchObject({ state: "listening", text: "Listening, your turn" });
  });

  it("puts the user first, and keeps a running lookup and a held answer visible", () => {
    expect(callStatus({ userSpeaking: true, assistantSpeaking: true, lookups: 1, heldAnswer: true })).toEqual({
      state: "hearing",
      text: "You're speaking · looking it up · answer ready",
      hint: "The answer plays when you pause.",
    });
  });

  it("shows a lookup while nobody talks", () => {
    expect(callStatus({ lookups: 1 })).toMatchObject({ state: "thinking", text: "Looking it up in Snowflake…" });
    expect(callStatus({ lookups: 2 }).text).toBe("2 lookups running in Snowflake…");
  });

  it("ignores user speech while muted and says so", () => {
    expect(callStatus({ muted: true, userSpeaking: true })).toMatchObject({ state: "muted", text: "Muted" });
    expect(callStatus({ muted: true, assistantSpeaking: true })).toMatchObject({ state: "speaking", text: "Assistant speaking · muted" });
    expect(callStatus({ muted: true, lookups: 1 }).text).toBe("Looking it up in Snowflake… · muted");
  });
});

describe("callStatus hints", () => {
  it("says what the user can do in each state", () => {
    expect(callStatus({}).hint).toMatch(/Ask about/);
    expect(callStatus({ assistantSpeaking: true }).hint).toBe("Talk any time to interrupt.");
    expect(callStatus({ lookups: 1 }).hint).toBe("You can keep talking while it looks.");
    expect(callStatus({ muted: true }).hint).toBe("Press Unmute or M to talk again.");
    // Muted, the assistant can't hear "keep talking" or an interruption.
    expect(callStatus({ muted: true, lookups: 1 }).hint).toBe("Unmute to talk.");
    expect(callStatus({ muted: true, assistantSpeaking: true }).hint).toBe("Unmute to talk.");
    expect(callStatus({ userSpeaking: true }).hint).toBe("Pause when you're done.");
  });
});

describe("formatDuration", () => {
  it("formats minutes and seconds", () => {
    expect(formatDuration(0)).toBe("0:00");
    expect(formatDuration(7_900)).toBe("0:07");
    expect(formatDuration(83_000)).toBe("1:23");
    expect(formatDuration(725_000)).toBe("12:05");
  });
});

describe("startError for the session limit", () => {
  it("says to wait when too many calls were started", () => {
    expect(startError(new Error("The request failed (429). Details are in the server logs."))).toBe(
      "Too many calls started in the last minute. Wait a moment, then start again.",
    );
  });
});

describe("startError for an ended sign-in", () => {
  it("says to sign in again", () => {
    expect(startError(new Error("The request failed (401). Details are in the server logs."))).toBe(
      "Your Snowflake sign-in has ended. Reload the page and sign in again.",
    );
    // A 401 from openai-gpt-live-1 itself keeps its own wording.
    expect(startError(new Error("openai-gpt-live-1 session create failed (401). Details are in the server logs."))).toMatch(/voice service/);
  });
});
