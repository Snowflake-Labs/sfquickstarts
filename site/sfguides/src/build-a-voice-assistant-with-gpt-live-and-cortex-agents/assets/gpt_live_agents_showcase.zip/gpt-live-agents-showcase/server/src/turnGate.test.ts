import { describe, expect, it, vi } from "vitest";
// Browser module: plain JS, no DOM, so it runs under Node as is.
import { TurnGate } from "../../web/turnGate.js";

describe("TurnGate", () => {
  it("hands a delegation the user turn that already landed", async () => {
    const gate = new TurnGate();
    gate.userTurnLanded();
    await expect(gate.claim()).resolves.toBe(true);
  });

  it("holds a delegation that arrives before its transcript, then releases it when the turn lands", async () => {
    vi.useFakeTimers();
    try {
      const gate = new TurnGate({ waitMs: 4000 });
      gate.userTurnLanded();
      await gate.claim(); // first question, already relayed
      let settled: boolean | undefined;
      void gate.claim().then((ok) => (settled = ok));
      await vi.advanceTimersByTimeAsync(1000);
      expect(settled).toBeUndefined(); // the old question is not reused
      expect(gate.pending).toBe(1);
      gate.userTurnLanded();
      await vi.advanceTimersByTimeAsync(0);
      expect(settled).toBe(true);
      expect(gate.pending).toBe(0);
    } finally {
      vi.useRealTimers();
    }
  });

  it("gives up rather than relay a stale question", async () => {
    vi.useFakeTimers();
    try {
      const gate = new TurnGate({ waitMs: 4000 });
      gate.userTurnLanded();
      await gate.claim();
      const waiting = gate.claim();
      await vi.advanceTimersByTimeAsync(4000);
      await expect(waiting).resolves.toBe(false);
    } finally {
      vi.useRealTimers();
    }
  });

  it("with speech still being transcribed, skips an older unused turn and waits for the new one", async () => {
    const gate = new TurnGate();
    gate.userTurnLanded(); // "thanks", never delegated
    let settled: boolean | undefined;
    const waiting = gate.claim({ awaitNext: true }).then((ok) => (settled = ok));
    await Promise.resolve();
    expect(settled).toBeUndefined();
    gate.userTurnLanded(); // the question behind this delegation
    await waiting;
    expect(settled).toBe(true);
  });

  it("gives one new turn to one delegation; a second keeps waiting", async () => {
    const gate = new TurnGate();
    const first = gate.claim();
    const second = gate.claim();
    gate.userTurnLanded();
    await expect(first).resolves.toBe(true);
    expect(gate.pending).toBe(1);
    gate.cancel();
    await expect(second).resolves.toBe(false);
  });

  it("calls its timers as plain functions, as browsers require of setTimeout", async () => {
    // Browsers throw "Illegal invocation" when setTimeout runs with `this` set
    // to another object; Node doesn't, so mimic the browser here.
    function strictSetTimer(this: unknown, fn: () => void, ms: number) {
      if (this !== undefined && this !== globalThis) throw new TypeError("Illegal invocation");
      return setTimeout(fn, ms);
    }
    function strictClearTimer(this: unknown, id: ReturnType<typeof setTimeout>) {
      if (this !== undefined && this !== globalThis) throw new TypeError("Illegal invocation");
      clearTimeout(id);
    }
    const gate = new TurnGate({
      waitMs: 10,
      setTimer: strictSetTimer as unknown as typeof setTimeout,
      clearTimer: strictClearTimer as unknown as typeof clearTimeout,
    });
    const waiting = gate.claim({ awaitNext: true });
    gate.userTurnLanded();
    await expect(waiting).resolves.toBe(true);
    await expect(gate.claim()).resolves.toBe(false); // timed out through the strict timer
  });
});
