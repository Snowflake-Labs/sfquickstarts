import { describe, expect, it, vi } from "vitest";
import { BRIEF_MAX_CHARS, BRIEF_RETRY_MS, BRIEF_TTL_MS, BriefCache, briefFromResponse, fetchBrief } from "./brief.js";
import { loadConfig } from "./config.js";

const base = { SNOWFLAKE_ACCOUNT_URL: "https://acct.snowflakecomputing.com", SNOWFLAKE_OAUTH_CLIENT_ID: "client-id" };
const local = loadConfig(base, () => false);
const ok = (brief: string) => new Response(JSON.stringify({ data: [[brief]] }), { status: 200 });

describe("briefing settings", () => {
  it("defaults to the view, warehouse and role setup.sql creates", () => {
    expect(local.briefView).toBe("GPT_LIVE_SHOWCASE.FIELD_SALES.DAY_BRIEF");
    expect(local.warehouse).toBe("GPT_LIVE_SHOWCASE_WH");
    expect(local.role).toBe("GPT_LIVE_SHOWCASE_ROLE");
  });

  it("can be turned off", () => {
    expect(loadConfig({ ...base, BRIEF_VIEW: "" }, () => false).briefView).toBe("");
    expect(loadConfig({ ...base, BRIEF_VIEW: "off" }, () => false).briefView).toBe("");
  });

  it("refuses anything but an object name, since it goes into SQL", () => {
    expect(() => loadConfig({ ...base, BRIEF_VIEW: "X; DROP TABLE Y" }, () => false)).toThrow(/BRIEF_VIEW/);
    expect(() => loadConfig({ ...base, SNOWFLAKE_WAREHOUSE: "wh'--" }, () => false)).toThrow(/SNOWFLAKE_WAREHOUSE/);
    expect(loadConfig({ ...base, BRIEF_VIEW: "MY_DB.MY_SCHEMA.MY_BRIEF" }, () => false).briefView).toBe("MY_DB.MY_SCHEMA.MY_BRIEF");
  });
});

describe("briefFromResponse", () => {
  it("reads the first column of the first row", () => {
    expect(briefFromResponse({ data: [["  Today is Fri.  "]] })).toBe("Today is Fri.");
  });

  it("is undefined when the view returned nothing", () => {
    expect(briefFromResponse({ data: [] })).toBeUndefined();
    expect(briefFromResponse({ data: [[null]] })).toBeUndefined();
    expect(briefFromResponse({})).toBeUndefined();
  });

  it("caps a long briefing", () => {
    expect(briefFromResponse({ data: [["x".repeat(BRIEF_MAX_CHARS + 50)]] })).toHaveLength(BRIEF_MAX_CHARS);
  });
});

describe("fetchBrief", () => {
  it("runs one SELECT on the configured view and warehouse, with the given auth", async () => {
    const fetchImpl = vi.fn(async () => ok("Today is Fri."));
    const brief = await fetchBrief(local, { Authorization: "Bearer t" }, fetchImpl as unknown as typeof fetch);
    expect(brief).toBe("Today is Fri.");
    const [url, init] = fetchImpl.mock.calls[0] as unknown as [string, RequestInit];
    expect(url).toBe("https://acct.snowflakecomputing.com/api/v2/statements");
    expect(init.headers).toMatchObject({ Authorization: "Bearer t" });
    expect(JSON.parse(String(init.body))).toMatchObject({
      statement: "SELECT BRIEF FROM GPT_LIVE_SHOWCASE.FIELD_SALES.DAY_BRIEF",
      warehouse: "GPT_LIVE_SHOWCASE_WH",
      role: "GPT_LIVE_SHOWCASE_ROLE",
    });
  });

  it("leaves the role to the token's default when SNOWFLAKE_ROLE is off", async () => {
    const fetchImpl = vi.fn(async () => ok("Today is Fri."));
    await fetchBrief(loadConfig({ ...base, SNOWFLAKE_ROLE: "off" }, () => false), {}, fetchImpl as unknown as typeof fetch);
    const [, init] = fetchImpl.mock.calls[0] as unknown as [string, RequestInit];
    expect(JSON.parse(String(init.body))).not.toHaveProperty("role");
  });

  it("leaves the warehouse to the token's default when SNOWFLAKE_WAREHOUSE is off", async () => {
    const fetchImpl = vi.fn(async () => ok("Today is Fri."));
    await fetchBrief(loadConfig({ ...base, SNOWFLAKE_WAREHOUSE: "off" }, () => false), {}, fetchImpl as unknown as typeof fetch);
    const [, init] = fetchImpl.mock.calls[0] as unknown as [string, RequestInit];
    expect(JSON.parse(String(init.body))).not.toHaveProperty("warehouse");
  });

  it("throws with Snowflake's message when the query fails", async () => {
    const fetchImpl = async () => new Response(JSON.stringify({ message: "Object 'DAY_BRIEF' does not exist" }), { status: 422 });
    await expect(fetchBrief(local, {}, fetchImpl as unknown as typeof fetch)).rejects.toThrow(/422.*does not exist/);
  });
});

describe("BriefCache", () => {
  it("reads once and reuses the briefing until it expires", async () => {
    let now = 0;
    const fetchImpl = vi.fn(async () => ok("brief"));
    const cache = new BriefCache(local, () => {}, fetchImpl as unknown as typeof fetch, () => now);
    expect(await cache.get({})).toBe("brief");
    now += BRIEF_TTL_MS - 1;
    expect(await cache.get({})).toBe("brief");
    expect(fetchImpl).toHaveBeenCalledTimes(1);
    now += 2;
    await cache.get({});
    expect(fetchImpl).toHaveBeenCalledTimes(2);
  });

  it("starts the call without a briefing on failure, and doesn't retry at once", async () => {
    let now = 0;
    const errors: string[] = [];
    const fetchImpl = vi.fn(async () => {
      throw new Error("fetch failed");
    });
    const cache = new BriefCache(local, (m) => errors.push(m), fetchImpl as unknown as typeof fetch, () => now);
    expect(await cache.get({})).toBeUndefined();
    expect(await cache.get({})).toBeUndefined();
    expect(fetchImpl).toHaveBeenCalledTimes(1);
    expect(errors).toEqual(["fetch failed"]);
    now += BRIEF_RETRY_MS;
    await cache.get({});
    expect(fetchImpl).toHaveBeenCalledTimes(2);
  });

  it("does nothing when turned off", async () => {
    const fetchImpl = vi.fn();
    const cache = new BriefCache(loadConfig({ ...base, BRIEF_VIEW: "off" }, () => false), () => {}, fetchImpl as unknown as typeof fetch);
    expect(await cache.get({})).toBeUndefined();
    expect(fetchImpl).not.toHaveBeenCalled();
  });
});
