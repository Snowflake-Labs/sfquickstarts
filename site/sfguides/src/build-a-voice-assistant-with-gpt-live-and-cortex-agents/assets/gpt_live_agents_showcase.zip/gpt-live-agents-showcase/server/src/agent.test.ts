import { describe, expect, it } from "vitest";
import { AgentError, agentRunUrl, applyFrame, parseFrames, runAgent } from "./agent.js";
import { loadConfig } from "./config.js";

const config = loadConfig(
  { SNOWFLAKE_ACCOUNT_URL: "myorg-myacct.snowflakecomputing.com", SNOWFLAKE_OAUTH_CLIENT_ID: "client-id" },
  () => false,
);

const networkFailure = (async () => {
  throw new TypeError("fetch failed", { cause: new Error("getaddrinfo ENOTFOUND") });
}) as unknown as typeof fetch;

function sseResponse(frames: string[]): Response {
  const body = new ReadableStream({
    start(controller) {
      // Split mid-frame to prove the parser buffers across chunks.
      const all = frames.join("");
      const mid = Math.floor(all.length / 2);
      controller.enqueue(new TextEncoder().encode(all.slice(0, mid)));
      controller.enqueue(new TextEncoder().encode(all.slice(mid)));
      controller.close();
    },
  });
  return new Response(body, { status: 200, headers: { "Content-Type": "text/event-stream" } });
}

const frame = (event: string, data: unknown) => `event: ${event}\ndata: ${JSON.stringify(data)}\n\n`;

describe("parseFrames", () => {
  it("returns complete frames, skips keepalive comments and keeps the tail", () => {
    const { frames, rest } = parseFrames(": keepalive\n\nevent: a\ndata: {\"x\":1}\n\nevent: b\ndata: {");
    expect(frames).toEqual([{ event: "a", data: '{"x":1}' }]);
    expect(rest).toBe("event: b\ndata: {");
  });
});

describe("applyFrame", () => {
  it("ignores unknown events and throws on error events", () => {
    const state = { text: "", toolTypes: [] as string[] };
    applyFrame({ event: "response.chart", data: "{}" }, state, {});
    expect(state.text).toBe("");
    expect(() => applyFrame({ event: "error", data: '{"message":"boom"}' }, state, {})).toThrow(/boom/);
  });
});

describe("runAgent", () => {
  it("posts the messages to the agent's :run endpoint and assembles streamed text", async () => {
    const statuses: string[] = [];
    let seen: { url: string; init: RequestInit } | undefined;
    const fetchImpl = (async (url: string, init: RequestInit) => {
      seen = { url, init };
      return sseResponse([
        frame("response.status", { status: "planning" }),
        frame("response.tool_use", { type: "cortex_analyst_text_to_sql" }),
        frame("response.text.delta", { text: "Forty " }),
        frame("response.text.delta", { text: "scripts." }),
        "data: [DONE]\n\n",
      ]);
    }) as unknown as typeof fetch;

    const messages = [{ role: "user" as const, content: [{ type: "text" as const, text: "q" }] }];
    const result = await runAgent(config, messages, { Authorization: "Bearer x" }, { onStatus: (s) => statuses.push(s) }, undefined, fetchImpl);

    expect(seen?.url).toBe(agentRunUrl(config));
    expect(seen?.url).toBe(
      "https://myorg-myacct.snowflakecomputing.com/api/v2/databases/GPT_LIVE_SHOWCASE/schemas/FIELD_SALES/agents/FIELD_SALES_AGENT:run",
    );
    expect(JSON.parse(String(seen?.init.body))).toEqual({ messages, stream: true });
    expect(result.text).toBe("Forty scripts.");
    expect(result.toolTypes).toEqual(["cortex_analyst_text_to_sql"]);
    expect(statuses).toEqual(["planning"]);
  });

  it("keeps only the text after the last tool call: earlier text is the agent thinking aloud", async () => {
    const fetchImpl = (async () =>
      sseResponse([
        frame("response.tool_use", { type: "cortex_analyst_text_to_sql" }),
        frame("response.text.delta", { content_index: 2, text: "No name given, so use the next meeting's prescriber." }),
        frame("response.text", { content_index: 2, text: "No name given, so use the next meeting's prescriber." }),
        frame("response.tool_use", { type: "cortex_analyst_text_to_sql" }),
        frame("response.text.delta", { content_index: 6, text: "He wrote " }),
        frame("response.text.delta", { content_index: 6, text: "about 4.9." }),
        "data: [DONE]\n\n",
      ])) as unknown as typeof fetch;
    const result = await runAgent(config, [], {}, {}, undefined, fetchImpl);
    expect(result.text).toBe("He wrote about 4.9.");
  });

  it("puts a space between text blocks with no tool call between them", async () => {
    const fetchImpl = (async () =>
      sseResponse([
        frame("response.text.delta", { content_index: 5, text: "December 2025 is the latest month." }),
        frame("response.text.delta", { content_index: 6, text: "He wrote about 4.9." }),
        "data: [DONE]\n\n",
      ])) as unknown as typeof fetch;
    const result = await runAgent(config, [], {}, {}, undefined, fetchImpl);
    expect(result.text).toBe("December 2025 is the latest month. He wrote about 4.9.");
  });

  it("explains a 403 in terms of grants", async () => {
    const fetchImpl = (async () => new Response("no", { status: 403 })) as unknown as typeof fetch;
    await expect(runAgent(config, [], {}, {}, undefined, fetchImpl)).rejects.toThrow(/setup\.sql/);
  });

  it("names the host and operation when the request never gets a response, keeping the cause", async () => {
    const error = await runAgent(config, [], {}, {}, undefined, networkFailure).catch((e: unknown) => e);
    expect(error).toBeInstanceOf(AgentError);
    expect((error as Error).message).toMatch(/Cortex Agents run: no response from myorg-myacct\.snowflakecomputing\.com .*ENOTFOUND/);
    expect((error as Error).cause).toBeInstanceOf(TypeError);
  });
});
