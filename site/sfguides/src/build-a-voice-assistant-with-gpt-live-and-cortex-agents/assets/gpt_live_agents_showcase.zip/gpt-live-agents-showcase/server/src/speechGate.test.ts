import { describe, expect, it } from "vitest";
// Browser module: plain JS, no DOM, so it runs under Node as is.
import { SpeechGate } from "../../web/speechGate.js";

const spoken = (content: string) => ({ type: "session.commentary.append", delegation_id: "d1", content });
const quiet = (content: string) => ({ type: "session.thinking.append", delegation_id: "d1", content });

function setup(speaking = false) {
  const sent: { content: string }[] = [];
  const state = { speaking };
  const gate = new SpeechGate(
    (event: object) => {
      sent.push(event as { content: string });
    },
    () => state.speaking,
  );
  return { gate, sent, state };
}

describe("SpeechGate", () => {
  it("sends everything at once while the user is quiet", () => {
    const { gate, sent } = setup();
    gate.send(quiet("a"));
    gate.send(spoken("b"));
    expect(sent.map((e) => e.content)).toEqual(["a", "b"]);
    expect(gate.held).toBe(0);
  });

  it("lets quiet context through while the user speaks", () => {
    const { gate, sent } = setup(true);
    gate.send(quiet("a"));
    expect(sent.map((e) => e.content)).toEqual(["a"]);
  });

  it("holds a spoken answer, and everything behind it, until the user's turn closes", () => {
    const { gate, sent, state } = setup(true);
    gate.send(spoken("answer"));
    gate.send(quiet("later"));
    expect(sent).toEqual([]);
    expect(gate.held).toBe(2);

    gate.release(); // still speaking
    expect(sent).toEqual([]);

    state.speaking = false;
    gate.release();
    expect(sent.map((e) => e.content)).toEqual(["answer", "later"]);
    expect(gate.held).toBe(0);
  });

  it("drops held events on clear", () => {
    const { gate, sent, state } = setup(true);
    gate.send(spoken("answer"));
    gate.clear();
    state.speaking = false;
    gate.release();
    expect(sent).toEqual([]);
  });
});
