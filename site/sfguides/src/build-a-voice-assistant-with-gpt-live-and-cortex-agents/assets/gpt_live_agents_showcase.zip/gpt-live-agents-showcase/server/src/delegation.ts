import { AgentError, type AgentMessage, type AgentRunCallbacks, type AgentRunResult } from "./agent.js";
import { errorText } from "./errors.js";

/** One side of the spoken conversation, as the browser rebuilt it from transcript deltas. */
export type VoiceTurn = { role: "user" | "assistant"; text: string };

/** What the server streams back to the browser for one delegation. */
export type DelegationEvent =
  /** Quiet context for the model while the lookup runs. Sent as session.thinking.append. */
  | { type: "progress"; text: string }
  /** The answer, for the model to say. Sent as session.commentary.append. */
  | { type: "answer"; text: string; toolTypes: string[]; totalMs: number }
  /**
   * `text` goes to the model as commentary. `detail` is the full error for the
   * server log (it can hold upstream response bodies); index.ts swaps in a
   * fixed message before streaming to the browser. `status` is the upstream
   * HTTP status, if there was one.
   */
  | { type: "error"; text: string; detail: string; status?: number };

/**
 * How many turns to send. Enough for "what about last year?" to resolve
 * against the turn before it, without the request growing all call long.
 */
export const MAX_TURNS = 12;

/**
 * Documented ceiling per session.*.append is 500 tokens. Agent answers for
 * speech are far shorter; this guards against a rejected append losing the
 * answer entirely.
 */
const APPEND_CHAR_BUDGET = 1500;

/**
 * Turn spoken history into a Cortex Agents `messages` array.
 *
 * Cortex wants the array to start with a user turn, alternate strictly, and
 * end on a user turn. openai-gpt-live-1 guarantees none of that: it is full duplex, its
 * transcript fragments interleave, and the greeting means the assistant always
 * speaks first. So: drop empty turns, merge consecutive same-role turns, drop
 * trailing assistant turns ("let me check that"), keep the last MAX_TURNS, and
 * start at the first user turn. Returns [] when there is nothing to ask.
 */
export function toAgentMessages(turns: readonly VoiceTurn[], maxTurns = MAX_TURNS): AgentMessage[] {
  const merged: VoiceTurn[] = [];
  for (const turn of turns) {
    const text = typeof turn?.text === "string" ? turn.text.trim() : "";
    if (!text || (turn.role !== "user" && turn.role !== "assistant")) continue;
    const previous = merged[merged.length - 1];
    if (previous?.role === turn.role) previous.text = `${previous.text} ${text}`;
    else merged.push({ role: turn.role, text });
  }
  while (merged.length > 0 && merged[merged.length - 1].role === "assistant") merged.pop();

  const windowed = merged.slice(-maxTurns);
  const start = windowed.findIndex((turn) => turn.role === "user");
  if (start === -1) return [];
  return windowed.slice(start).map((turn) => ({ role: turn.role, content: [{ type: "text", text: turn.text }] }));
}

/**
 * Make an agent answer safe to hand to a voice model: no markdown, tables,
 * links or citation markers, and within the per-append size limit.
 */
export function forSpeech(text: string): string {
  const cleaned = text
    .replace(/```[\s\S]*?```/g, " ")
    .replace(/^\s*\|.*\|\s*$/gm, " ")
    .replace(/\[([^\]]+)\]\([^)]*\)/g, "$1")
    .replace(/https?:\/\/\S+/g, " ")
    .replace(/【[^】]*】|\[\d+\]/g, " ")
    // Markdown markers only: a ">" or "_" inside a sentence ("TRx > 5", ICS_LABA) is content.
    // A leading ">" is a quote marker, unless a number follows ("> 5 scripts", ">= 5").
    .replace(/^\s*>+\s?(?![\s=]*\d|=)/gm, "")
    .replace(/^\s*#+\s*/gm, "")
    .replace(/(?<![A-Za-z0-9])_+|_+(?![A-Za-z0-9])/g, "")
    .replace(/[*`]+/g, "")
    .replace(/^\s*[-•]\s+/gm, "")
    .replace(/\s+/g, " ")
    .trim();
  return cleaned.length <= APPEND_CHAR_BUDGET ? cleaned : `${cleaned.slice(0, APPEND_CHAR_BUDGET - 1).trimEnd()}…`;
}

/**
 * Progress for the model's quiet context, phrased as state rather than prose.
 * Fluent sentences tend to be read aloud; key=value lines are not.
 */
export function progressNote(phase: string): string {
  return (
    "[INTERNAL STATE — not speech. Mention only if the rep asks how the lookup is going.] " +
    `lookup=running phase=${phase} answer=not_ready`
  );
}

/** Statuses worth a progress note. The stream sends many more; one per phase is enough. */
const PHASES: Record<string, string> = {
  planning: "planning",
  executing_tools: "querying_data",
  proceeding_to_answer: "writing_answer",
};

export type RunAgentFn = (messages: AgentMessage[], callbacks: AgentRunCallbacks, signal: AbortSignal) => Promise<AgentRunResult>;

/**
 * Fulfil one openai-gpt-live-1 client delegation.
 *
 * The delegation event carries no task text, so the conversation is the
 * request. Emits progress as the agent moves through its phases, then exactly
 * one answer or error. Every path ends with something the model can say,
 * because openai-gpt-live-1 waits on the delegation id and otherwise stalls.
 */
export async function runDelegation(
  turns: readonly VoiceTurn[],
  runAgent: RunAgentFn,
  emit: (event: DelegationEvent) => void,
  signal: AbortSignal,
): Promise<void> {
  const messages = toAgentMessages(turns);
  if (messages.length === 0) {
    emit({ type: "answer", text: "I didn't catch the question. Could you say it again?", toolTypes: [], totalMs: 0 });
    return;
  }

  const seen = new Set<string>();
  const onPhase = (phase: string) => {
    if (seen.has(phase)) return;
    seen.add(phase);
    emit({ type: "progress", text: progressNote(phase) });
  };
  onPhase("started");

  try {
    const result = await runAgent(
      messages,
      {
        onStatus: (status) => {
          const phase = PHASES[status];
          if (phase) onPhase(phase);
        },
      },
      signal,
    );
    if (signal.aborted) return;
    const text = forSpeech(result.text) || "I looked, but found nothing for that question.";
    emit({ type: "answer", text, toolTypes: result.toolTypes, totalMs: result.totalMs });
  } catch (error) {
    if (signal.aborted) return;
    emit({
      type: "error",
      text:
        "The lookup failed, so the data isn't available right now. Tell the rep you couldn't reach " +
        "the data and suggest trying again in a moment.",
      detail: error instanceof Error ? errorText(error).slice(0, 500) : String(error),
      status: error instanceof AgentError ? error.status : undefined,
    });
  }
}
