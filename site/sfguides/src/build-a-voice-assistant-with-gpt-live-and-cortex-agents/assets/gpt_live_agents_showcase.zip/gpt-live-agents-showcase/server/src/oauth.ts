import crypto from "node:crypto";
import { AuthError } from "./auth.js";
import type { Config } from "./config.js";

/** How long a sign-in started with /oauth/login may take to come back. */
export const SIGN_IN_WAIT_MS = 10 * 60_000;
/** The most sign-ins waiting at once; any web page can start one, so the oldest go first. */
export const MAX_PENDING_SIGN_INS = 10;
/** Refresh the access token this long before it expires. */
export const REFRESH_EARLY_MS = 60_000;
/** Snowflake's token endpoint can be slow, but not this slow. */
const TOKEN_REQUEST_TIMEOUT_MS = 15_000;

type Tokens = { access: string; expiresAt: number; refresh?: string; user?: string };

/** Same length and same bytes, compared in constant time. */
function sameKey(a: string, b: string): boolean {
  const x = Buffer.from(a);
  const y = Buffer.from(b);
  return x.length === y.length && crypto.timingSafeEqual(x, y);
}

const base64url = (bytes: Buffer) => bytes.toString("base64url");

/**
 * Snowflake OAuth for local runs: the user signs in in the browser, and the
 * server keeps the tokens in memory only. Nothing is written to disk, and the
 * tokens never reach the page. Stopping the server forgets them; Snowflake lets
 * them expire on their own (the access token within minutes, the refresh token
 * within a day).
 *
 * Authorization code flow with PKCE against a public OAuth client
 * (snowflake/setup.sql creates it), so there is no client secret anywhere.
 * The scope asks for the app role only.
 *
 * The sign-in belongs to the browser that completed it: completeSignIn returns
 * a random browser key, which the server sets as an HttpOnly cookie, and calls
 * without that key are refused. So other programs on this machine, which can
 * reach 127.0.0.1 too, can't use the token. A new sign-in replaces the old one.
 */
export class OAuthSession {
  private tokens?: Tokens;
  private browserKey?: string;
  /** Sign-ins started here and not finished yet, by `state`. */
  private readonly pending = new Map<string, { verifier: string; startedAt: number }>();
  private refreshing?: Promise<void>;

  constructor(
    private readonly config: Config,
    private readonly fetchImpl: typeof fetch = fetch,
    private readonly now: () => number = Date.now,
  ) {}

  get signedIn(): boolean {
    return this.tokens !== undefined;
  }

  /** Whether `key` (the browser's cookie) is the one the current sign-in gave out. */
  owns(key: string | undefined): boolean {
    return this.tokens !== undefined && this.browserKey !== undefined && key !== undefined && sameKey(key, this.browserKey);
  }

  /** The Snowflake user name the token belongs to, for the page header. */
  get user(): string | undefined {
    return this.tokens?.user;
  }

  /** Where to send the browser to sign in. */
  loginUrl(): string {
    const now = this.now();
    for (const [state, sign] of this.pending) if (now - sign.startedAt > SIGN_IN_WAIT_MS) this.pending.delete(state);
    // A Map keeps insertion order, so the first key is the oldest sign-in.
    while (this.pending.size >= MAX_PENDING_SIGN_INS) this.pending.delete(this.pending.keys().next().value!);
    const state = base64url(crypto.randomBytes(24));
    const verifier = base64url(crypto.randomBytes(48));
    this.pending.set(state, { verifier, startedAt: now });
    const params = new URLSearchParams({
      client_id: this.clientId(),
      response_type: "code",
      redirect_uri: this.config.oauthRedirectUri,
      scope: this.scope(),
      state,
      code_challenge: base64url(crypto.createHash("sha256").update(verifier).digest()),
      code_challenge_method: "S256",
    });
    return `${this.config.snowflakeUrl}/oauth/authorize?${params}`;
  }

  /**
   * Finish a sign-in: `state` must be one this server started, recently.
   * Returns the key the browser must send back with every call.
   */
  async completeSignIn(code: string, state: string): Promise<string> {
    const sign = this.pending.get(state);
    this.pending.delete(state);
    if (!sign || this.now() - sign.startedAt > SIGN_IN_WAIT_MS) {
      throw new AuthError("This sign-in wasn't started here, or took too long. Start it again from the page.");
    }
    await this.tokenRequest({
      grant_type: "authorization_code",
      code,
      redirect_uri: this.config.oauthRedirectUri,
      code_verifier: sign.verifier,
    });
    this.browserKey = base64url(crypto.randomBytes(32));
    return this.browserKey;
  }

  /** Authorization headers for one Snowflake REST call, refreshing the token first if it is about to expire. */
  async headers(): Promise<Record<string, string>> {
    if (!this.tokens) throw new AuthError("Not signed in to Snowflake. Open the page and choose Sign in with Snowflake.");
    if (this.now() >= this.tokens.expiresAt - REFRESH_EARLY_MS) {
      // One refresh for all the calls that notice at the same time.
      this.refreshing ??= this.refresh().finally(() => (this.refreshing = undefined));
      await this.refreshing;
    }
    if (!this.tokens) throw new AuthError("The Snowflake sign-in has ended. Reload the page and sign in again.");
    return { Authorization: `Bearer ${this.tokens.access}`, "X-Snowflake-Authorization-Token-Type": "OAUTH" };
  }

  private async refresh(): Promise<void> {
    const refreshToken = this.tokens?.refresh;
    if (!refreshToken) {
      this.tokens = undefined;
      return;
    }
    try {
      await this.tokenRequest({ grant_type: "refresh_token", refresh_token: refreshToken });
    } catch (error) {
      this.tokens = undefined;
      throw error;
    }
  }

  private async tokenRequest(form: Record<string, string>): Promise<void> {
    const response = await this.fetchImpl(`${this.config.snowflakeUrl}/oauth/token-request`, {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded", Accept: "application/json" },
      body: new URLSearchParams({ ...form, client_id: this.clientId() }),
      signal: AbortSignal.timeout(TOKEN_REQUEST_TIMEOUT_MS),
    });
    const body = (await response.json().catch(() => ({}))) as Record<string, unknown>;
    if (!response.ok || typeof body.access_token !== "string") {
      // The error fields describe the failure; the response never echoes a token back.
      const reason = String(body.message ?? body.error_description ?? body.error ?? "no details").slice(0, 200);
      throw new AuthError(`Snowflake OAuth token request failed (${response.status}): ${reason}`);
    }
    const expiresIn = typeof body.expires_in === "number" ? body.expires_in : 600;
    this.tokens = {
      access: body.access_token,
      expiresAt: this.now() + expiresIn * 1000,
      refresh: typeof body.refresh_token === "string" ? body.refresh_token : this.tokens?.refresh,
      user: typeof body.username === "string" ? body.username : this.tokens?.user,
    };
  }

  private clientId(): string {
    if (!this.config.oauthClientId) throw new AuthError("SNOWFLAKE_OAUTH_CLIENT_ID is not set.");
    return this.config.oauthClientId;
  }

  /** The app role only, plus a refresh token so the call doesn't end when the access token does. */
  private scope(): string {
    return this.config.role ? `session:role:${this.config.role} refresh_token` : "refresh_token";
  }
}
