import fs from "node:fs";
import http from "node:http";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { runAgent } from "./agent.js";
import { BriefCache } from "./brief.js";
import { OAuthSession } from "./oauth.js";
import { AuthError, SIGNED_IN_USER_HEADER, snowflakeAuthHeaders } from "./auth.js";
import { loadConfig, loadDotEnv, type Config } from "./config.js";
import { runDelegation, type DelegationEvent, type VoiceTurn } from "./delegation.js";
import { errorText } from "./errors.js";
import { createLiveSession, LiveSessionError } from "./liveSession.js";

/** web/ sits two levels up from both server/src (dev) and server/dist (built). */
const WEB_DIR = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "../../web");
const MAX_BODY_BYTES = 256 * 1024;
/** The HttpOnly cookie that ties the local sign-in to the browser that completed it. */
export const SIGN_IN_COOKIE = "gpt_live_showcase_sign_in";

/**
 * Sent with every response. The page loads only its own files, and no other
 * site may frame it, so a hidden frame can't get a click on Start call.
 * WebRTC media isn't covered by connect-src, so this doesn't block the call.
 */
const SECURITY_HEADERS = {
  "Content-Security-Policy":
    "default-src 'self'; img-src 'self' data:; object-src 'none'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'",
  "X-Frame-Options": "DENY",
  "X-Content-Type-Options": "nosniff",
  "Referrer-Policy": "no-referrer",
};
const STATIC_TYPES: Record<string, string> = {
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".svg": "image/svg+xml",
};

/** One JSON line per event. SPCS collects stdout; never log tokens or SDP. */
function log(level: "info" | "warn" | "error", msg: string, fields: Record<string, unknown> = {}): void {
  console.log(JSON.stringify({ ts: new Date().toISOString(), level, msg, ...fields }));
}

class HttpError extends Error {
  constructor(
    readonly status: number,
    message: string,
  ) {
    super(message);
  }
}

async function readJson(req: http.IncomingMessage): Promise<Record<string, unknown>> {
  let size = 0;
  const chunks: Buffer[] = [];
  for await (const chunk of req) {
    size += (chunk as Buffer).length;
    if (size > MAX_BODY_BYTES) throw new HttpError(413, "Request body too large.");
    chunks.push(chunk as Buffer);
  }
  try {
    const parsed: unknown = JSON.parse(Buffer.concat(chunks).toString("utf8") || "{}");
    if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) return parsed as Record<string, unknown>;
  } catch {
    // fall through
  }
  throw new HttpError(400, "Body must be a JSON object.");
}

/** Send the browser elsewhere: to Snowflake to sign in, or back to the page. */
function redirect(res: http.ServerResponse, location: string, cookie?: string): void {
  res.writeHead(302, {
    ...SECURITY_HEADERS,
    Location: location,
    "Cache-Control": "no-store",
    ...(cookie ? { "Set-Cookie": cookie } : {}),
  });
  res.end();
}

function sendJson(res: http.ServerResponse, status: number, body: unknown): void {
  res.writeHead(status, { ...SECURITY_HEADERS, "Content-Type": "application/json", "Cache-Control": "no-store" });
  res.end(JSON.stringify(body));
}

function header(req: http.IncomingMessage, name: string): string | undefined {
  const value = req.headers[name];
  return Array.isArray(value) ? value[0] : value;
}

/** The value of one cookie the browser sent, if any. */
export function cookie(req: http.IncomingMessage, name: string): string | undefined {
  for (const part of (header(req, "cookie") ?? "").split(";")) {
    const at = part.indexOf("=");
    if (at > 0 && part.slice(0, at).trim() === name) return part.slice(at + 1).trim();
  }
  return undefined;
}

function serveStatic(res: http.ServerResponse, urlPath: string): void {
  const relative = urlPath === "/" ? "index.html" : urlPath.slice(1);
  const file = path.resolve(WEB_DIR, relative);
  // Refuse anything that resolves outside web/.
  if (!file.startsWith(WEB_DIR + path.sep) || !fs.existsSync(file) || !fs.statSync(file).isFile()) {
    sendJson(res, 404, { error: "not_found" });
    return;
  }
  res.writeHead(200, {
    ...SECURITY_HEADERS,
    "Content-Type": STATIC_TYPES[path.extname(file)] ?? "application/octet-stream",
    "Cache-Control": "no-cache",
  });
  fs.createReadStream(file)
    // A read that fails after the checks above must not crash the server.
    .on("error", () => res.destroy())
    .pipe(res);
}

/** Snowflake auth for one request: the signed-in user's OAuth token locally, the SPCS token otherwise. */
type AuthFor = (req: http.IncomingMessage) => Promise<Record<string, string>>;

/**
 * Who the per-user limits count against. On SPCS, ingress sets the signed-in
 * user's name and replaces any value the client sent. Locally the header
 * could be anything, and there is one user, so it is ignored.
 */
function limitKey(config: Config, req: http.IncomingMessage): string {
  return config.authMode === "service" ? (header(req, SIGNED_IN_USER_HEADER) ?? "unknown") : "local";
}

/**
 * POST /api/session — create the openai-gpt-live-1 call and hand the SDP answer to the
 * browser. Today's briefing goes into the instructions when it can be read.
 */
async function handleSession(
  config: Config,
  authFor: AuthFor,
  briefs: BriefCache,
  limiter: RateLimiter,
  req: http.IncomingMessage,
  res: http.ServerResponse,
): Promise<void> {
  const body = await readJson(req);
  const sdp = body.sdp;
  if (typeof sdp !== "string" || !sdp.startsWith("v=0")) throw new HttpError(400, "Body needs an SDP offer in `sdp`.");
  const auth = await authFor(req);
  if (!limiter.allow(limitKey(config, req))) {
    throw new HttpError(429, `More than ${SESSIONS_PER_MINUTE} calls started in the last minute.`);
  }

  const startedAt = Date.now();
  const brief = await briefs.get(auth);
  const session = await createLiveSession(config, sdp, auth, fetch, brief);
  log("info", "openai-gpt-live-1 session created", {
    sessionId: session.sessionId,
    ms: Date.now() - startedAt,
    briefChars: brief?.length ?? 0,
  });
  sendJson(res, 201, { sessionId: session.sessionId, sdp: session.answerSdp, briefed: Boolean(brief) });
}

/** Comment line sent while the agent is quiet, so idle timeouts on the path don't cut the stream. */
const KEEPALIVE_MS = 15_000;

/** The most turns one delegation may carry, and the longest turn. The page sends at most 24 spoken turns. */
export const MAX_REQUEST_TURNS = 50;
export const MAX_TURN_CHARS = 4000;

/**
 * The conversation the browser sends, checked before the agent sees it: a list
 * of {role: "user" | "assistant", text} within the limits above. The agent runs
 * with GPT_LIVE_SHOWCASE_ROLE's rights, so anything else is refused, not passed on.
 */
export function parseTurns(value: unknown): VoiceTurn[] {
  if (value === undefined) return [];
  if (!Array.isArray(value) || value.length > MAX_REQUEST_TURNS) {
    throw new HttpError(400, `\`turns\` must be a list of at most ${MAX_REQUEST_TURNS} turns.`);
  }
  return value.map((turn: unknown) => {
    const { role, text } = (turn ?? {}) as { role?: unknown; text?: unknown };
    if ((role !== "user" && role !== "assistant") || typeof text !== "string" || text.length > MAX_TURN_CHARS) {
      throw new HttpError(400, `Each turn must be {role: "user" | "assistant", text}, with text up to ${MAX_TURN_CHARS} characters.`);
    }
    return { role, text };
  });
}

/** The longest `delegationId` accepted. openai-gpt-live-1's ids are far shorter; the id is logged. */
export const MAX_DELEGATION_ID_CHARS = 128;

/** New openai-gpt-live-1 calls one user may start per minute. Each one costs credits. */
export const SESSIONS_PER_MINUTE = 6;
/** Lookups one user may start per minute. Each one runs the Cortex Agent, which costs credits. */
export const LOOKUPS_PER_MINUTE = 20;

/** Counts requests per user over the last minute, in memory (see limitKey for the user). */
export class RateLimiter {
  private readonly starts = new Map<string, number[]>();
  constructor(
    private readonly limit: number,
    private readonly windowMs = 60_000,
    private readonly now: () => number = Date.now,
  ) {}

  /** Records a start and says whether it is allowed. */
  allow(user: string): boolean {
    const now = this.now();
    for (const [key, times] of this.starts) {
      const recent = times.filter((t) => now - t < this.windowMs);
      if (recent.length) this.starts.set(key, recent);
      else this.starts.delete(key);
    }
    const recent = this.starts.get(user) ?? [];
    if (recent.length >= this.limit) return false;
    this.starts.set(user, [...recent, now]);
    return true;
  }
}

/**
 * POST /api/delegate — run one delegation and stream its progress and answer.
 *
 * Server-sent events over the POST response. The browser forwards each event
 * onto its data channel; closing the request (the browser hanging up)
 * cancels the agent run.
 */
async function handleDelegate(
  config: Config,
  authFor: AuthFor,
  limiter: RateLimiter,
  req: http.IncomingMessage,
  res: http.ServerResponse,
): Promise<void> {
  const body = await readJson(req);
  const delegationId = typeof body.delegationId === "string" ? body.delegationId : "";
  if (!delegationId || delegationId.length > MAX_DELEGATION_ID_CHARS) {
    throw new HttpError(400, `Body needs \`delegationId\`, up to ${MAX_DELEGATION_ID_CHARS} characters.`);
  }
  const turns = parseTurns(body.turns);
  const auth = await authFor(req);
  if (!limiter.allow(limitKey(config, req))) {
    throw new HttpError(429, `More than ${LOOKUPS_PER_MINUTE} lookups started in the last minute.`);
  }

  const controller = new AbortController();
  res.on("close", () => controller.abort());
  res.writeHead(200, {
    "Content-Type": "text/event-stream",
    "Cache-Control": "no-store",
    Connection: "keep-alive",
    // Some proxies buffer event streams unless told not to.
    "X-Accel-Buffering": "no",
  });
  const emit = (event: DelegationEvent) => {
    if (!res.writableEnded) res.write(`event: ${event.type}\ndata: ${JSON.stringify(event)}\n\n`);
  };
  // The agent can be silent for tens of seconds while a query runs.
  const keepalive = setInterval(() => {
    if (!res.writableEnded) res.write(": ping\n\n");
  }, KEEPALIVE_MS);

  log("info", "Delegation started", { delegationId, turns: turns.length });
  try {
    await runDelegation(
      turns,
      (messages, callbacks, signal) => runAgent(config, messages, auth, callbacks, signal),
      (event) => {
        if (event.type === "answer") log("info", "Delegation answered", { delegationId, ms: event.totalMs, tools: event.toolTypes });
        if (event.type === "error") {
          log("error", "Delegation failed", { delegationId, status: event.status, detail: event.detail });
          // The detail can carry an upstream body: it stays in the server log.
          emit({ type: "error", text: event.text, detail: publicMessage("The lookup", event.status) });
          return;
        }
        emit(event);
      },
      controller.signal,
    );
  } finally {
    clearInterval(keepalive);
    res.end();
  }
}

/**
 * A loopback host with an optional port, matched exactly. Any port, so
 * LISTEN_PORT can change. Not parsed as a URL, which would read
 * `evil.example@localhost` as localhost.
 */
const LOOPBACK_HOST = /^(?:127\.0\.0\.1|localhost|\[::1\])(?::\d{1,5})?$/i;

export function isLoopbackHost(hostHeader: string | undefined): boolean {
  return hostHeader !== undefined && LOOPBACK_HOST.test(hostHeader);
}

/**
 * Refuse requests a hostile web page could make on the user's behalf.
 *
 * Locally the server holds the user's Snowflake sign-in, so it must only answer
 * the page it served: a Host other than loopback means DNS rebinding, and a non-JSON POST
 * is one a browser sends cross-site without a CORS preflight. On SPCS, ingress
 * authenticates every request, but the JSON rule still costs nothing.
 * The sign-in cookie is the other half: other programs on this machine don't have it.
 *
 * Returns an error to send, or undefined to carry on.
 */
export function rejectRequest(config: Config, req: http.IncomingMessage): HttpError | undefined {
  if (config.authMode === "oauth" && !isLoopbackHost(header(req, "host"))) {
    return new HttpError(421, "This local server only answers on 127.0.0.1, localhost or [::1].");
  }
  if (req.method === "POST" && !/^application\/json\b/i.test(header(req, "content-type") ?? "")) {
    return new HttpError(415, "POST bodies must be application/json.");
  }
  return undefined;
}

/**
 * What the browser sees of a failure: a fixed sentence and status codes, never
 * the error text, which can hold an upstream response body. The full error is
 * in the server log.
 */
export function publicMessage(what: string, status: number | undefined): string {
  return `${what} failed${status ? ` (${status})` : ""}. Details are in the server logs.`;
}

export function browserError(error: unknown, status: number): { error: string; status: number; upstreamStatus?: number } {
  if (error instanceof LiveSessionError) {
    return { error: publicMessage("openai-gpt-live-1 session create", error.status), status, upstreamStatus: error.status };
  }
  return { error: publicMessage("The request", status), status };
}

/**
 * GET /oauth/login when another site started it: a link, image or frame on
 * another page. Each one would push out a sign-in waiting to come back.
 * Browsers send Sec-Fetch-Site; "none" means the user typed the URL.
 */
export function startedCrossSite(req: http.IncomingMessage): boolean {
  const site = header(req, "sec-fetch-site");
  return site !== undefined && site !== "same-origin" && site !== "none";
}

/** The request path, or undefined when it isn't a valid URL path (`//`, for example). */
function requestUrl(req: http.IncomingMessage): URL | undefined {
  try {
    return new URL(req.url ?? "/", "http://localhost");
  } catch {
    return undefined;
  }
}

export function createServer(config: Config): http.Server {
  const sessionLimiter = new RateLimiter(SESSIONS_PER_MINUTE);
  const lookupLimiter = new RateLimiter(LOOKUPS_PER_MINUTE);
  const oauth = config.authMode === "oauth" ? new OAuthSession(config) : undefined;
  const authFor: AuthFor = async (req) => {
    if (!oauth) return snowflakeAuthHeaders(config);
    if (oauth.signedIn && !oauth.owns(cookie(req, SIGN_IN_COOKIE))) {
      throw new AuthError("This browser isn't signed in to the app. Open the page and choose Sign in with Snowflake.");
    }
    return oauth.headers();
  };
  const briefs = new BriefCache(config, (message) =>
    log("warn", "Briefing unavailable; the call starts without it", { view: config.briefView, error: message }),
  );
  return http.createServer((req, res) => {
    const url = requestUrl(req);
    const route = `${req.method} ${url?.pathname ?? "(invalid path)"}`;
    const handle = async () => {
      if (!url) throw new HttpError(400, "Invalid request path.");
      // Before the guard: SPCS probes this from outside with its own Host header.
      if (route === "GET /healthz") return sendJson(res, 200, { ok: true });
      const rejected = rejectRequest(config, req);
      if (rejected) throw rejected;
      if (route === "GET /api/config") {
        return sendJson(res, 200, {
          model: config.liveModel,
          voice: config.voice,
          agent: `${config.agentDatabase}.${config.agentSchema}.${config.agentName}`,
          signedIn: oauth ? oauth.owns(cookie(req, SIGN_IN_COOKIE)) : true,
          user: (oauth ? oauth.owns(cookie(req, SIGN_IN_COOKIE)) && oauth.user : header(req, SIGNED_IN_USER_HEADER)) || null,
        });
      }
      if (oauth && route === "GET /oauth/login") {
        if (startedCrossSite(req)) throw new HttpError(403, "Start the sign-in from the app's page.");
        return redirect(res, oauth.loginUrl());
      }
      if (oauth && route === "GET /oauth/callback") {
        const code = url.searchParams.get("code");
        const state = url.searchParams.get("state");
        if (!code || !state) {
          log("warn", "Sign-in did not complete", { error: url.searchParams.get("error") ?? "no code" });
          return redirect(res, "/?signin=failed");
        }
        let browserKey: string;
        try {
          browserKey = await oauth.completeSignIn(code, state);
        } catch (error) {
          log("warn", "Sign-in failed", { error: errorText(error) });
          return redirect(res, "/?signin=failed");
        }
        log("info", "Signed in to Snowflake");
        // HttpOnly: the page's scripts can't read it. Strict: other sites' requests don't carry it.
        return redirect(res, "/", `${SIGN_IN_COOKIE}=${browserKey}; HttpOnly; SameSite=Strict; Path=/`);
      }
      if (route === "POST /api/session") return handleSession(config, authFor, briefs, sessionLimiter, req, res);
      if (route === "POST /api/delegate") return handleDelegate(config, authFor, lookupLimiter, req, res);
      if (req.method === "GET") return serveStatic(res, url.pathname);
      sendJson(res, 404, { error: "not_found" });
    };
    handle().catch((error: unknown) => {
      const status =
        error instanceof HttpError ? error.status : error instanceof LiveSessionError ? 502 : error instanceof AuthError ? 401 : 500;
      log(status >= 500 ? "error" : "warn", "Request failed", { route, status, error: errorText(error) });
      if (res.headersSent) res.end();
      else sendJson(res, status, browserError(error, status));
    });
  });
}

// Started directly (npm run dev / npm start), not imported by a test.
if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  loadDotEnv();
  const config = loadConfig();
  createServer(config).listen(config.port, config.host, () => {
    log("info", "Listening", {
      url: `http://${config.host}:${config.port}`,
      snowflake: config.snowflakeUrl,
      authMode: config.authMode,
      gateway: config.aiGatewayName,
      agent: `${config.agentDatabase}.${config.agentSchema}.${config.agentName}`,
    });
  });
}
