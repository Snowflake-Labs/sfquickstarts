-- SPCS step 3 of 3: create the service and let app users reach its endpoint.
-- Run as GPT_LIVE_SHOWCASE_ROLE, after spcs/push-image.sh, with the same tag:
--   snow sql -c <your-connection> --role GPT_LIVE_SHOWCASE_ROLE -f spcs/02_service.sql -D image_tag=v1
-- In a Snowsight worksheet, set the role to GPT_LIVE_SHOWCASE_ROLE and
-- replace <% image_tag %> by hand. It never switches roles itself, so any
-- login works.
--
-- Auth: there are no secrets in the container or the browser. Snowflake
-- mounts an OAuth token for the service at /snowflake/session/token and
-- injects SNOWFLAKE_HOST; ingress signs users in before they reach the page.
-- Cortex and AI Gateway calls run as the service owner role,
-- GPT_LIVE_SHOWCASE_ROLE, for every app user.

USE SCHEMA GPT_LIVE_SHOWCASE.FIELD_SALES;
USE WAREHOUSE GPT_LIVE_SHOWCASE_WH;

CREATE SERVICE IF NOT EXISTS GPT_LIVE_SHOWCASE_SERVICE
  IN COMPUTE POOL GPT_LIVE_SHOWCASE_POOL
  MIN_INSTANCES = 1
  MAX_INSTANCES = 1
  FROM SPECIFICATION $$
spec:
  containers:
    - name: app
      image: /gpt_live_showcase/field_sales/images/gpt-live-agents-showcase:<% image_tag %>
      env:
        AI_GATEWAY_NAME: snowflake
        GPT_LIVE_MODEL: openai-gpt-live-1
        AGENT_DATABASE: GPT_LIVE_SHOWCASE
        AGENT_SCHEMA: FIELD_SALES
        AGENT_NAME: FIELD_SALES_AGENT
      readinessProbe:
        port: 3000
        path: /healthz
      resources:
        requests:
          cpu: 0.5
          memory: 512M
        limits:
          cpu: 1
          memory: 1G
  endpoints:
    - name: ui
      port: 3000
      public: true
$$;

-- To ship a new version: push it under a new tag, then, as GPT_LIVE_SHOWCASE_ROLE:
--   ALTER SERVICE GPT_LIVE_SHOWCASE_SERVICE FROM SPECIFICATION $$ <the spec above, new tag> $$;
-- Re-running this file doesn't update a service that already exists. A new
-- tag makes sure the new image is pulled; reusing a tag may keep the old one.

-- Who may open the page: holders of GPT_LIVE_SHOWCASE_USER (created in step
-- 1). Ingress signs the user in with Snowflake and admits them only if one of
-- their roles has the endpoint service role. App users need nothing else,
-- so they don't get the owner role.
GRANT SERVICE ROLE GPT_LIVE_SHOWCASE_SERVICE!ALL_ENDPOINTS_USAGE TO ROLE GPT_LIVE_SHOWCASE_USER;
-- Then, as ACCOUNTADMIN, for each app user:
--   GRANT ROLE GPT_LIVE_SHOWCASE_USER TO USER <app_user>;

-- Wait for READY (a minute or two the first time), then open the ingress_url.
SELECT SYSTEM$GET_SERVICE_STATUS('GPT_LIVE_SHOWCASE_SERVICE');
SHOW ENDPOINTS IN SERVICE GPT_LIVE_SHOWCASE_SERVICE;

-- Logs, if the page loads but a call fails:
--   SELECT SYSTEM$GET_SERVICE_LOGS('GPT_LIVE_SHOWCASE_SERVICE', 0, 'app', 200);
