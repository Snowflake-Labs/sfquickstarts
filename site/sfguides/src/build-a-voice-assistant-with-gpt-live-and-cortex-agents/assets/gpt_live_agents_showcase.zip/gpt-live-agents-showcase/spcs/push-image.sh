#!/usr/bin/env bash
# SPCS step 2 of 3: create the image repository if it doesn't exist yet, then
# build the linux/amd64 image and push it.
#   spcs/push-image.sh <your-connection> <tag>
# Runs every Snowflake command as GPT_LIVE_SHOWCASE_ROLE, so that role owns
# the repository; the connection's user needs that role (README Quick start step 1).
# Use a new tag for every push (v1, v2, …): the service pulls by tag, and
# reusing one may keep the old image running. Pass the same tag to
# spcs/02_service.sql. Needs Docker with buildx, running, and the Snowflake
# CLI (snow). Run from the showcase folder.
set -euo pipefail

CONNECTION="${1:?usage: spcs/push-image.sh <your-connection> <tag>}"
TAG="${2:?usage: spcs/push-image.sh <your-connection> <tag>}"
IMAGE="gpt-live-agents-showcase"
SNOW=(-c "$CONNECTION" --role GPT_LIVE_SHOWCASE_ROLE --database GPT_LIVE_SHOWCASE --schema FIELD_SALES)

docker info >/dev/null 2>&1 || { echo "Docker isn't running. Start it, then run this again." >&2; exit 1; }

# Look the repository up first: after the README's step 4 the role can push to
# it but no longer create one.
if ! REPO_URL="$(snow spcs image-repository url IMAGES "${SNOW[@]}" 2>/dev/null)"; then
  snow spcs image-repository create IMAGES "${SNOW[@]}"
  REPO_URL="$(snow spcs image-repository url IMAGES "${SNOW[@]}")"
fi
echo "Repository: $REPO_URL"

snow spcs image-registry login "${SNOW[@]}"
docker buildx build --platform linux/amd64 -t "$REPO_URL/$IMAGE:$TAG" --load .
docker push "$REPO_URL/$IMAGE:$TAG"
echo "Pushed $REPO_URL/$IMAGE:$TAG"
