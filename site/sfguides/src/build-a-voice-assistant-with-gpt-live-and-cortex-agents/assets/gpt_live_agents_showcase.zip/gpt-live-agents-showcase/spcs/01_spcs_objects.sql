-- SPCS step 1 of 3: compute pool, grants and the app-user role.
-- Run as ACCOUNTADMIN, after snowflake/setup.sql:
--   snow sql -c <your-connection> --role ACCOUNTADMIN -f spcs/01_spcs_objects.sql
-- or paste it into a Snowsight worksheet whose role is ACCOUNTADMIN.
-- Safe to re-run. It never switches roles itself, so any sign-in method works,
-- including one limited to a single role, which can't run USE ROLE.
--
-- No egress rule or external access integration: the container only calls
-- the SNOWFLAKE_HOST that SPCS injects (server/src/config.ts), which needs
-- none, and the browser talks to the model provider directly.

-- Smallest CPU pool. One node is enough: the container serves the page and
-- makes REST calls; audio never passes through it. AUTO_SUSPEND_SECS only
-- applies with no service running: the service from step 3 keeps the pool up
-- until you suspend both (README, "Stop and start it").
CREATE COMPUTE POOL IF NOT EXISTS GPT_LIVE_SHOWCASE_POOL
  MIN_NODES = 1
  MAX_NODES = 1
  INSTANCE_FAMILY = CPU_X64_XS
  AUTO_SUSPEND_SECS = 3600;
GRANT USAGE, MONITOR ON COMPUTE POOL GPT_LIVE_SHOWCASE_POOL TO ROLE GPT_LIVE_SHOWCASE_ROLE;

-- The image repository and the service are created, and owned, by
-- GPT_LIVE_SHOWCASE_ROLE (steps 2 and 3), so the app runs with that role's rights.
-- Once the service exists, revoke these two (README, Deploy to SPCS, step 4);
-- running this file again grants them back.
GRANT CREATE IMAGE REPOSITORY, CREATE SERVICE ON SCHEMA GPT_LIVE_SHOWCASE.FIELD_SALES
  TO ROLE GPT_LIVE_SHOWCASE_ROLE;
-- The service owner needs this to expose a public (ingress) endpoint.
GRANT BIND SERVICE ENDPOINT ON ACCOUNT TO ROLE GPT_LIVE_SHOWCASE_ROLE;

-- Who may open the page: holders of GPT_LIVE_SHOWCASE_USER. Step 3 gives it
-- the service's endpoint role, and nothing else: app users don't get the
-- owner role, which can create services and bind endpoints.
CREATE ROLE IF NOT EXISTS GPT_LIVE_SHOWCASE_USER
  COMMENT = 'Can open the openai-gpt-live-1 showcase app. Holds only the service endpoint role.';
