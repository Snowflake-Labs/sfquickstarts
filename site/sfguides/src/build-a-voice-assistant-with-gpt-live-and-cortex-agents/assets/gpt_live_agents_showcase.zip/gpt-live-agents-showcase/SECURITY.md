# Security

This repository is sample code, not production code. It creates objects only in a database, warehouse and roles it owns (`GPT_LIVE_SHOWCASE`, `GPT_LIVE_SHOWCASE_WH`, `GPT_LIVE_SHOWCASE_ROLE`, the OAuth integration `GPT_LIVE_SHOWCASE_OAUTH`, and for SPCS `GPT_LIVE_SHOWCASE_POOL` and `GPT_LIVE_SHOWCASE_USER`), uses synthetic data only, and contains no credentials.

How it handles credentials and data:

- **No stored secrets.** Locally you sign in with Snowflake OAuth (a public client with PKCE, so there is no client secret). On SPCS the app uses the token Snowflake mounts in the container.
- **Tokens stay in the server's memory.** They are never written to disk, never logged and never sent to the browser. Stopping the server makes the app forget them; Snowflake lets them expire on their own (the access token within minutes, the refresh token within a day).
- **Least privilege.** The sign-in asks only for `GPT_LIVE_SHOWCASE_ROLE` (the `SNOWFLAKE_ROLE` setting), and Snowflake blocks `ACCOUNTADMIN` and `SECURITYADMIN` for OAuth by default.
- **HTTPS to Snowflake only.** The server refuses an `http://` account URL. Locally it refuses to listen beyond this machine (`127.0.0.1`, `localhost` or `::1`), and only answers requests addressed to it.
- **The sign-in belongs to one browser.** After you sign in, the server sets an HttpOnly, SameSite=Strict cookie, and refuses calls without it, so other programs on your machine can't use your token. The page is sent with a Content-Security-Policy and can't be framed by other sites.
- **Limits.** Each user can start at most 6 calls and 20 lookups a minute.
- **Nothing written to disk.** The server keeps the briefing, its call counters and the token in memory. The page stores only whether the transcript is shown.

Recommendations when running it:

- Use a sandbox account or a dedicated role. The setup scripts use `ACCOUNTADMIN` for simplicity.
- On SPCS every app user acts as `GPT_LIVE_SHOWCASE_ROLE`: grant that role only data that all app users may see. After the service is created, revoke the role's `CREATE SERVICE` and `CREATE IMAGE REPOSITORY` rights (README, *Deploy to SPCS*, step 4).
- Run the "Clean up" steps in the README when you're done, including dropping the OAuth integration.

## Reporting a vulnerability

Please don't open a public issue for a security problem. Refer to the Snowflake [HackerOne program](https://hackerone.com/snowflake?type=team) for our security policies and for reporting vulnerabilities. For other security questions, contact the Snowflake security team at security@snowflake.com.
