# Data notes

All data in `setup.sql` is synthetic. No real prescriber, patient, payer,
product, claims, or commercial account appears in it.

## How it is built

`setup.sql` writes one table, `HCP_EVENTS`: one row per event in a rep's
territory, such as a prescriber profile, observed prescribing, payer access, a
meeting held, an objection raised, a patient cohort, a next best action, or a
scheduled meeting. Each row has a `PRODUCT`, a short `TITLE`, a spoken-friendly
`BODY` and a JSON `ATTRIBUTES` column. The semantic view `FIELD_SALES_SV`
exposes the columns the agent needs, including `PRODUCT` as a dimension, so it
can filter by brand.

The numbers are deterministic, so every run of `setup.sql` builds the same data:

- **The main prescriber, Dr. Vantreese,** has a hand-written prescribing series,
  so the questions below have fixed answers.
- **The other prescribers** get values derived with `HASH` from the prescriber
  ID and product, with no `RANDOM`. They look varied but never change between
  runs.

## Fictional names

Every name below is invented for this showcase. HCP means healthcare provider.
The hero is Dr. Vantreese, the main prescriber of the demo; supporting are the
other prescribers with visits today.

| Kind | Name |
|---|---|
| Our brand | ZEVRANTA (generic zevratimab) |
| Our brand focus | ZEVRANTA PULM (Asthma) |
| Competitor brand | ORLIVEX |
| Drug class | ICS/LABA (a class, not a brand) |
| Manufacturer | Halvern Therapeutics (agent instructions and page header) |
| HCP (hero) | Dr. Teodor Vantreese |
| HCPs | Dr. Junia Pellwether, Dr. Anselm Kirtridge, Dr. Odalys Fennimore-Rook, Dr. Caspian Wolverly, Dr. Mireille Quantock, Dr. Ezra Thistlewood, Dr. Solvei Brannigan-Oduya, Dr. Florentin Haverbrook, Dr. Ysolde Marchbank, Dr. Percival Ravensworth, Dr. Zinnia Corrowan |
| HCP IDs | hcp-001 ... hcp-012 |
| Reps | Alex Rivera (rep-4417); co-calling rep Morgan Ellery |
| Practices | Birchfield Pulmonary Associates, Quillfeather Allergy Partners, Bramblewood Chest & Sleep, Thistledown Lung Clinic, Marrowstone Primary Care, Copperleaf Respiratory Group, Wildrye Allergy Associates, Saltbrush Chest Medicine, Larkspur Hollow Family Medicine |
| Payers | Lakeshore Regional Health Plan, Sunridge Advantage, Brightwater Mutual, Orchard Valley Medicaid Plan |

Cities (Fresno, Clovis, Visalia, Madera, Bakersfield, Delano, Tehachapi, CA)
are real and kept. No street addresses, zip codes, phone numbers, emails, or
NPIs remain.

## Row counts

One table, `GPT_LIVE_SHOWCASE.FIELD_SALES.HCP_EVENTS`, 960 rows:

| Event type | Rows | Notes |
|---|---|---|
| HCP_PROFILE | 12 | one per prescriber |
| PRESCRIBING_OBSERVED | 864 | 12 prescribers x 3 products x 24 months (Jan 2024 to Dec 2025) |
| MEETING_HELD | 60 | 52 hero calls (Jul 2025 to 12 Jan 2026) + 2 each for 4 supporting |
| PAYER_ACCESS_OBSERVED | 8 | 4 hero payers + 1 each for 4 supporting |
| PATIENT_COHORT_OBSERVED | 8 | hero only, aggregate counts |
| OBJECTION_RAISED | 2 | hero only |
| NEXT_BEST_ACTION | 1 | hero only |
| MEETING_SCHEDULED | 5 | all on Friday 2026-01-16 |

## Meeting-prep scenario

Demo "today" is Friday 16 January 2026. Rep Alex Rivera's first meeting is
**Dr. Teodor Vantreese**, pulmonologist at Birchfield Pulmonary Associates in
Fresno, at 9:30.

## Example spoken questions

Each is answerable from `FIELD_SALES_SV` columns (expected answer in brackets).
Questions 1, 2, 3, 5, 6, 7 and 10 are also covered by the `DAY_BRIEF` view, so
during a call they are answered from the precomputed briefing without a lookup.
The others go to the agent.

1. "Who am I seeing today?" [five `MEETING_SCHEDULED` rows on 2026-01-16,
   Dr. Vantreese first at 9:30]
2. "What's the focus for my meeting with Dr. Vantreese?" [`MEETING_SCHEDULED`
   body: 21 OCS-dependent ICS/LABA patients and pull-through]
3. "How much ZEVRANTA did he prescribe in December?" [`product` = ZEVRANTA,
   `metric_name` = trx, Dec 2025: about 4.9 TRx]
4. "How does that compare with his best month?" [max trx for ZEVRANTA: 9.74
   in August 2024]
5. "Is he writing more ORLIVEX or ICS/LABA?" [Dec 2025: ICS/LABA about 19.3,
   ORLIVEX 2.0]
6. "What objections has he raised?" [two `OBJECTION_RAISED` titles: comfortable
   with current approach; biologics expensive and hard to get approved]
7. "Which payer covers most of his patients, and does it need prior
   authorization?" [`PAYER_ACCESS_OBSERVED`: Lakeshore Regional Health Plan,
   40 percent, prior auth required]
8. "How many times have I called on him in the last six months?"
   [`MEETING_HELD` count for the hero: 52]
9. "How many of his patients are OCS-dependent?" [`PATIENT_COHORT_OBSERVED`,
   Dec 2025: 21]
10. "What should I bring?" [`NEXT_BEST_ACTION` title: prior-auth turnaround
    data and the step-edit pathway one-pager]
