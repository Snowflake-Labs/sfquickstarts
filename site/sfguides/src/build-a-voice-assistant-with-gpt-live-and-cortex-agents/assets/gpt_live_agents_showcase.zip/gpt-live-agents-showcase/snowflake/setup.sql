-- openai-gpt-live-1 agents showcase: Snowflake setup for the field sales Cortex Agent.
-- ALL DATA IS SYNTHETIC. Fabricated for a demo. Not a real person, patient,
-- prescriber, payer, product, or commercial account.
--
-- One file, idempotent. Run as ACCOUNTADMIN:
--   snow sql -c <your-connection> --role ACCOUNTADMIN -f snowflake/setup.sql
-- or paste the whole file into a Snowsight worksheet and Run All.
--
-- Scope: only what the app needs (table, semantic view, agent, briefing view,
-- grants, the OAuth integration for local sign-in). The SPCS objects (compute
-- pool, image repository, service) live in a separate file.
--
-- Re-running drops and reloads the demo table, then recreates the semantic
-- view and the agent. Nothing outside GPT_LIVE_SHOWCASE is dropped.

-- ===========================================================================
-- a. Names
-- ===========================================================================
-- These names are literal throughout the file rather than SET variables:
-- they also appear inside the semantic view and the agent specification,
-- which cannot read session variables. To rename, find-and-replace.
--
--   Role              GPT_LIVE_SHOWCASE_ROLE
--   Warehouse         GPT_LIVE_SHOWCASE_WH        (XSMALL, auto-suspend 60 s)
--   Database          GPT_LIVE_SHOWCASE
--   Schema            GPT_LIVE_SHOWCASE.FIELD_SALES
--   Table             GPT_LIVE_SHOWCASE.FIELD_SALES.HCP_EVENTS
--   Semantic view     GPT_LIVE_SHOWCASE.FIELD_SALES.FIELD_SALES_SV
--   Agent             GPT_LIVE_SHOWCASE.FIELD_SALES.FIELD_SALES_AGENT
--   Briefing view     GPT_LIVE_SHOWCASE.FIELD_SALES.DAY_BRIEF
--   Search (optional) GPT_LIVE_SHOWCASE.FIELD_SALES.FIELD_NOTES_SEARCH
--   OAuth integration GPT_LIVE_SHOWCASE_OAUTH     (sign-in for the local app)
--
-- The app server defaults (AGENT_DATABASE, AGENT_SCHEMA, AGENT_NAME and
-- BRIEF_VIEW in server/src/config.ts) match these names.

USE ROLE ACCOUNTADMIN;

-- ===========================================================================
-- b. Role, warehouse, database, schema
-- ===========================================================================
CREATE ROLE IF NOT EXISTS GPT_LIVE_SHOWCASE_ROLE
  COMMENT = 'Runs the openai-gpt-live-1 field sales showcase agent. Synthetic data only.';

-- Granting to SYSADMIN lets anyone holding SYSADMIN or ACCOUNTADMIN use it.
GRANT ROLE GPT_LIVE_SHOWCASE_ROLE TO ROLE SYSADMIN;

CREATE WAREHOUSE IF NOT EXISTS GPT_LIVE_SHOWCASE_WH
  WAREHOUSE_SIZE = XSMALL
  AUTO_SUSPEND = 60
  AUTO_RESUME = TRUE
  INITIALLY_SUSPENDED = TRUE
  COMMENT = 'Warehouse for the openai-gpt-live-1 field sales showcase agent.';

CREATE DATABASE IF NOT EXISTS GPT_LIVE_SHOWCASE
  COMMENT = 'openai-gpt-live-1 agents showcase. All data is synthetic.';

CREATE SCHEMA IF NOT EXISTS GPT_LIVE_SHOWCASE.FIELD_SALES
  COMMENT = 'Synthetic pharma field sales book for the openai-gpt-live-1 showcase. All data is fabricated.';

USE WAREHOUSE GPT_LIVE_SHOWCASE_WH;
USE SCHEMA GPT_LIVE_SHOWCASE.FIELD_SALES;

-- ===========================================================================
-- c. Table and sample data
-- ===========================================================================
-- HCP_EVENTS is the only fact table: one row per atomic event about a
-- prescriber (HCP) in one rep's book. Fictional manufacturer Halvern
-- Therapeutics markets ZEVRANTA (zevratimab), a biologic for severe asthma.
-- ORLIVEX is a fictional competitor biologic; ICS/LABA is the inhaled
-- controller class.
--
-- Deterministic: HASH() only, never RANDOM(). Every re-run produces the same
-- EVENT_ID values and the same numbers. Demo "today" is Friday 2026-01-16.

CREATE OR REPLACE TABLE HCP_EVENTS (
  HCP_ID        VARCHAR       NOT NULL,
  HCP_NAME      VARCHAR       NOT NULL,
  REP_ID        VARCHAR       NOT NULL,
  REP_NAME      VARCHAR       NOT NULL,
  EVENT_ID      VARCHAR       NOT NULL,
  EVENT_TS      TIMESTAMP_NTZ NOT NULL,
  EVENT_TYPE    VARCHAR       NOT NULL,
  PRODUCT       VARCHAR,
  TITLE         VARCHAR       NOT NULL,
  BODY          VARCHAR,
  METRIC_NAME   VARCHAR,
  METRIC_VALUE  NUMBER(18,4),
  METRIC_UNIT   VARCHAR,
  ATTRIBUTES    VARIANT,
  CONSTRAINT pk_hcp_events PRIMARY KEY (EVENT_ID)
)
COMMENT = 'One row per atomic event about a prescriber in one rep''s book. All data is synthetic.';

COMMENT ON COLUMN HCP_EVENTS.HCP_ID IS 'Opaque prescriber identifier. Not an NPI.';
COMMENT ON COLUMN HCP_EVENTS.HCP_NAME IS 'Fictional prescriber display name. Denormalized onto every row so no read needs a join.';
COMMENT ON COLUMN HCP_EVENTS.REP_ID IS 'Opaque sales rep identifier.';
COMMENT ON COLUMN HCP_EVENTS.REP_NAME IS 'Fictional sales rep display name. Denormalized onto every row.';
COMMENT ON COLUMN HCP_EVENTS.EVENT_ID IS 'Primary key. Opaque stable identifier for one event row.';
COMMENT ON COLUMN HCP_EVENTS.EVENT_TS IS 'When the event occurred. Monthly facts use the first of the month.';
COMMENT ON COLUMN HCP_EVENTS.EVENT_TYPE IS 'HCP_PROFILE, PRESCRIBING_OBSERVED, PAYER_ACCESS_OBSERVED, MEETING_HELD, OBJECTION_RAISED, PATIENT_COHORT_OBSERVED, NEXT_BEST_ACTION, or MEETING_SCHEDULED.';
COMMENT ON COLUMN HCP_EVENTS.PRODUCT IS 'ZEVRANTA, ORLIVEX, or ICS/LABA where the event is about one product. Null otherwise.';
COMMENT ON COLUMN HCP_EVENTS.TITLE IS 'Always populated. One-line human-readable summary.';
COMMENT ON COLUMN HCP_EVENTS.BODY IS 'Long text only: call note, objection wording, recommendation, payer detail. Nullable.';
COMMENT ON COLUMN HCP_EVENTS.METRIC_NAME IS 'Optional numeric fact name: trx, duration_minutes, payer_mix_pct, or patient_count. Populate METRIC_NAME, METRIC_VALUE, and METRIC_UNIT together, or none.';
COMMENT ON COLUMN HCP_EVENTS.METRIC_VALUE IS 'Optional numeric fact value. Only meaningful filtered or grouped by METRIC_NAME.';
COMMENT ON COLUMN HCP_EVENTS.METRIC_UNIT IS 'Optional numeric fact unit: scripts, minutes, percent, or patients.';
COMMENT ON COLUMN HCP_EVENTS.ATTRIBUTES IS 'Event-specific extras (NRx, NBRx, plan type, call outcome). Not exposed in the semantic view.';

-- The book: twelve fictional prescribers in one rep's Central Valley territory.
-- IS_HERO marks the prescriber the meeting-prep scenario is built around.
-- IS_SUPPORTING marks the four with scheduled visits, payer rows, and calls.
CREATE OR REPLACE TEMPORARY TABLE _BOOK (
  HCP_ID        VARCHAR      NOT NULL,
  HCP_NAME      VARCHAR      NOT NULL,
  SPECIALTY     VARCHAR,
  SEGMENT       VARCHAR,
  TARGET_TIER   NUMBER(2,0),
  PRACTICE_NAME VARCHAR,
  CITY          VARCHAR,
  STATE         VARCHAR,
  BRAND_FOCUS   VARCHAR,
  IS_HERO       BOOLEAN      NOT NULL,
  IS_SUPPORTING BOOLEAN      NOT NULL
);

INSERT INTO _BOOK
SELECT * FROM VALUES
  ('hcp-001', 'Dr. Teodor Vantreese',      'Pulmonary Disease Physician (PDP)', 'Bio-Hesitant Supporter (Tier 2)', 2, 'Birchfield Pulmonary Associates', 'Fresno',      'CA', 'ZEVRANTA PULM (Asthma)', TRUE,  FALSE),
  ('hcp-002', 'Dr. Junia Pellwether',      'Pulmonary Disease Physician (PDP)', 'Champion (Tier 1)',               1, 'Birchfield Pulmonary Associates', 'Fresno',      'CA', 'ZEVRANTA PULM (Asthma)', FALSE, TRUE),
  ('hcp-003', 'Dr. Anselm Kirtridge',      'Allergist / Immunologist',          'Champion (Tier 1)',               1, 'Quillfeather Allergy Partners',    'Clovis',      'CA', 'ZEVRANTA PULM (Asthma)', FALSE, TRUE),
  ('hcp-004', 'Dr. Odalys Fennimore-Rook', 'Pulmonary Disease Physician (PDP)', 'Bio-Hesitant Supporter (Tier 2)', 2, 'Bramblewood Chest & Sleep',        'Visalia',     'CA', 'ZEVRANTA PULM (Asthma)', FALSE, TRUE),
  ('hcp-005', 'Dr. Caspian Wolverly',      'Allergist / Immunologist',          'Bio-Hesitant Supporter (Tier 2)', 2, 'Quillfeather Allergy Partners',    'Clovis',      'CA', 'ZEVRANTA PULM (Asthma)', FALSE, FALSE),
  ('hcp-006', 'Dr. Mireille Quantock',     'Pulmonary Disease Physician (PDP)', 'Sceptic (Tier 3)',                3, 'Thistledown Lung Clinic',          'Fresno',      'CA', 'ZEVRANTA PULM (Asthma)', FALSE, FALSE),
  ('hcp-007', 'Dr. Ezra Thistlewood',      'Internal Medicine',                 'Sceptic (Tier 3)',                3, 'Marrowstone Primary Care',         'Madera',      'CA', 'ICS/LABA',               FALSE, FALSE),
  ('hcp-008', 'Dr. Solvei Brannigan-Oduya','Pulmonary Disease Physician (PDP)', 'Champion (Tier 1)',               1, 'Copperleaf Respiratory Group',     'Bakersfield', 'CA', 'ZEVRANTA PULM (Asthma)', FALSE, TRUE),
  ('hcp-009', 'Dr. Florentin Haverbrook',  'Allergist / Immunologist',          'Bio-Hesitant Supporter (Tier 2)', 2, 'Wildrye Allergy Associates',       'Bakersfield', 'CA', 'ZEVRANTA PULM (Asthma)', FALSE, FALSE),
  ('hcp-010', 'Dr. Ysolde Marchbank',      'Pulmonary Disease Physician (PDP)', 'Sceptic (Tier 3)',                3, 'Saltbrush Chest Medicine',         'Delano',      'CA', 'ICS/LABA',               FALSE, FALSE),
  ('hcp-011', 'Dr. Percival Ravensworth',  'Pulmonary Disease Physician (PDP)', 'Champion (Tier 1)',               1, 'Copperleaf Respiratory Group',     'Bakersfield', 'CA', 'ZEVRANTA PULM (Asthma)', FALSE, FALSE),
  ('hcp-012', 'Dr. Zinnia Corrowan',       'Internal Medicine',                 'Sceptic (Tier 3)',                3, 'Larkspur Hollow Family Medicine',  'Tehachapi',   'CA', 'ICS/LABA',               FALSE, FALSE)
  AS t(HCP_ID, HCP_NAME, SPECIALTY, SEGMENT, TARGET_TIER, PRACTICE_NAME, CITY, STATE, BRAND_FOCUS, IS_HERO, IS_SUPPORTING);

-- ---------------------------------------------------------------------------
-- HCP_PROFILE — exactly one per prescriber
-- ---------------------------------------------------------------------------
INSERT INTO HCP_EVENTS (
  HCP_ID, HCP_NAME, REP_ID, REP_NAME,
  EVENT_ID, EVENT_TS, EVENT_TYPE, PRODUCT, TITLE, BODY,
  METRIC_NAME, METRIC_VALUE, METRIC_UNIT, ATTRIBUTES
)
SELECT
  b.HCP_ID,
  b.HCP_NAME,
  'rep-4417',
  'Alex Rivera',
  'profile:' || b.HCP_ID,
  '2026-01-01 00:00:00'::TIMESTAMP_NTZ,
  'HCP_PROFILE',
  NULL,
  b.SPECIALTY || ', ' || b.SEGMENT || ', ' || b.PRACTICE_NAME || ', ' || b.CITY || ' ' || b.STATE,
  IFF(
    b.IS_HERO,
    'Opportunity (synthetic): 21 OCS-dependent ICS/LABA patients already on the books. Evaluate one for Type 2 inflammation markers this visit.',
    NULL
  ),
  NULL, NULL, NULL,
  OBJECT_CONSTRUCT(
    'specialty', b.SPECIALTY,
    'segment', b.SEGMENT,
    'target_tier', b.TARGET_TIER,
    'practice_name', b.PRACTICE_NAME,
    'city', b.CITY,
    'state', b.STATE,
    'brand_focus', b.BRAND_FOCUS,
    'engagement_tier', IFF(b.IS_HERO, 'High', NULL),
    'opportunity_flag', IFF(b.IS_HERO, TRUE, NULL)
  )
FROM _BOOK b;

-- ---------------------------------------------------------------------------
-- PRESCRIBING_OBSERVED — hero: hand-calibrated 24-month series, Jan-2024..Dec-2025
--   ZEVRANTA asthma   Dec-2025 4.91, Aug-2024 peak 9.74
--   ORLIVEX           Dec-2025 2.00
--   ICS/LABA          Dec-2025 19.27
-- TRx is a weighted total-prescriptions metric, so values are fractional.
-- ---------------------------------------------------------------------------
INSERT INTO HCP_EVENTS (
  HCP_ID, HCP_NAME, REP_ID, REP_NAME,
  EVENT_ID, EVENT_TS, EVENT_TYPE, PRODUCT, TITLE, BODY,
  METRIC_NAME, METRIC_VALUE, METRIC_UNIT, ATTRIBUTES
)
WITH series(M, ZEVRANTA, ORLIVEX, ICS_LABA) AS (
  SELECT * FROM VALUES
    ( 0, 4.12, 0.92, 10.90),
    ( 1, 3.85, 1.05, 11.23),
    ( 2, 4.55, 0.87, 11.67),
    ( 3, 5.02, 1.12, 12.10),
    ( 4, 4.38, 0.95, 12.43),
    ( 5, 3.97, 0.90, 12.77),
    ( 6, 5.61, 0.78, 13.10),
    ( 7, 9.74, 1.08, 13.46),
    ( 8, 5.18, 0.99, 13.79),
    ( 9, 4.44, 0.84, 14.13),
    (10, 3.54, 0.84, 14.47),
    (11, 4.09, 1.02, 14.84),
    (12, 4.83, 1.09, 14.21),
    (13, 4.21, 0.96, 14.55),
    (14, 5.34, 1.18, 14.89),
    (15, 4.67, 1.04, 15.12),
    (16, 3.98, 0.91, 15.38),
    (17, 4.52, 1.13, 15.61),
    (18, 5.07, 1.22, 15.85),
    (19, 4.75, 1.07, 16.09),
    (20, 4.31, 1.31, 16.32),
    (21, 5.16, 1.45, 16.58),
    (22, 4.48, 1.68, 16.84),
    (23, 4.91, 2.00, 19.27)
    AS v(M, ZEVRANTA, ORLIVEX, ICS_LABA)
),
hero AS (
  SELECT HCP_ID, HCP_NAME FROM _BOOK WHERE IS_HERO
),
unpivoted AS (
  SELECT h.HCP_ID, h.HCP_NAME, 'ZEVRANTA' AS PRODUCT, 'ASTHMA' AS INDICATION,
         DATEADD(month, s.M, DATE '2024-01-01') AS MONTH_START, s.ZEVRANTA AS TRX,
         ROUND(s.ZEVRANTA * 0.31, 2) AS NRX, ROUND(s.ZEVRANTA * 0.12, 2) AS NBRX
  FROM series s CROSS JOIN hero h
  UNION ALL
  SELECT h.HCP_ID, h.HCP_NAME, 'ORLIVEX', 'ASTHMA',
         DATEADD(month, s.M, DATE '2024-01-01'), s.ORLIVEX,
         ROUND(s.ORLIVEX * 0.34, 2), ROUND(s.ORLIVEX * 0.15, 2)
  FROM series s CROSS JOIN hero h
  UNION ALL
  SELECT h.HCP_ID, h.HCP_NAME, 'ICS/LABA', 'ASTHMA',
         DATEADD(month, s.M, DATE '2024-01-01'), s.ICS_LABA,
         ROUND(s.ICS_LABA * 0.22, 2), ROUND(s.ICS_LABA * 0.07, 2)
  FROM series s CROSS JOIN hero h
)
SELECT
  u.HCP_ID,
  u.HCP_NAME,
  'rep-4417',
  'Alex Rivera',
  'rx:' || u.HCP_ID || ':' || u.PRODUCT || ':' || TO_CHAR(u.MONTH_START, 'YYYYMM'),
  CAST(u.MONTH_START AS TIMESTAMP_NTZ),
  'PRESCRIBING_OBSERVED',
  u.PRODUCT,
  u.PRODUCT || ' ' || LOWER(u.INDICATION) || ', '
    || INITCAP(TO_CHAR(u.MONTH_START, 'MON')) || ' ' || TO_CHAR(u.MONTH_START, 'YYYY')
    || ': ' || TO_VARCHAR(u.TRX) || ' TRx',
  NULL,
  'trx', u.TRX, 'scripts',
  OBJECT_CONSTRUCT(
    'indication', u.INDICATION,
    'month_start', u.MONTH_START,
    'nrx', u.NRX,
    'nbrx', u.NBRX
  )
FROM unpivoted u;

-- ---------------------------------------------------------------------------
-- PRESCRIBING_OBSERVED — peers: deterministic HASH noise, same 24 months
-- ---------------------------------------------------------------------------
INSERT INTO HCP_EVENTS (
  HCP_ID, HCP_NAME, REP_ID, REP_NAME,
  EVENT_ID, EVENT_TS, EVENT_TYPE, PRODUCT, TITLE, BODY,
  METRIC_NAME, METRIC_VALUE, METRIC_UNIT, ATTRIBUTES
)
WITH months AS (
  SELECT DATEADD(month, SEQ4(), DATE '2024-01-01') AS MONTH_START
  FROM TABLE(GENERATOR(ROWCOUNT => 24))
),
products AS (
  SELECT * FROM VALUES
    ('ZEVRANTA', 'ASTHMA',  6.0),
    ('ORLIVEX',  'ASTHMA',  1.6),
    ('ICS/LABA', 'ASTHMA', 16.0)
    AS p(PRODUCT, INDICATION, BASE)
),
raw AS (
  SELECT
    b.HCP_ID,
    b.HCP_NAME,
    p.PRODUCT,
    p.INDICATION,
    m.MONTH_START,
    ROUND(
      p.BASE
        * CASE b.TARGET_TIER WHEN 1 THEN 1.45 WHEN 2 THEN 1.00 ELSE 0.55 END
        * (0.75 + (ABS(HASH(b.HCP_ID, p.PRODUCT, m.MONTH_START)) % 500) / 1000.0)
        * (1 + DATEDIFF(month, DATE '2024-01-01', m.MONTH_START) * 0.006),
      2
    ) AS TRX
  FROM _BOOK b
  CROSS JOIN products p
  CROSS JOIN months m
  WHERE NOT b.IS_HERO
)
SELECT
  r.HCP_ID,
  r.HCP_NAME,
  'rep-4417',
  'Alex Rivera',
  'rx:' || r.HCP_ID || ':' || r.PRODUCT || ':' || TO_CHAR(r.MONTH_START, 'YYYYMM'),
  CAST(r.MONTH_START AS TIMESTAMP_NTZ),
  'PRESCRIBING_OBSERVED',
  r.PRODUCT,
  r.PRODUCT || ' ' || LOWER(r.INDICATION) || ', '
    || INITCAP(TO_CHAR(r.MONTH_START, 'MON')) || ' ' || TO_CHAR(r.MONTH_START, 'YYYY')
    || ': ' || TO_VARCHAR(r.TRX) || ' TRx',
  NULL,
  'trx', r.TRX, 'scripts',
  OBJECT_CONSTRUCT(
    'indication', r.INDICATION,
    'month_start', r.MONTH_START,
    'nrx', ROUND(r.TRX * 0.29, 2),
    'nbrx', ROUND(r.TRX * 0.11, 2)
  )
FROM raw r;

-- ---------------------------------------------------------------------------
-- MEETING_HELD — hero: 52 calls in the 6 months ending 2026-01-12
-- ---------------------------------------------------------------------------
INSERT INTO HCP_EVENTS (
  HCP_ID, HCP_NAME, REP_ID, REP_NAME,
  EVENT_ID, EVENT_TS, EVENT_TYPE, PRODUCT, TITLE, BODY,
  METRIC_NAME, METRIC_VALUE, METRIC_UNIT, ATTRIBUTES
)
WITH n AS (SELECT SEQ4() AS I FROM TABLE(GENERATOR(ROWCOUNT => 52))),
hero AS (
  SELECT HCP_ID, HCP_NAME FROM _BOOK WHERE IS_HERO
),
calls AS (
  SELECT
    h.HCP_ID,
    h.HCP_NAME,
    'CALL-' || LPAD(n.I::VARCHAR, 5, '0') AS CALL_ID,
    DATEADD(day, -CAST(ROUND((51 - n.I) * 3.5) AS INT), DATE '2026-01-12') AS CALL_DATE,
    CASE MOD(n.I, 5) WHEN 0 THEN 6 WHEN 1 THEN 9 WHEN 2 THEN 4 WHEN 3 THEN 12 ELSE 7 END AS DURATION_MIN,
    CASE WHEN MOD(n.I, 4) = 0 THEN 'Co-Call' WHEN MOD(n.I, 7) = 0 THEN 'Lunch & Learn' ELSE 'In-Person Detail' END AS CALL_TYPE,
    CASE MOD(n.I, 6)
      WHEN 0 THEN 'Type 2 inflammation / eosinophil testing'
      WHEN 1 THEN 'OCS burst reduction'
      WHEN 2 THEN 'Prior authorization support'
      WHEN 3 THEN 'Copay card and patient access'
      WHEN 4 THEN 'ZEVRANTA efficacy data'
      ELSE 'COPD indication update'
    END AS PRIMARY_TOPIC,
    CASE MOD(n.I, 5)
      WHEN 0 THEN 'Engaged - follow up scheduled'
      WHEN 1 THEN 'Brief hallway conversation'
      WHEN 2 THEN 'Declined - no time'
      WHEN 3 THEN 'Engaged - requested clinical reprint'
      ELSE 'Neutral - staff only'
    END AS OUTCOME,
    IFF(MOD(n.I, 4) = 0, 'Morgan Ellery', NULL) AS CO_REP_NAME,
    CASE WHEN MOD(n.I, 3) = 0 THEN 2 ELSE 0 END AS SAMPLES_DROPPED
  FROM n CROSS JOIN hero h
)
SELECT
  c.HCP_ID,
  c.HCP_NAME,
  'rep-4417',
  'Alex Rivera',
  'meeting:' || c.CALL_ID,
  DATEADD(minute, 9 * 60 + (ABS(HASH(c.CALL_ID)) % 90), CAST(c.CALL_DATE AS TIMESTAMP_NTZ)),
  'MEETING_HELD',
  NULL,
  c.CALL_TYPE || ', ' || c.DURATION_MIN::VARCHAR || ' min: ' || c.PRIMARY_TOPIC,
  IFF(
    c.CALL_DATE = DATE '2026-01-12',
    'Call note (synthetic). Most recent visit before the 2026-01-16 meeting. Discussed '
      || c.PRIMARY_TOPIC || '. Outcome: ' || c.OUTCOME
      || '. Cadence is still roughly twice a week, often with the co-calling representative. Staff have asked that visits be scheduled further apart.',
    'Call note (synthetic). Topic: ' || c.PRIMARY_TOPIC || '. Outcome: ' || c.OUTCOME || '.'
  ),
  'duration_minutes', c.DURATION_MIN, 'minutes',
  OBJECT_CONSTRUCT(
    'channel', IFF(c.CALL_TYPE = 'Lunch & Learn', 'lunch_and_learn', 'in_person'),
    'call_type', c.CALL_TYPE,
    'outcome', c.OUTCOME,
    'samples_dropped', c.SAMPLES_DROPPED,
    'co_rep_name', c.CO_REP_NAME
  )
FROM calls c;

-- ---------------------------------------------------------------------------
-- MEETING_HELD — supporting prescribers: two visits each
-- ---------------------------------------------------------------------------
INSERT INTO HCP_EVENTS (
  HCP_ID, HCP_NAME, REP_ID, REP_NAME,
  EVENT_ID, EVENT_TS, EVENT_TYPE, PRODUCT, TITLE, BODY,
  METRIC_NAME, METRIC_VALUE, METRIC_UNIT, ATTRIBUTES
)
WITH seq AS (
  SELECT 1 AS N, 'In-Person Detail, 12 min: Prior authorization support' AS TITLE,
         'Call note (synthetic). Discussed access pathway and staff workflow.' AS BODY,
         12 AS DURATION_MIN
  UNION ALL
  SELECT 2, 'In-Person Detail, 8 min: OCS burst reduction',
         'Call note (synthetic). Reviewed oral corticosteroid burst frequency.',
         8
)
SELECT
  b.HCP_ID,
  b.HCP_NAME,
  'rep-4417',
  'Alex Rivera',
  'meeting:' || b.HCP_ID || '-' || seq.N,
  DATEADD(
    minute,
    10 * 60,
    CAST(
      DATEADD(day, IFF(seq.N = 1, -18, -45) - (ABS(HASH(b.HCP_ID, seq.N)) % 7), DATE '2026-01-16')
      AS TIMESTAMP_NTZ
    )
  ),
  'MEETING_HELD',
  NULL,
  seq.TITLE,
  seq.BODY,
  'duration_minutes', seq.DURATION_MIN, 'minutes',
  OBJECT_CONSTRUCT('channel', 'in_person', 'call_type', 'In-Person Detail', 'outcome', 'Neutral - staff only')
FROM _BOOK b
CROSS JOIN seq
WHERE b.IS_SUPPORTING;

-- ---------------------------------------------------------------------------
-- PAYER_ACCESS_OBSERVED — hero: payer mix across 20 asthma enrolments, Dec-2025
-- Payer names are fictional.
-- ---------------------------------------------------------------------------
INSERT INTO HCP_EVENTS (
  HCP_ID, HCP_NAME, REP_ID, REP_NAME,
  EVENT_ID, EVENT_TS, EVENT_TYPE, PRODUCT, TITLE, BODY,
  METRIC_NAME, METRIC_VALUE, METRIC_UNIT, ATTRIBUTES
)
WITH hero AS (
  SELECT HCP_ID, HCP_NAME FROM _BOOK WHERE IS_HERO
),
payers AS (
  SELECT * FROM VALUES
    ('Lakeshore Regional Health Plan', 'Commercial HMO',   TRUE,  72.50, 8, 2, 2, 40.00),
    ('Sunridge Advantage',             'Medicare Adv.',    TRUE,  61.00, 5, 1, 2, 25.00),
    ('Brightwater Mutual',             'Commercial PPO',   FALSE, 94.00, 4, 0, 0, 20.00),
    ('Orchard Valley Medicaid Plan',   'Managed Medicaid', TRUE,  48.00, 3, 0, 1, 15.00)
    AS t(PAYER_NAME, PLAN_TYPE, PA_REQUIRED, PA_APPROVAL_RATE, ENROLMENTS, APPROVED_NOT_SHIPPED, DENIALS, MIX_PCT)
)
SELECT
  h.HCP_ID,
  h.HCP_NAME,
  'rep-4417',
  'Alex Rivera',
  'payer:' || h.HCP_ID || ':' || p.PAYER_NAME,
  '2025-12-01 00:00:00'::TIMESTAMP_NTZ,
  'PAYER_ACCESS_OBSERVED',
  NULL,
  p.PAYER_NAME || ': ' || TRIM(TO_CHAR(p.MIX_PCT, '990')) || '% of book, prior auth '
    || IFF(p.PA_REQUIRED, 'required', 'not required'),
  'Payer detail (synthetic). ' || p.PLAN_TYPE || '. Prior-auth approval rate '
    || TRIM(TO_CHAR(p.PA_APPROVAL_RATE, '990.0')) || '%. '
    || p.ENROLMENTS::VARCHAR || ' enrolments, '
    || p.APPROVED_NOT_SHIPPED::VARCHAR || ' approved but not shipped, '
    || p.DENIALS::VARCHAR || ' denials.',
  'payer_mix_pct', p.MIX_PCT, 'percent',
  OBJECT_CONSTRUCT(
    'payer_name', p.PAYER_NAME,
    'plan_type', p.PLAN_TYPE,
    'pa_required', p.PA_REQUIRED,
    'pa_approval_rate', p.PA_APPROVAL_RATE,
    'enrolments', p.ENROLMENTS,
    'approved_not_shipped', p.APPROVED_NOT_SHIPPED,
    'denials', p.DENIALS
  )
FROM hero h CROSS JOIN payers p;

-- ---------------------------------------------------------------------------
-- PAYER_ACCESS_OBSERVED — supporting prescribers: one payer each
-- ---------------------------------------------------------------------------
INSERT INTO HCP_EVENTS (
  HCP_ID, HCP_NAME, REP_ID, REP_NAME,
  EVENT_ID, EVENT_TS, EVENT_TYPE, PRODUCT, TITLE, BODY,
  METRIC_NAME, METRIC_VALUE, METRIC_UNIT, ATTRIBUTES
)
WITH payers AS (
  SELECT * FROM VALUES
    ('hcp-002', 'Lakeshore Regional Health Plan', 'Commercial HMO', TRUE,  81.00, 11, 1, 1),
    ('hcp-003', 'Brightwater Mutual',             'Commercial PPO', FALSE, 96.00,  7, 0, 0),
    ('hcp-004', 'Lakeshore Regional Health Plan', 'Commercial HMO', TRUE,  69.00,  6, 2, 1),
    ('hcp-008', 'Sunridge Advantage',             'Medicare Adv.',  TRUE,  74.00,  9, 1, 2)
    AS t(HCP_ID, PAYER_NAME, PLAN_TYPE, PA_REQUIRED, PA_APPROVAL_RATE, ENROLMENTS, APPROVED_NOT_SHIPPED, DENIALS)
)
SELECT
  b.HCP_ID,
  b.HCP_NAME,
  'rep-4417',
  'Alex Rivera',
  'payer:' || b.HCP_ID || ':' || p.PAYER_NAME,
  '2025-12-01 00:00:00'::TIMESTAMP_NTZ,
  'PAYER_ACCESS_OBSERVED',
  NULL,
  p.PAYER_NAME || ': 100% of observed book, prior auth '
    || IFF(p.PA_REQUIRED, 'required', 'not required'),
  'Payer detail (synthetic). ' || p.PLAN_TYPE || '. Prior-auth approval rate '
    || TRIM(TO_CHAR(p.PA_APPROVAL_RATE, '990.0')) || '%. '
    || p.ENROLMENTS::VARCHAR || ' enrolments, '
    || p.APPROVED_NOT_SHIPPED::VARCHAR || ' approved but not shipped, '
    || p.DENIALS::VARCHAR || ' denials.',
  'payer_mix_pct', 100, 'percent',
  OBJECT_CONSTRUCT(
    'payer_name', p.PAYER_NAME,
    'plan_type', p.PLAN_TYPE,
    'pa_required', p.PA_REQUIRED,
    'pa_approval_rate', p.PA_APPROVAL_RATE,
    'enrolments', p.ENROLMENTS,
    'approved_not_shipped', p.APPROVED_NOT_SHIPPED,
    'denials', p.DENIALS
  )
FROM _BOOK b
JOIN payers p ON p.HCP_ID = b.HCP_ID
WHERE b.IS_SUPPORTING;

-- ---------------------------------------------------------------------------
-- PATIENT_COHORT_OBSERVED — hero only: OCS trend 12 -> 20 -> 21 plus Dec alerts.
-- Aggregate headcounts only; no individual patient appears anywhere.
-- ---------------------------------------------------------------------------
INSERT INTO HCP_EVENTS (
  HCP_ID, HCP_NAME, REP_ID, REP_NAME,
  EVENT_ID, EVENT_TS, EVENT_TYPE, PRODUCT, TITLE, BODY,
  METRIC_NAME, METRIC_VALUE, METRIC_UNIT, ATTRIBUTES
)
WITH hero AS (
  SELECT HCP_ID, HCP_NAME FROM _BOOK WHERE IS_HERO
),
cohorts AS (
  SELECT * FROM VALUES
    (DATE '2025-08-01', 'OCS_DEPENDENT_ICS_LABA', 12, 'Asthma patients on ICS/LABA with 2 or more oral corticosteroid bursts in the last 12 months'),
    (DATE '2025-09-01', 'OCS_DEPENDENT_ICS_LABA', 20, 'Asthma patients on ICS/LABA with 2 or more oral corticosteroid bursts in the last 12 months'),
    (DATE '2025-10-01', 'OCS_DEPENDENT_ICS_LABA', 21, 'Asthma patients on ICS/LABA with 2 or more oral corticosteroid bursts in the last 12 months'),
    (DATE '2025-11-01', 'OCS_DEPENDENT_ICS_LABA', 21, 'Asthma patients on ICS/LABA with 2 or more oral corticosteroid bursts in the last 12 months'),
    (DATE '2025-12-01', 'OCS_DEPENDENT_ICS_LABA', 21, 'Asthma patients on ICS/LABA with 2 or more oral corticosteroid bursts in the last 12 months'),
    (DATE '2025-12-01', 'PA_APPROVED_NOT_SHIPPED',  3, 'Asthma enrolments with prior authorisation approved but no shipment recorded'),
    (DATE '2025-12-01', 'NO_COPAY_REDEMPTION',      1, 'First fill dispensed with no copay card redemption - cost-driven discontinuation risk'),
    (DATE '2025-12-01', 'COPD_NEW_DIAGNOSIS',       1, 'Newly diagnosed COPD patient with a ZEVRANTA new-to-brand prescription')
    AS t(AS_OF_MONTH, COHORT_NAME, PATIENT_COUNT, COHORT_DESCRIPTION)
)
SELECT
  h.HCP_ID,
  h.HCP_NAME,
  'rep-4417',
  'Alex Rivera',
  'cohort:' || h.HCP_ID || ':' || c.COHORT_NAME || ':' || TO_CHAR(c.AS_OF_MONTH, 'YYYYMM'),
  CAST(c.AS_OF_MONTH AS TIMESTAMP_NTZ),
  'PATIENT_COHORT_OBSERVED',
  NULL,
  c.PATIENT_COUNT::VARCHAR || ' ' || LOWER(REPLACE(c.COHORT_NAME, '_', ' ')) || ': ' || c.COHORT_DESCRIPTION,
  NULL,
  'patient_count', c.PATIENT_COUNT, 'patients',
  OBJECT_CONSTRUCT(
    'cohort_name', c.COHORT_NAME,
    'as_of_month', c.AS_OF_MONTH
  )
FROM hero h CROSS JOIN cohorts c;

-- ---------------------------------------------------------------------------
-- OBJECTION_RAISED — two open objections on the hero
-- ---------------------------------------------------------------------------
INSERT INTO HCP_EVENTS (
  HCP_ID, HCP_NAME, REP_ID, REP_NAME,
  EVENT_ID, EVENT_TS, EVENT_TYPE, PRODUCT, TITLE, BODY,
  METRIC_NAME, METRIC_VALUE, METRIC_UNIT, ATTRIBUTES
)
SELECT
  b.HCP_ID, b.HCP_NAME, 'rep-4417', 'Alex Rivera',
  'objection:' || b.HCP_ID || ':1',
  '2026-01-12 10:15:00'::TIMESTAMP_NTZ,
  'OBJECTION_RAISED',
  'ZEVRANTA',
  'Objection: "I''m comfortable with my current approach. These patients are doing okay on ICS/LABA plus OCS when needed."',
  'Verbatim (synthetic). Raised on the 2026-01-12 visit. Context: bio-hesitant supporter, comfortable escalating inhaled therapy and reaching for oral corticosteroid bursts, hesitant to initiate a biologic without eosinophil confirmation. He has previously said he does not want to start a biologic he cannot get approved.',
  NULL, NULL, NULL,
  OBJECT_CONSTRUCT('indication', 'ASTHMA', 'theme', 'bio_hesitancy')
FROM _BOOK b WHERE b.IS_HERO
UNION ALL
SELECT
  b.HCP_ID, b.HCP_NAME, 'rep-4417', 'Alex Rivera',
  'objection:' || b.HCP_ID || ':2',
  '2025-12-15 11:00:00'::TIMESTAMP_NTZ,
  'OBJECTION_RAISED',
  'ZEVRANTA',
  'Objection: "Biologics are expensive and hard to get approved."',
  'Verbatim (synthetic). Access/process objection rather than clinical scepticism. Several asthma enrolments have cleared prior authorisation but never shipped, so the friction is pull-through after the prescription is written.',
  NULL, NULL, NULL,
  OBJECT_CONSTRUCT('indication', 'ASTHMA', 'theme', 'access')
FROM _BOOK b WHERE b.IS_HERO;

-- ---------------------------------------------------------------------------
-- NEXT_BEST_ACTION — one open recommendation for the scheduled visit
-- ---------------------------------------------------------------------------
INSERT INTO HCP_EVENTS (
  HCP_ID, HCP_NAME, REP_ID, REP_NAME,
  EVENT_ID, EVENT_TS, EVENT_TYPE, PRODUCT, TITLE, BODY,
  METRIC_NAME, METRIC_VALUE, METRIC_UNIT, ATTRIBUTES
)
SELECT
  b.HCP_ID, b.HCP_NAME, 'rep-4417', 'Alex Rivera',
  'nba:' || b.HCP_ID,
  '2026-01-16 00:00:00'::TIMESTAMP_NTZ,
  'NEXT_BEST_ACTION',
  'ZEVRANTA',
  'Bring the prior-auth turnaround data and the step-edit pathway one-pager',
  'Open recommendation (synthetic) for the 2026-01-16 visit: address the 21 OCS-dependent asthma patients not on ZEVRANTA. Ask to evaluate one of those patients for Type 2 inflammation markers. Offer a field reimbursement in-service for office staff, copay-card materials, and a 15-minute pull-through working session. Coordinate with co-calling rep Morgan Ellery to reduce visit frequency.',
  NULL, NULL, NULL,
  OBJECT_CONSTRUCT(
    'focus', 'OCS_DEPENDENT_ICS_LABA',
    'resources', ARRAY_CONSTRUCT('HCP Checklist', 'Wall Chart', 'Co-pay Card', 'Field reimbursement in-service')
  )
FROM _BOOK b WHERE b.IS_HERO;

-- ---------------------------------------------------------------------------
-- MEETING_SCHEDULED — five visits on demo day Friday 2026-01-16.
-- The hero visit at 09:30 is the meeting-prep scenario.
-- ---------------------------------------------------------------------------
INSERT INTO HCP_EVENTS (
  HCP_ID, HCP_NAME, REP_ID, REP_NAME,
  EVENT_ID, EVENT_TS, EVENT_TYPE, PRODUCT, TITLE, BODY,
  METRIC_NAME, METRIC_VALUE, METRIC_UNIT, ATTRIBUTES
)
SELECT
  b.HCP_ID, b.HCP_NAME, 'rep-4417', 'Alex Rivera',
  'scheduled:' || b.HCP_ID,
  s.EVENT_TS::TIMESTAMP_NTZ,
  'MEETING_SCHEDULED',
  NULL,
  s.TITLE,
  s.BODY,
  NULL, NULL, NULL,
  OBJECT_CONSTRUCT(
    'practice_name', b.PRACTICE_NAME,
    'city', b.CITY,
    'state', b.STATE,
    'duration_minutes', 30,
    'channel', 'in_person',
    'start_time', s.START_TIME,
    'end_time', s.END_TIME,
    'purpose', s.PURPOSE,
    'prep_status', s.PREP_STATUS
  )
FROM _BOOK b
JOIN (
  SELECT * FROM VALUES
    (
      'hcp-001',
      '2026-01-16 09:30:00',
      '09:30',
      '10:00',
      'Fri 09:30, Birchfield Pulmonary Associates, Fresno, 30 min',
      'Upcoming visit (synthetic). Focus: 21 OCS-dependent ICS/LABA patients and pull-through on already-approved enrolments.',
      '21 OCS-dependent ICS/LABA patients and pull-through',
      'Ready'
    ),
    (
      'hcp-002',
      '2026-01-16 10:30:00',
      '10:30',
      '11:00',
      'Fri 10:30, Birchfield Pulmonary Associates, Fresno, 30 min',
      'Follow-up at the same practice (synthetic). Confirm ZEVRANTA pull-through after last week''s in-service.',
      'Follow-up, same practice',
      'Ready'
    ),
    (
      'hcp-003',
      '2026-01-16 13:00:00',
      '13:00',
      '13:30',
      'Fri 13:00, Quillfeather Allergy Partners, Clovis, 30 min',
      'Allergy consult in Clovis (synthetic). Review ORLIVEX vs ZEVRANTA split on the atopic book.',
      'Allergy consult, Clovis',
      'Review Needed'
    ),
    (
      'hcp-004',
      '2026-01-16 14:30:00',
      '14:30',
      '15:00',
      'Fri 14:30, Bramblewood Chest & Sleep, Visalia, 30 min',
      'Visalia access review (synthetic). Prior-auth friction on two commercial plans.',
      'Visalia access review',
      'Review Needed'
    ),
    (
      'hcp-008',
      '2026-01-16 16:00:00',
      '16:00',
      '16:30',
      'Fri 16:00, Copperleaf Respiratory Group, Bakersfield, 30 min',
      'Relationship call in Bakersfield (synthetic). Champion account; keep the cadence without a hard pitch.',
      'Bakersfield relationship',
      'Urgent'
    )
    AS t(HCP_ID, EVENT_TS, START_TIME, END_TIME, TITLE, BODY, PURPOSE, PREP_STATUS)
) s ON b.HCP_ID = s.HCP_ID;

DROP TABLE IF EXISTS _BOOK;

-- ===========================================================================
-- d. Semantic view
-- ===========================================================================
-- METRIC_VALUE is the only numeric column, by design. Summing or averaging it
-- across different METRIC_NAME values is meaningless (TRx mixed with minutes
-- mixed with percents). Any aggregation of metric_value MUST be filtered or
-- grouped by metric_name.
--
-- Synonyms share one namespace with table aliases, so the table alias
-- `events` is not repeated in WITH SYNONYMS. Snowflake rejects that collision.

CREATE OR REPLACE SEMANTIC VIEW FIELD_SALES_SV

  TABLES (
    events AS HCP_EVENTS
      PRIMARY KEY (EVENT_ID)
      WITH SYNONYMS ('activity', 'history', 'timeline')
      COMMENT = 'One row per atomic event about a prescriber in one rep''s book. All demo data is synthetic.'
  )

  FACTS (
    events.metric_value AS METRIC_VALUE
      WITH SYNONYMS ('value', 'amount', 'quantity', 'measured value')
      COMMENT = 'Optional numeric fact on the event. Only meaningful when filtered or grouped by metric_name; do not sum across mixed metric names.'
  )

  DIMENSIONS (
    events.hcp_id AS HCP_ID
      WITH SYNONYMS ('prescriber identifier', 'hcp key')
      COMMENT = 'Opaque prescriber identifier. Not an NPI.',
    events.hcp_name AS HCP_NAME
      WITH SYNONYMS ('prescriber', 'doctor', 'physician', 'HCP', 'provider', 'clinician')
      COMMENT = 'Fictional prescriber name, for example Dr. Teodor Vantreese. Repeated on every event so no join is required. Match on surname with ILIKE when the user gives only part of the name.',
    events.rep_id AS REP_ID
      WITH SYNONYMS ('rep identifier', 'rep key')
      COMMENT = 'Opaque sales rep identifier. One rep in the seed.',
    events.rep_name AS REP_NAME
      WITH SYNONYMS ('rep', 'sales rep', 'representative', 'territory owner')
      COMMENT = 'Display name of the rep who holds this prescriber. Repeated on every event.',
    events.event_id AS EVENT_ID
      WITH SYNONYMS ('event identifier', 'row id')
      COMMENT = 'Primary key of one event row. Opaque stable identifier.',
    events.event_ts AS EVENT_TS
      WITH SYNONYMS ('timestamp', 'when', 'event time', 'date')
      COMMENT = 'When the event occurred. Monthly facts use the first of the month. Use this to filter a month, a day, or an upcoming meeting. Demo today is 2026-01-16.',
    events.event_type AS EVENT_TYPE
      WITH SYNONYMS ('kind of event', 'event kind', 'type of activity')
      COMMENT = 'One of HCP_PROFILE (specialty, segment, tier, practice, city), PRESCRIBING_OBSERVED (monthly TRx by product), PAYER_ACCESS_OBSERVED (payer mix and prior auth), MEETING_HELD (past call), OBJECTION_RAISED (open objection), PATIENT_COHORT_OBSERVED (aggregate patient headcount), NEXT_BEST_ACTION (open recommendation), MEETING_SCHEDULED (upcoming visit).',
    events.product AS PRODUCT
      WITH SYNONYMS ('brand', 'drug', 'medication', 'therapy')
      COMMENT = 'ZEVRANTA (our biologic, zevratimab), ORLIVEX (competitor biologic), or ICS/LABA (inhaled controller class). Null for events not about one product.',
    events.title AS TITLE
      WITH SYNONYMS ('summary', 'headline', 'one-line summary')
      COMMENT = 'Always populated. One-line human summary. Profile titles carry specialty, segment and tier, practice, and city; payer titles carry payer name, share of book, and prior-auth requirement.',
    events.body AS BODY
      WITH SYNONYMS ('notes', 'details', 'transcript', 'long text')
      COMMENT = 'Optional long text: call note, objection wording, recommendation, or payer detail (approval rate, approved-not-shipped, denials).',
    events.metric_name AS METRIC_NAME
      WITH SYNONYMS ('measure', 'metric', 'what was measured')
      COMMENT = 'Name of the optional numeric fact: trx, duration_minutes, payer_mix_pct, or patient_count. Required companion of any metric_value aggregation.',
    events.metric_unit AS METRIC_UNIT
      WITH SYNONYMS ('unit', 'units', 'uom')
      COMMENT = 'Unit of the optional numeric fact: scripts, minutes, percent, or patients.'
  )

  METRICS (
    events.event_count AS COUNT(events.EVENT_ID)
      WITH SYNONYMS ('number of events', 'how many events', 'event volume')
      COMMENT = 'Count of event rows. Filter event_type = MEETING_HELD to count calls.',
    events.metric_total AS SUM(events.metric_value)
      WITH SYNONYMS ('total metric', 'sum of the metric')
      COMMENT = 'Sum of metric_value. Meaningless unless filtered or grouped by metric_name.',
    events.metric_average AS AVG(events.metric_value)
      WITH SYNONYMS ('average metric', 'mean metric', 'typical metric')
      COMMENT = 'Average of metric_value. Meaningless unless filtered or grouped by metric_name.',
    events.hcp_count AS COUNT(DISTINCT events.HCP_ID)
      WITH SYNONYMS ('number of prescribers', 'how many prescribers', 'distinct prescribers')
      COMMENT = 'Distinct prescribers in the selected events.'
  )

  COMMENT = 'Synthetic pharma field sales event log for Cortex Analyst. METRIC_VALUE aggregations must be filtered or grouped by METRIC_NAME. All data is synthetic.';

-- ===========================================================================
-- e. OPTIONAL: Cortex Search over free-text notes
-- ===========================================================================
-- Skip this block if you do not need it. The agent in section f works without
-- it. It indexes BODY (call notes, objection wording, recommendations, payer
-- detail) so the agent can answer "what did he say about ..." style questions
-- by meaning rather than by exact filter.
--
-- To enable: uncomment the statement below, uncomment the search grant in
-- section h, and add the search tool to the agent as described at the end of
-- section f. Cortex Search must be available in your account's region.
--
-- CREATE OR REPLACE CORTEX SEARCH SERVICE FIELD_NOTES_SEARCH
--   ON BODY
--   ATTRIBUTES HCP_NAME, EVENT_TYPE, PRODUCT
--   WAREHOUSE = GPT_LIVE_SHOWCASE_WH
--   TARGET_LAG = '1 day'
--   AS (
--     SELECT EVENT_ID, HCP_NAME, EVENT_TYPE, PRODUCT, TITLE, BODY, EVENT_TS
--     FROM HCP_EVENTS
--     WHERE BODY IS NOT NULL
--   );

-- ===========================================================================
-- f. Agent
-- ===========================================================================
-- Analyst-only: one tool over FIELD_SALES_SV. The app server calls this agent
-- (agent:run) when openai-gpt-live-1 delegates a question, and openai-gpt-live-1 speaks the
-- answer, so the response instructions are written for speech.
-- Only documented spec fields are used.

CREATE OR REPLACE AGENT FIELD_SALES_AGENT
  COMMENT = 'openai-gpt-live-1 showcase field sales agent over FIELD_SALES_SV. Answers are spoken aloud. Synthetic data.'
  FROM SPECIFICATION
  $$
models:
  orchestration: auto
instructions:
  orchestration: |
    You answer questions for Alex Rivera, a pharmaceutical field sales rep at
    Halvern Therapeutics who is about to walk into a meeting with a prescriber.
    "My", "I" and "me" refer to Alex Rivera's book. Today is Friday 2026-01-16.
    Answer only from query_sales_data. Never invent a fact. If the data cannot
    answer, say so plainly.

    Products:
    - ZEVRANTA (zevratimab) is Halvern's biologic for severe asthma.
    - ORLIVEX is a competitor biologic.
    - ICS/LABA is the inhaled controller class, not a brand.

    Metric rule:
    - metric_name always accompanies any metric_value aggregation. Never return
      a single total of metric_value across mixed metric names. That mixes TRx,
      minutes, percents, and headcounts. Group or filter by metric_name.
    - TRx is weighted and fractional. "Prescriptions" means trx.

    Event types:
    - HCP_PROFILE carries identity (specialty, segment and tier, practice, city).
    - PRESCRIBING_OBSERVED is monthly TRx by product, January 2024 to
      December 2025. December 2025 is the latest month.
    - PAYER_ACCESS_OBSERVED is payer mix and prior-auth detail.
    - MEETING_HELD is a past call; BODY holds the note.
    - OBJECTION_RAISED is an open objection in the prescriber's words.
    - PATIENT_COHORT_OBSERVED is an aggregate headcount, never a named patient.
    - NEXT_BEST_ACTION is an open recommendation for the next visit.
    - MEETING_SCHEDULED is an upcoming visit.

    When the user names a prescriber, filter to that prescriber; match on
    surname if that is all they gave. If they say "he" or "the doctor" with no
    name earlier in the conversation, assume the next scheduled meeting.

    Efficiency. Every extra step is dead air on a voice call:
    - Take the fewest steps that answer the question. Prefer one query that
      returns what you need over several narrower ones.
    - Once a tool returns what you asked for, answer from it. Do not re-plan.
    - Stop as soon as you can answer. No unrequested breakdowns.

    Never build a chart or visualization, and never call data_to_chart or a
    charting skill. The answer is spoken; a chart is pure latency.

    All data is synthetic. Never imply it is real customer or patient data.
    Do not give medical advice or make clinical claims beyond what the data
    says.
  response: |
    Your answer is read aloud by a voice assistant. Write plain spoken prose.

    - Two to four short sentences. One is fine when it answers the question.
    - Lead with the answer and say the time period it covers.
    - Round numbers for speech: one decimal for TRx ("about 4.9"), whole
      numbers for percents and counts. Say "percent", not "%".
    - No markdown: no tables, bullets, headings, bold, or code.
    - No URLs, IDs, SQL, column names, or event-type codes.
    - Say "prior authorization", not "PA". Say dates in words
      ("December 2025", "Friday at 9:30").
    - No filler openers and no closing offers of more help.
tools:
  - tool_spec:
      type: "cortex_analyst_text_to_sql"
      name: "query_sales_data"
      description: |
        Query every recorded event about prescribers in the rep's book:
        profiles, monthly prescribing by product, payer access, past calls,
        objections, patient cohorts, recommendations, and scheduled meetings.
        Filter by prescriber when one is named. Always group or filter
        metric_value by metric_name.
tool_resources:
  query_sales_data:
    semantic_view: "GPT_LIVE_SHOWCASE.FIELD_SALES.FIELD_SALES_SV"
    execution_environment:
      type: "warehouse"
      warehouse: "GPT_LIVE_SHOWCASE_WH"
  $$;

-- OPTIONAL: add Cortex Search as a second tool (only after section e ran).
-- Add this entry under `tools:` in the specification above:
--
--   - tool_spec:
--       type: "cortex_search"
--       name: "search_notes"
--       description: |
--         Search free-text call notes, objection wording, recommendations,
--         and payer detail by meaning. Use for "what did they say about"
--         questions. Use query_sales_data for numbers and counts.
--
-- and this entry under `tool_resources:`:
--
--   search_notes:
--     name: "GPT_LIVE_SHOWCASE.FIELD_SALES.FIELD_NOTES_SEARCH"
--     max_results: 5
--     id_column: "EVENT_ID"
--     title_column: "TITLE"
--
-- then re-run the CREATE OR REPLACE AGENT statement.

-- ===========================================================================
-- g. Day briefing (precomputed insights)
-- ===========================================================================
-- One row, one column BRIEF: one line per visit on the earliest day with
-- scheduled meetings (the demo's "today"), with the visit's focus, the
-- prescriber's latest TRx by product, top payer, open objections and next
-- best action. The app reads it when a call starts and adds it to openai-gpt-live-1's
-- instructions, so questions it covers are answered at once. Everything else
-- (trends, other months, past visits, other prescribers) still goes to the
-- agent. Plain SQL over HCP_EVENTS, so it is deterministic; change it to put
-- different insights in the briefing.

CREATE OR REPLACE VIEW DAY_BRIEF
  COMMENT = 'Precomputed briefing for the voice assistant: one row, column BRIEF. Synthetic data.'
AS
  WITH day AS (
    SELECT MIN(EVENT_TS)::DATE AS D FROM HCP_EVENTS WHERE EVENT_TYPE = 'MEETING_SCHEDULED'
  ),
  visits AS (
    SELECT e.HCP_ID, e.HCP_NAME, e.REP_NAME, e.EVENT_TS, e.TITLE, e.BODY
    FROM HCP_EVENTS e JOIN day ON e.EVENT_TS::DATE = day.D
    WHERE e.EVENT_TYPE = 'MEETING_SCHEDULED'
  ),
  facts AS (
    SELECT e.* FROM HCP_EVENTS e WHERE e.HCP_ID IN (SELECT HCP_ID FROM visits)
  ),
  last_month AS (
    SELECT HCP_ID, PRODUCT, METRIC_VALUE, EVENT_TS FROM facts
    WHERE EVENT_TYPE = 'PRESCRIBING_OBSERVED' AND METRIC_NAME = 'trx'
    QUALIFY EVENT_TS = MAX(EVENT_TS) OVER (PARTITION BY HCP_ID)
  ),
  trx AS (
    SELECT HCP_ID, TO_CHAR(MAX(EVENT_TS), 'Mon YYYY') AS MONTH,
           LISTAGG(PRODUCT || ' ' || TO_CHAR(ROUND(METRIC_VALUE, 1)), ', ')
             WITHIN GROUP (ORDER BY PRODUCT) AS TRX
    FROM last_month GROUP BY HCP_ID
  ),
  top_payer AS (
    SELECT HCP_ID, TITLE FROM facts WHERE EVENT_TYPE = 'PAYER_ACCESS_OBSERVED'
    QUALIFY ROW_NUMBER() OVER (PARTITION BY HCP_ID ORDER BY METRIC_VALUE DESC NULLS LAST, TITLE) = 1
  ),
  objections AS (
    SELECT HCP_ID,
           LISTAGG(REPLACE(TITLE, 'Objection: ', ''), ' ') WITHIN GROUP (ORDER BY EVENT_TS) AS TEXT
    FROM facts WHERE EVENT_TYPE = 'OBJECTION_RAISED' GROUP BY HCP_ID
  ),
  next_action AS (
    SELECT HCP_ID, TITLE FROM facts WHERE EVENT_TYPE = 'NEXT_BEST_ACTION'
    QUALIFY ROW_NUMBER() OVER (PARTITION BY HCP_ID ORDER BY EVENT_TS DESC) = 1
  )
  SELECT
    'Today is ' || DAYNAME(ANY_VALUE(day.D)) || ' ' || TO_CHAR(ANY_VALUE(day.D), 'YYYY-MM-DD') || '. '
    || ANY_VALUE(v.REP_NAME) || ' has ' || COUNT(*) || ' visits:\n'
    || LISTAGG(
         '- ' || v.HCP_NAME || ', ' || v.TITLE || '. ' || REPLACE(v.BODY, ' (synthetic)', '')
         || COALESCE(' Latest TRx (' || t.MONTH || '): ' || t.TRX || '.', '')
         || COALESCE(' Top payer: ' || p.TITLE || '.', '')
         || COALESCE(' Open objections: ' || o.TEXT, '')
         || COALESCE(' Next best action: ' || n.TITLE || '.', ''),
         '\n'
       ) WITHIN GROUP (ORDER BY v.EVENT_TS) AS BRIEF
  FROM visits v
  CROSS JOIN day
  LEFT JOIN trx t ON t.HCP_ID = v.HCP_ID
  LEFT JOIN top_payer p ON p.HCP_ID = v.HCP_ID
  LEFT JOIN objections o ON o.HCP_ID = v.HCP_ID
  LEFT JOIN next_action n ON n.HCP_ID = v.HCP_ID;

-- ===========================================================================
-- h. Grants to GPT_LIVE_SHOWCASE_ROLE
-- ===========================================================================
-- The agent runs with the caller's privileges, so the role that calls
-- agent:run needs the warehouse, the table, the semantic view, and the agent.
-- CREATE OR REPLACE drops grants on the replaced object, so these run after
-- every re-create.

GRANT USAGE ON WAREHOUSE GPT_LIVE_SHOWCASE_WH TO ROLE GPT_LIVE_SHOWCASE_ROLE;
GRANT USAGE ON DATABASE GPT_LIVE_SHOWCASE TO ROLE GPT_LIVE_SHOWCASE_ROLE;
GRANT USAGE ON SCHEMA GPT_LIVE_SHOWCASE.FIELD_SALES TO ROLE GPT_LIVE_SHOWCASE_ROLE;

GRANT SELECT ON TABLE GPT_LIVE_SHOWCASE.FIELD_SALES.HCP_EVENTS TO ROLE GPT_LIVE_SHOWCASE_ROLE;

GRANT REFERENCES, SELECT ON SEMANTIC VIEW GPT_LIVE_SHOWCASE.FIELD_SALES.FIELD_SALES_SV TO ROLE GPT_LIVE_SHOWCASE_ROLE;

GRANT SELECT ON VIEW GPT_LIVE_SHOWCASE.FIELD_SALES.DAY_BRIEF TO ROLE GPT_LIVE_SHOWCASE_ROLE;

GRANT USAGE ON AGENT GPT_LIVE_SHOWCASE.FIELD_SALES.FIELD_SALES_AGENT TO ROLE GPT_LIVE_SHOWCASE_ROLE;

-- OPTIONAL: only if section e created the search service.
-- GRANT USAGE ON CORTEX SEARCH SERVICE GPT_LIVE_SHOWCASE.FIELD_SALES.FIELD_NOTES_SEARCH TO ROLE GPT_LIVE_SHOWCASE_ROLE;

-- CORTEX_AGENT_USER covers calling agents. CORTEX_USER covers the other
-- Cortex functions the agent's analyst step uses.
GRANT DATABASE ROLE SNOWFLAKE.CORTEX_AGENT_USER TO ROLE GPT_LIVE_SHOWCASE_ROLE;
GRANT DATABASE ROLE SNOWFLAKE.CORTEX_USER TO ROLE GPT_LIVE_SHOWCASE_ROLE;

-- Private Preview: the openai-gpt-live-1 model must also be enabled for this
-- account. See ../README.md ("Enable openai-gpt-live-1 on your account"). Model access is
-- role-based: by default every role can use every model (Snowflake grants
-- CORTEX-MODEL-ROLE-ALL to SNOWFLAKE.PUBLIC), so no grant is needed. If your
-- account limits model access, grant the openai-gpt-live-1 model role, plus one model role the
-- agent can use (README, "Enable openai-gpt-live-1 on your account"):
--   GRANT APPLICATION ROLE SNOWFLAKE."CORTEX-MODEL-ROLE-OPENAI-GPT-LIVE-1" TO ROLE GPT_LIVE_SHOWCASE_ROLE;

-- Give the role to each user who signs in to the app:
-- GRANT ROLE GPT_LIVE_SHOWCASE_ROLE TO USER <your_user>;

-- ===========================================================================
-- i. Sign-in for the local app (OAuth)
-- ===========================================================================
-- The local app signs you in with Snowflake in the browser and keeps the
-- token in memory only: nothing secret is stored on disk.
-- A public client with PKCE needs no client secret. The app asks for
-- GPT_LIVE_SHOWCASE_ROLE only (SNOWFLAKE_ROLE), so the token carries that role,
-- and Snowflake blocks ACCOUNTADMIN and SECURITYADMIN for OAuth by default.
-- The redirect URI must match the app's address. If you change LISTEN_PORT,
-- run ALTER SECURITY INTEGRATION GPT_LIVE_SHOWCASE_OAUTH SET OAUTH_REDIRECT_URI
-- = 'http://127.0.0.1:<port>/oauth/callback'; re-running this file won't change
-- an integration that already exists. http is only allowed for this loopback address.
-- SPCS doesn't use this: there the app uses the token Snowflake mounts.

CREATE SECURITY INTEGRATION IF NOT EXISTS GPT_LIVE_SHOWCASE_OAUTH
  TYPE = OAUTH
  ENABLED = TRUE
  OAUTH_CLIENT = CUSTOM
  OAUTH_CLIENT_TYPE = 'PUBLIC'
  OAUTH_REDIRECT_URI = 'http://127.0.0.1:3000/oauth/callback'
  OAUTH_ALLOW_NON_TLS_REDIRECT_URI = TRUE
  OAUTH_ENFORCE_PKCE = TRUE
  OAUTH_ISSUE_REFRESH_TOKENS = TRUE
  OAUTH_REFRESH_TOKEN_VALIDITY = 86400
  COMMENT = 'Sign-in for the openai-gpt-live-1 showcase app run locally.';

-- The client ID for .env (SNOWFLAKE_OAUTH_CLIENT_ID). It's not a secret.
SELECT PARSE_JSON(SYSTEM$SHOW_OAUTH_CLIENT_SECRETS('GPT_LIVE_SHOWCASE_OAUTH')):OAUTH_CLIENT_ID::STRING
  AS SNOWFLAKE_OAUTH_CLIENT_ID;

-- ===========================================================================
-- j. Validation (read-only; safe to run on its own)
-- ===========================================================================
-- Expected: 960 rows. HCP_PROFILE 12, PRESCRIBING_OBSERVED 864,
-- MEETING_HELD 60, PAYER_ACCESS_OBSERVED 8, PATIENT_COHORT_OBSERVED 8,
-- OBJECTION_RAISED 2, NEXT_BEST_ACTION 1, MEETING_SCHEDULED 5.

USE WAREHOUSE GPT_LIVE_SHOWCASE_WH;
USE SCHEMA GPT_LIVE_SHOWCASE.FIELD_SALES;

SELECT EVENT_TYPE, COUNT(*) AS N
FROM HCP_EVENTS
GROUP BY EVENT_TYPE
ORDER BY EVENT_TYPE;

-- Expected: ZEVRANTA 4.91, ORLIVEX 2.00, ICS/LABA 19.27.
SELECT PRODUCT, METRIC_VALUE AS DEC_2025_TRX
FROM HCP_EVENTS
WHERE HCP_ID = 'hcp-001'
  AND EVENT_TYPE = 'PRESCRIBING_OBSERVED'
  AND EVENT_TS = '2025-12-01 00:00:00'::TIMESTAMP_NTZ
ORDER BY PRODUCT;

-- Expected: 960.
SELECT event_count
FROM SEMANTIC_VIEW(
  GPT_LIVE_SHOWCASE.FIELD_SALES.FIELD_SALES_SV
  METRICS event_count
);

-- Event count per type through the semantic view.
SELECT *
FROM SEMANTIC_VIEW(
  GPT_LIVE_SHOWCASE.FIELD_SALES.FIELD_SALES_SV
  DIMENSIONS events.event_type
  METRICS events.event_count
)
ORDER BY event_type;

SHOW SEMANTIC VIEWS LIKE 'FIELD_SALES_SV' IN SCHEMA GPT_LIVE_SHOWCASE.FIELD_SALES;
SHOW AGENTS LIKE 'FIELD_SALES_AGENT' IN SCHEMA GPT_LIVE_SHOWCASE.FIELD_SALES;
DESCRIBE AGENT GPT_LIVE_SHOWCASE.FIELD_SALES.FIELD_SALES_AGENT;

-- The briefing the app adds to openai-gpt-live-1's instructions (about 2,000 characters).
SELECT BRIEF FROM GPT_LIVE_SHOWCASE.FIELD_SALES.DAY_BRIEF;
