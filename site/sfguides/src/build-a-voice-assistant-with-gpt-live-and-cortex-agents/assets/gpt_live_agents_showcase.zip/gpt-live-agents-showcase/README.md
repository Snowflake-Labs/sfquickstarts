# openai-gpt-live-1 + Cortex Agents: voice meeting prep

> **Note:** `openai-gpt-live-1` is currently in Private Preview.
> Contact your Snowflake account team to request access.

> **Sample code, not production code.** This app shows how `openai-gpt-live-1` and Cortex
> Agents fit together. It isn't a supported Snowflake product and isn't
> hardened for production: review it, and add what your organization needs,
> before you use it with real data.

A hands-free voice assistant for a field sales rep preparing for a meeting with
a doctor. You talk to **`openai-gpt-live-1`** in the browser. When a question needs data,
`openai-gpt-live-1` answers from today's briefing, precomputed in Snowflake, or hands it to
a **Snowflake Cortex Agent**, and the answer is spoken back to you. On screen are
the call controls (Start/End call, Mute, Copy transcript) and a
live transcript with a row for each Snowflake lookup.

All data is synthetic and every name is fictional (Halvern Therapeutics,
ZEVRANTA, …). See [`snowflake/DATA_NOTES.md`](snowflake/DATA_NOTES.md).

This README is the short reference. The Snowflake quickstart guide *Build a
Voice Assistant with openai-gpt-live-1 and Cortex Agents* walks through the same steps
with explanations and a diagram.

## What you need

- A Snowflake account that can use the **`openai-gpt-live-1`** model. See
  [Enable openai-gpt-live-1 on your account](#enable-openai-gpt-live-1-on-your-account).
- **ACCOUNTADMIN** for the one-time setup.
- **Node.js 20.12+** and a browser with WebRTC (Chrome, Edge, Safari or Firefox).
- [Cross-region inference](https://docs.snowflake.com/en/user-guide/snowflake-cortex/cross-region-inference) that includes Azure US, where `openai-gpt-live-1` runs.
  It's an account-wide setting that applies to every model; see
  [Enable openai-gpt-live-1](#enable-openai-gpt-live-1-on-your-account) step 4.
- For the CLI commands, a [Snowflake CLI](https://docs.snowflake.com/developer-guide/snowflake-cli/index)
  connection (`snow connection add`). `<your-connection>` below is its name.

**Cost.** Each call opens an `openai-gpt-live-1` session and each lookup runs the Cortex
Agent; both use credits (see the
[Snowflake Service Consumption Table](https://www.snowflake.com/legal-files/CreditConsumptionTable.pdf)).
The server lets each user start at most 6 calls and 20 lookups a minute.

## Quick start (local)

**1. Create the Snowflake objects.** Run [`snowflake/setup.sql`](snowflake/setup.sql)
as ACCOUNTADMIN, in a Snowsight worksheet (Run All) or with the CLI:

```bash
snow sql -c <your-connection> --role ACCOUNTADMIN -f snowflake/setup.sql
```

It builds the role, warehouse, database, sample data, semantic view, agent,
briefing view (`DAY_BRIEF`), grants and the OAuth sign-in for the app
(`GPT_LIVE_SHOWCASE_OAUTH`), and is safe to re-run. Near the end it prints
`SNOWFLAKE_OAUTH_CLIENT_ID`, which you need in step 2. Then, as ACCOUNTADMIN,
give yourself the role:

```sql
GRANT ROLE GPT_LIVE_SHOWCASE_ROLE TO USER <your_user>;
```

To check the agent on its own, open **AI & ML → Agents → FIELD_SALES_AGENT** in
Snowsight and ask "How much ZEVRANTA did Dr. Vantreese prescribe in December?"
(about 4.9 prescriptions).

**2. Configure.** Copy the example and fill in the two required values:

```bash
cp .env.example .env
```

```bash
SNOWFLAKE_ACCOUNT_URL=https://<org>-<account>.snowflakecomputing.com
SNOWFLAKE_OAUTH_CLIENT_ID=<the client ID from step 1>
```

The client ID isn't a secret. To see it again:
`SELECT PARSE_JSON(SYSTEM$SHOW_OAUTH_CLIENT_SECRETS('GPT_LIVE_SHOWCASE_OAUTH')):OAUTH_CLIENT_ID::STRING;`.
Everything else has a working default; see [Configuration](#configuration).

**3. Run.**

```bash
npm install
npm run dev        # then open http://127.0.0.1:3000
```

Press **Sign in with Snowflake** and sign in with your user. The app asks only
for `GPT_LIVE_SHOWCASE_ROLE`, and only the browser you signed in with can use
the sign-in. Then press **Start call**, allow the microphone,
and try both kinds of question.
The sample data is set on Friday 16 January 2026, so that is "today" for the
assistant.

> **Keep this sign-in.** AI Gateway accepts the Snowflake OAuth token this
> sign-in gives the app. It doesn't currently accept a session from a driver's
> `externalbrowser` (SSO) login, so don't swap the sign-in for that.

- Precomputed, answered at once from today's briefing: "Who am I seeing today?",
  "What's the focus for my meeting with Dr. Vantreese?", "What objections has he
  raised?"
- On demand, looked up by the Cortex Agent: "How does his December ZEVRANTA
  compare with his best month?", "What happened on my last visit with him?"

Each answer from the Cortex Agent gets a Snowflake row in the transcript; no row
means `openai-gpt-live-1` answered on its own. The server log shows each lookup as
`Delegation started` and `Delegation answered`.

Press **M** to mute and unmute. Mute only turns your microphone off: the call
stays connected. **End call** closes the session; **Start call** opens a new
one. You can talk any time, even while the assistant is speaking, to interrupt
it. Headphones work best: on speakers, the assistant can hear itself and stop
mid-sentence.

Your Snowflake token stays in the server's memory: it is never written to disk
and never reaches the browser. Stopping the server makes the app forget it; the
tokens expire on their own (within minutes, and within a day for the refresh
token). The server only answers on `127.0.0.1` and `localhost`, so other web
pages can't use it, and it refuses to listen beyond this machine.

## Configuration

Locally the server reads `.env` when it starts, so restart `npm run dev` after
changing it. Variables already exported in your shell win over `.env`. On SPCS,
the same names go in the service spec's `env:` block in
[`spcs/02_service.sql`](spcs/02_service.sql).

| Setting | Default | What it is |
|---|---|---|
| `SNOWFLAKE_ACCOUNT_URL` | **required locally** | Your account URL. On SPCS it comes from the injected `SNOWFLAKE_HOST`. |
| `SNOWFLAKE_OAUTH_CLIENT_ID` | **required locally** | The client ID of the OAuth integration from step 1. Not a secret. Not used on SPCS. |
| `AI_GATEWAY_NAME` | `snowflake` | Your account's AI Gateway, which gives the app access to models. It sets up `openai-gpt-live-1` sessions. Change it only if your account team gives you another name. |
| `GPT_LIVE_MODEL` | `openai-gpt-live-1` | The voice model. |
| `GPT_LIVE_VOICE` | `marin` | The assistant's voice, for example `marin`, `cedar`, `alloy`, `coral` or `verse`. It is fixed once the call starts. |
| `AGENT_DATABASE` / `AGENT_SCHEMA` / `AGENT_NAME` | `GPT_LIVE_SHOWCASE` / `FIELD_SALES` / `FIELD_SALES_AGENT` | The Cortex Agent that answers lookups. |
| `AGENT_TIMEOUT_MS` | `120000` | How long one lookup may take, in milliseconds. |
| `BRIEF_VIEW` | `GPT_LIVE_SHOWCASE.FIELD_SALES.DAY_BRIEF` | The view with today's precomputed briefing, read when a call starts. `off` turns it off. |
| `SNOWFLAKE_WAREHOUSE` | `GPT_LIVE_SHOWCASE_WH` | The warehouse that reads the briefing. |
| `SNOWFLAKE_ROLE` | `GPT_LIVE_SHOWCASE_ROLE` | The role the sign-in asks for, which also reads the briefing. `off` uses your default role. |
| `LISTEN_PORT` | `3000` | The local port. If you change it, change the OAuth integration's redirect URI to match: `ALTER SECURITY INTEGRATION GPT_LIVE_SHOWCASE_OAUTH SET OAUTH_REDIRECT_URI = 'http://127.0.0.1:<port>/oauth/callback';` |
| `LISTEN_HOST` | `127.0.0.1` locally, `0.0.0.0` on SPCS | The address the server listens on. Locally it must be `127.0.0.1`, `localhost` or `::1`, or the server won't start: it holds your Snowflake sign-in. |

### Use your own data

1. Point `AGENT_DATABASE`, `AGENT_SCHEMA` and `AGENT_NAME` at your agent. The
   agent runs with `GPT_LIVE_SHOWCASE_ROLE`'s rights, so grant that role `USAGE` on the
   agent and its warehouse, and `SELECT` and `REFERENCES` on the semantic view
   and tables it uses.
2. Edit [`server/src/persona.ts`](server/src/persona.ts). It tells `openai-gpt-live-1` who
   it is talking to and what the lookup covers (the `<backend-tools>` list), and
   that decides which questions it hands to the agent. On SPCS, a change here
   needs a new image (see [Deploy to SPCS](#deploy-to-spcs-optional)).
3. Change the precomputed insights: edit the `DAY_BRIEF` view in
   `snowflake/setup.sql` (one row, one column `BRIEF`), or point `BRIEF_VIEW` at
   your own view and grant `GPT_LIVE_SHOWCASE_ROLE` `SELECT` on it. The server caches the
   briefing for 10 minutes; restart `npm run dev` to see an edit at once.

## Enable openai-gpt-live-1 on your account

The `openai-gpt-live-1` model is in Private Preview. Your Snowflake account
team arranges steps 1 and 2. You run steps 3 and 4 as ACCOUNTADMIN.

1. **Preview terms.** Your organization accepts the Private Preview terms.
2. **Model access.** Snowflake enables `openai-gpt-live-1` for your account.
3. **Check that the model is listed**, and refresh the list if it isn't:
   ```sql
   SHOW MODELS LIKE '%GPT-LIVE%' IN SCHEMA SNOWFLAKE.MODELS;   -- should list OPENAI-GPT-LIVE-1
   ```
   If it's listed, skip to step 4. If not, run this, then run the check again, or
   wait up to 24 hours for the list to refresh on its own:
   ```sql
   USE WAREHOUSE <any_warehouse>;   -- the refresh needs one
   CALL SNOWFLAKE.MODELS.CORTEX_BASE_MODELS_REFRESH();
   ```
   Voice calls fail with a 401 until the model is listed.
4. **Cross-region inference.** `openai-gpt-live-1` runs in Azure East US 2, and the
   models the agent uses may not be offered in your region either. Unless your
   account is in Azure East US 2, check the
   [cross-region inference](https://docs.snowflake.com/en/user-guide/snowflake-cortex/cross-region-inference) setting:
   ```sql
   SHOW PARAMETERS LIKE 'CORTEX_ENABLED_CROSS_REGION' IN ACCOUNT;
   ```
   If it shows `DISABLED`, or a region group that doesn't include Azure US (for
   example `AWS_US`), `openai-gpt-live-1` can't be reached. `ANY_REGION` fixes that, but it
   means requests for every model may be processed in a region other than your
   account's. Check your data-sovereignty requirements before you change it.
   ```sql
   ALTER ACCOUNT SET CORTEX_ENABLED_CROSS_REGION = 'ANY_REGION';
   ```

No model grant is needed by default. Model access uses
[role-based access control](https://docs.snowflake.com/en/user-guide/snowflake-cortex/aisql-privileges-and-access#control-model-access),
and by default every role can use every model: Snowflake grants the
`SNOWFLAKE."CORTEX-MODEL-ROLE-ALL"` application role to `SNOWFLAKE.PUBLIC`.
If your account limits model access, then once `setup.sql` has run, grant
the `openai-gpt-live-1` model role to `GPT_LIVE_SHOWCASE_ROLE`:

```sql
GRANT APPLICATION ROLE SNOWFLAKE."CORTEX-MODEL-ROLE-OPENAI-GPT-LIVE-1" TO ROLE GPT_LIVE_SHOWCASE_ROLE;
```

The agent also needs one model it may use: if lookups then fail with "None of the
preferred models are authorized", grant one of the models it lists the same way.

## Deploy to SPCS (optional)

This runs the same app as one container in your account, Snowpark Container
Services (SPCS), with no secrets: the app uses the token Snowflake mounts in
the container and calls only your account host. Everyone opens it at one URL
after signing in to Snowflake.

**Before you start**

- [Quick start](#quick-start-local) step 1 is done: `setup.sql` has run. You
  don't need `.env` or the sign-in for SPCS.
- Docker with `buildx` is installed and running.
- A Snowflake CLI connection (`snow connection add`) whose user can use both
  **ACCOUNTADMIN** and **GPT_LIVE_SHOWCASE_ROLE**. Each step below picks its
  role with `--role`, so any sign-in method works, for example SSO or a key pair.
- Run the commands below from this folder (`gpt-live-agents-showcase`): step 2
  builds the image from it.

**1. Create the compute pool, grants and app-user role**, as ACCOUNTADMIN:

```bash
snow sql -c <your-connection> --role ACCOUNTADMIN -f spcs/01_spcs_objects.sql
```

**2. Build and push the image.** The script creates the image repository and
runs as `GPT_LIVE_SHOWCASE_ROLE` by itself. The last argument is a version tag
of your choice. The script's last line should be `Pushed …/gpt-live-agents-showcase:v1`.

```bash
spcs/push-image.sh <your-connection> v1
```

**3. Create the service**, with the same tag, as `GPT_LIVE_SHOWCASE_ROLE`:

```bash
snow sql -c <your-connection> --role GPT_LIVE_SHOWCASE_ROLE -f spcs/02_service.sql -D image_tag=v1
```

**4. Let people in.** As ACCOUNTADMIN, for each person who should use the app:

```sql
GRANT ROLE GPT_LIVE_SHOWCASE_USER TO USER <app_user>;
```

Also take back the two rights `GPT_LIVE_SHOWCASE_ROLE` needed only to create
the service. The app runs with that role's rights, so without them it can't
create other services. Pushing a new image and `ALTER SERVICE` still work. To
create the service again from scratch, run step 1 again first.

```sql
REVOKE CREATE SERVICE, CREATE IMAGE REPOSITORY ON SCHEMA GPT_LIVE_SHOWCASE.FIELD_SALES
  FROM ROLE GPT_LIVE_SHOWCASE_ROLE;
```

**5. Open the app.** The service takes a minute or two to start. Run these as
`GPT_LIVE_SHOWCASE_ROLE` or ACCOUNTADMIN. When the first shows
`"status":"READY"`, open the `ingress_url` from the second in a browser and
sign in to Snowflake:

```sql
SELECT SYSTEM$GET_SERVICE_STATUS('GPT_LIVE_SHOWCASE.FIELD_SALES.GPT_LIVE_SHOWCASE_SERVICE');
SHOW ENDPOINTS IN SERVICE GPT_LIVE_SHOWCASE.FIELD_SALES.GPT_LIVE_SHOWCASE_SERVICE;
```

**Stop and start it.** The service runs, and costs compute, until you suspend
it: the compute pool doesn't suspend on its own while the service runs. When
you're done, as ACCOUNTADMIN:

```sql
ALTER SERVICE GPT_LIVE_SHOWCASE.FIELD_SALES.GPT_LIVE_SHOWCASE_SERVICE SUSPEND;
ALTER COMPUTE POOL GPT_LIVE_SHOWCASE_POOL SUSPEND;
-- and to start again:
ALTER COMPUTE POOL GPT_LIVE_SHOWCASE_POOL RESUME;
ALTER SERVICE GPT_LIVE_SHOWCASE.FIELD_SALES.GPT_LIVE_SHOWCASE_SERVICE RESUME;
```

**Ship a new version or change a setting.** Re-running `02_service.sql` does
not update a service that already exists. Instead:

1. Push the new image under a new tag: `spcs/push-image.sh <your-connection> v2`.
   Always use a new tag: reusing one can keep the old image running.
2. Copy the specification from `spcs/02_service.sql` (between the `$$` marks).
   Replace `<% image_tag %>` with the new tag, and change any setting in its
   `env:` block.
3. As `GPT_LIVE_SHOWCASE_ROLE`, apply it:
   `ALTER SERVICE GPT_LIVE_SHOWCASE.FIELD_SALES.GPT_LIVE_SHOWCASE_SERVICE FROM SPECIFICATION $$ … $$;`

**Whose rights.** Every call runs as the service's owner role,
`GPT_LIVE_SHOWCASE_ROLE`; `GPT_LIVE_SHOWCASE_USER` can only open the page. So
every app user can ask, through the agent, about anything that role can read:
grant it only data that all app users may see.

## How it works

1. **You press Start call.** The browser asks the app server to start a voice session.
2. **The server reads today's briefing** from the `DAY_BRIEF` view: the
   precomputed insights for each visit. It is cached for 10 minutes.
3. **The server asks your AI Gateway to open the session** with
   `openai-gpt-live-1`, with the briefing in its instructions. Your token stays
   on the server.
4. **You and `openai-gpt-live-1` talk directly.** Audio goes straight between
   your browser and `openai-gpt-live-1`, at the model provider. It doesn't pass
   through the app server. Questions the briefing covers are answered at once.
5. **`openai-gpt-live-1` asks for data** for anything else (on-demand insights): it tells
   the browser, which sends the conversation so far to the server.
6. **The server asks the Cortex Agent**, which answers from the semantic view.
7. **`openai-gpt-live-1` says the answer.** It goes back through the browser to
   `openai-gpt-live-1`, which says it in its own words.

If the briefing can't be read, the call starts without it, and every data
question goes to the agent.

## Code map

| File | What it does |
|---|---|
| `snowflake/setup.sql` | Everything in Snowflake: role, warehouse, data, semantic view, agent, briefing view, grants |
| `server/src/liveSession.ts` | Asks the AI Gateway for an `openai-gpt-live-1` session |
| `server/src/brief.ts` | Reads today's briefing from the `DAY_BRIEF` view |
| `server/src/agent.ts`, `delegation.ts` | Runs the Cortex Agent and turns its answer into speech |
| `server/src/persona.ts` | `openai-gpt-live-1`'s instructions: when to look things up, how to speak |
| `server/src/oauth.ts` | Sign-in with Snowflake (OAuth with PKCE); keeps the token in memory |
| `server/src/auth.ts`, `config.ts`, `errors.ts` | SPCS token, settings, error text |
| `web/app.js` | The call: microphone, WebRTC, mute, lookups |
| `web/view.js`, `callStatus.js` | Transcript, Snowflake rows and status line |
| `web/turns.js`, `turnGate.js`, `speechGate.js` | Keep turns in spoken order; match each lookup to its question; hold an answer while you are talking |
| `spcs/` | Compute pool, image repository, service |

`npm run check` runs the type check and the tests.

## Troubleshooting

The page shows a short message. The full error is in the server log: the
terminal running `npm run dev`, or on SPCS, as `GPT_LIVE_SHOWCASE_ROLE`,
`SELECT SYSTEM$GET_SERVICE_LOGS('GPT_LIVE_SHOWCASE.FIELD_SALES.GPT_LIVE_SHOWCASE_SERVICE', 0, 'app', 200);`.

| Symptom | Likely cause |
|---|---|
| "The voice service didn't start the call (401)" | `openai-gpt-live-1` isn't enabled for the account yet, or `GPT_LIVE_SHOWCASE_ROLE` can't use it: see [Enable openai-gpt-live-1 on your account](#enable-openai-gpt-live-1-on-your-account). |
| Sign-in: Snowflake shows an error about the redirect URI | The app's address doesn't match the OAuth integration's `OAUTH_REDIRECT_URI`. Open the page at `http://127.0.0.1:3000`, or change the integration's redirect URI if you changed `LISTEN_PORT`. |
| Sign-in: Snowflake says the role isn't granted or the scope is invalid | Your user doesn't have `GPT_LIVE_SHOWCASE_ROLE` yet (Quick start step 1). |
| "Your Snowflake sign-in has ended" | The sign-in lasts up to a day, and the app forgets it when you restart the server. Reload the page and sign in again. |
| "… (404)" | No `openai-gpt-live-1` route on that gateway. Check `AI_GATEWAY_NAME`. |
| "… (400)" or "… (500)" now and then | The voice service refused that one session. Press **Try again**. |
| Calls work, but lookups fail with 403 or 404 | The role lacks a grant from `setup.sql`, or `AGENT_*` don't name the agent. |
| Lookups fail: "None of the preferred models are authorized or available in your region" | Turn on [cross-region inference](https://docs.snowflake.com/en/user-guide/snowflake-cortex/cross-region-inference) ([Enable openai-gpt-live-1](#enable-openai-gpt-live-1-on-your-account) step 4). If your account limits model access, see the model note in the same section. |
| The page shows 421 | Open the page at `127.0.0.1` or `localhost` (for example `http://127.0.0.1:3000`). Other host names are refused on purpose. |
| SPCS: the status stays `PENDING` | The container is still starting. If it lasts more than five minutes, read the service log (above). |
| SPCS: Snowflake signs you in, then refuses the page | Your user doesn't have `GPT_LIVE_SHOWCASE_USER` yet (step 4). |
| The assistant answers from memory | `openai-gpt-live-1` decides when to look things up. Name a doctor or product, or adjust `persona.ts`. |
| The assistant cuts itself off | It hears itself through your speakers. Use headphones, or turn the volume down. |

## Clean up

As ACCOUNTADMIN:

```sql
DROP SERVICE IF EXISTS GPT_LIVE_SHOWCASE.FIELD_SALES.GPT_LIVE_SHOWCASE_SERVICE;
ALTER COMPUTE POOL IF EXISTS GPT_LIVE_SHOWCASE_POOL STOP ALL;
DROP COMPUTE POOL IF EXISTS GPT_LIVE_SHOWCASE_POOL;
DROP DATABASE IF EXISTS GPT_LIVE_SHOWCASE;
DROP WAREHOUSE IF EXISTS GPT_LIVE_SHOWCASE_WH;
DROP ROLE IF EXISTS GPT_LIVE_SHOWCASE_USER;
DROP ROLE IF EXISTS GPT_LIVE_SHOWCASE_ROLE;
DROP SECURITY INTEGRATION IF EXISTS GPT_LIVE_SHOWCASE_OAUTH;
```

## Licence

Apache 2.0. See [LICENSE](LICENSE). This is sample code, not a supported Snowflake
product. See also [SECURITY.md](SECURITY.md), [CONTRIBUTING.md](CONTRIBUTING.md)
and [CODE_OF_CONDUCT.md](CODE_OF_CONDUCT.md).
