// What the call is doing, for the orb and the status line.
//
// Who is talking wins: the user talking over the assistant is the moment they
// most need to see they are heard. Then what the call is busy with. Anything
// else still going on is added after a dot, so it is never hidden, e.g.
// "Assistant speaking · looking it up" or "You're speaking · answer ready".
//
// The hint under it says what the user can do now, e.g. "Talk any time to
// interrupt" while the assistant speaks.

/**
 * @param {{
 *   connecting?: boolean,
 *   muted?: boolean,
 *   userSpeaking?: boolean,
 *   assistantSpeaking?: boolean,
 *   lookups?: number,       // delegations not yet answered
 *   heldAnswer?: boolean,   // an answer waits for the user to pause
 * }} s
 * @returns {{ state: string, text: string, hint: string }}
 */
export function callStatus(s) {
  if (s.connecting) return { state: "connecting", text: "Connecting…", hint: "This takes a few seconds." };

  const lookups = s.lookups ?? 0;
  const working = lookups === 0 ? "" : lookups === 1 ? "looking it up" : `${lookups} lookups running`;

  let state;
  let text;
  if (s.userSpeaking && !s.muted) {
    state = "hearing";
    text = "You're speaking";
  } else if (s.assistantSpeaking) {
    state = "speaking";
    text = "Assistant speaking";
  } else if (working) {
    state = "thinking";
    text = `${working[0].toUpperCase()}${working.slice(1)} in Snowflake…`;
  } else if (s.muted) {
    state = "muted";
    text = "Muted";
  } else {
    state = "listening";
    text = "Listening, your turn";
  }

  const extras = [];
  if (working && state !== "thinking") extras.push(working);
  if (s.heldAnswer) extras.push("answer ready");
  if (s.muted && state !== "muted") extras.push("muted");
  // Muted, "keep talking" or "talk to interrupt" would not be heard.
  const hint = s.muted && state !== "muted" ? "Unmute to talk." : HINTS[state](s);
  return { state, text: [text, ...extras].join(" · "), hint };
}

/** What the user can do in each state. */
const HINTS = {
  hearing: (s) => (s.heldAnswer ? "The answer plays when you pause." : "Pause when you're done."),
  speaking: () => "Talk any time to interrupt.",
  thinking: () => "You can keep talking while it looks.",
  muted: () => "Press Unmute or M to talk again.",
  listening: () => "Ask about your meetings, doctors or prescriptions.",
};

/** A start failure in words the user can act on. The full error is in the console. */
export function startError(error) {
  if (error?.name === "NotAllowedError") return "The microphone is blocked. Allow it in the address bar, then start again.";
  if (error?.name === "NotFoundError") return "No microphone found. Plug one in, then start again.";
  if (error?.name === "NotReadableError") return "The microphone is in use by another app. Close it, then start again.";
  const message = String(error?.message ?? error);
  // fetch's network failure: a TypeError with one of these messages (Chrome, Safari, Firefox).
  // Other TypeErrors are bugs, and keep their own message.
  if (error?.name === "TypeError" && /failed to fetch|load failed|networkerror/i.test(message)) {
    return "Can't reach the app server. Check that it is still running, then try again.";
  }
  // Matches the wording of publicMessage() in server/src/index.ts.
  if (/failed \(429\)/.test(message)) return "Too many calls started in the last minute. Wait a moment, then start again.";
  const status = message.match(/session create failed \((\d{3})\)/i)?.[1];
  if (status) return `The voice service didn't start the call (${status}). Try again. Details are in the server logs.`;
  if (/failed \(401\)/.test(message)) return "Your Snowflake sign-in has ended. Reload the page and sign in again.";
  return `${message.replace(/[.\s]*$/, "")}. Try again.`;
}

/** 0:07, 1:23, 12:05 */
export function formatDuration(ms) {
  const total = Math.max(0, Math.floor(ms / 1000));
  return `${Math.floor(total / 60)}:${String(total % 60).padStart(2, "0")}`;
}
