// Holds spoken answers while the user is talking.
//
// session.commentary.append is spoken straight away. If it lands mid-sentence,
// openai-gpt-live-1 answers the commentary instead of hearing (and delegating) what the
// user is saying. So commentary waits until the user's turn has closed.
// Anything sent after a held event queues behind it, to keep the order the
// model sees the same as the order it was produced in.

const SPOKEN = "session.commentary.append";

export class SpeechGate {
  /**
   * @param {(event: object) => void} send       puts one event on the data channel
   * @param {() => boolean} userSpeaking         true while a user turn is open
   */
  constructor(send, userSpeaking) {
    this.sendNow = send;
    this.userSpeaking = userSpeaking;
    this.queue = [];
  }

  /** How many events are waiting. */
  get held() {
    return this.queue.length;
  }

  send(event) {
    this.queue.push(event);
    this.release();
  }

  /** Send everything that may go now. Call whenever a user turn closes. */
  release() {
    while (this.queue.length > 0) {
      if (this.queue[0].type === SPOKEN && this.userSpeaking()) return;
      this.sendNow(this.queue.shift());
    }
  }

  /** Drop everything, e.g. on hang-up. */
  clear() {
    this.queue = [];
  }
}
