// The conversation as a list of closed turns, in the order they were spoken.
//
// openai-gpt-live-1 is full duplex, so both sides can be talking at once, and each side's
// turn closes on its own pause. A turn that began first can therefore close
// second: the user starts a sentence, the assistant starts answering, and the
// assistant's shorter reply closes first. Recording turns as they close would
// put them out of order, and the agent would read the conversation wrong.
// So each turn keeps when it began, and is inserted by that.

/**
 * Add a closed turn, keeping the list ordered by when each turn began, and at
 * most `max` long. Returns the list.
 *
 * @param {{role: string, text: string, began: number, at: number}[]} turns
 * @param {{role: string, text: string, began: number, at: number}} turn
 * @param {number} max
 */
export function addTurn(turns, turn, max = Infinity) {
  let i = turns.length;
  while (i > 0 && turns[i - 1].began > turn.began) i -= 1;
  turns.splice(i, 0, turn);
  if (turns.length > max) turns.splice(0, turns.length - max);
  return turns;
}

/**
 * Whether a delegation has to wait for a user turn that hasn't closed yet,
 * rather than take the newest one. It waits while the user is still being
 * transcribed, and when the newest user turn is old and the assistant has
 * spoken since: a "thanks" from a while ago is not the question.
 *
 * @param {{role: string, at: number}[]} turns
 * @param {{ transcribing: boolean, now: number, staleMs: number }} opts
 */
export function needsNewTurn(turns, { transcribing, now, staleMs }) {
  if (transcribing) return true;
  let lastUser;
  for (let i = turns.length - 1; i >= 0 && !lastUser; i -= 1) if (turns[i].role === "user") lastUser = turns[i];
  return turns.at(-1)?.role === "assistant" && lastUser !== undefined && now - lastUser.at > staleMs;
}

/**
 * What the user asked: their newest run of turns, joined, since a pause can
 * split one question over several. The assistant's turns after it ("Let me
 * check that") are skipped: they began after the question, so they sort after
 * it. The server drops them from the agent's messages the same way.
 */
export function lastRequest(turns) {
  let i = turns.length - 1;
  while (i >= 0 && turns[i].role !== "user") i -= 1;
  const asked = [];
  for (; i >= 0 && turns[i].role === "user"; i -= 1) asked.unshift(turns[i].text);
  return asked.join(" ");
}
