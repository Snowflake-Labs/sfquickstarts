// The call's on-screen pieces: the transcript with its Snowflake rows, and the
// audio level meter that drives the orb. Text only ever goes in through
// textContent: transcripts and agent answers are untrusted.

const STEPS = [
  ["started", "Understanding the question"],
  ["planning", "Planning"],
  ["querying_data", "Querying Snowflake"],
  ["writing_answer", "Writing the answer"],
];
const STEP_LABEL = new Map(STEPS);
/** How long a side counts as audible after its last loud moment. */
const AUDIBLE_MS = 400;
/**
 * Lines from one side this close together are one bubble: longer than a breath
 * between sentences, shorter than a lookup.
 */
const MERGE_GAP_MS = 4000;

/** Copy text, and say on the button whether it worked. */
function copyFrom(button, text) {
  const label = button.textContent;
  const flash = (message) => {
    button.textContent = message;
    setTimeout(() => (button.textContent = label), 1500);
  };
  if (!navigator.clipboard) return flash("Can't copy here");
  navigator.clipboard.writeText(text).then(
    () => flash("Copied"),
    () => flash("Can't copy here"),
  );
}

function el(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}

export class Transcript {
  /**
   * @param {HTMLElement} root  the scrolling list; its `.empty` child is the empty-state hint
   * @param {HTMLButtonElement} jump  shown when new lines arrive while scrolled up
   * @param {HTMLButtonElement} copy  copies the transcript as text; shown once there is one
   */
  constructor(root, jump, copy) {
    this.root = root;
    this.jump = jump;
    this.copy = copy;
    copy.addEventListener("click", () => copyFrom(copy, this.asText()));
    this.empty = root.querySelector(".empty");
    this.open = { user: null, assistant: null };
    root.addEventListener("scroll", () => {
      if (this.atBottom()) this.jump.hidden = true;
    });
    jump.addEventListener("click", () => {
      root.scrollTo({ top: root.scrollHeight, behavior: "smooth" });
      jump.hidden = true;
    });
  }

  atBottom() {
    return this.root.scrollHeight - this.root.scrollTop - this.root.clientHeight < 48;
  }

  /** Run a change, following it if the view was at the bottom, else offering to. */
  update(change) {
    const pinned = this.atBottom();
    const result = change();
    const hasLines = this.root.children.length > 1;
    if (this.empty) this.empty.hidden = hasLines;
    this.copy.hidden = !hasLines;
    if (pinned) this.root.scrollTop = this.root.scrollHeight;
    else this.jump.hidden = false;
    return result;
  }

  /** The conversation as plain text: both sides, each lookup with its answer, and notes. */
  asText() {
    const lines = [];
    for (const node of this.root.children) {
      if (node === this.empty) continue;
      if (node.classList.contains("said")) {
        lines.push(`${node.classList.contains("user") ? "You" : "Assistant"}: ${node.textContent}`);
      } else if (node.classList.contains("lookup")) {
        const question = node.querySelector(".lookup-q")?.textContent ?? "";
        const answer = node.querySelector(".lookup-a");
        lines.push(`[Snowflake lookup] ${question}${answer && !answer.hidden ? ` → ${answer.textContent}` : ""}`);
      } else if (node.classList.contains("note")) {
        lines.push(`(${node.textContent})`);
      }
    }
    return lines.join("\n");
  }

  /** Jump to the newest line, e.g. when the transcript is shown again. */
  toLatest() {
    this.root.scrollTop = this.root.scrollHeight;
    this.jump.hidden = true;
  }

  clear() {
    this.update(() => {
      [...this.root.children].forEach((child) => child !== this.empty && child.remove());
      this.open = { user: null, assistant: null };
    });
    this.jump.hidden = true;
  }

  /**
   * The bubble a new turn of `side` goes in. A pause closes a turn, so one
   * answer arrives as several turns, often one per sentence. Carry on the
   * previous bubble when it is the same side, nothing came between, and it
   * was still going a moment ago, or it stopped mid-sentence. A long gap,
   * such as "Let me check" and then the answer after a lookup, starts a new
   * bubble.
   */
  openLine(side) {
    // A note ("Connection unstable…") is not a turn: look past it.
    let last = this.root.lastElementChild;
    while (last?.classList.contains("note")) last = last.previousElementSibling;
    if (last?.classList.contains("said") && last.classList.contains(side)) {
      const recent = Date.now() - Number(last.dataset.at ?? 0) < MERGE_GAP_MS;
      const unfinished = !/[.?!…]["”’)]?$/.test(last.textContent.trim());
      if (recent || unfinished) return { node: last, base: last.textContent };
    }
    const node = el("p", `said ${side}`);
    this.root.append(node);
    return { node, base: "" };
  }

  /** What one side is still saying, shown dimmed until its turn closes. */
  partial(side, text) {
    if (!text.trim()) return;
    this.update(() => {
      this.open[side] ??= this.openLine(side);
      const { node, base } = this.open[side];
      node.textContent = base ? `${base} ${text.trim()}` : text.trim();
      node.classList.add("partial");
      node.dataset.at = String(Date.now());
    });
  }

  /** The side's turn closed: keep its words, or undo the line if nothing was said. */
  commit(side, text) {
    const line = this.open[side];
    this.open[side] = null;
    this.update(() => {
      if (!text) {
        if (!line) return;
        if (line.base) line.node.textContent = line.base;
        else line.node.remove();
        line.node.classList.remove("partial");
        return;
      }
      const { node, base } = line ?? this.openLine(side);
      node.textContent = base ? `${base} ${text}` : text;
      node.classList.remove("partial");
      node.dataset.at = String(Date.now());
    });
  }

  /** A quiet line for things that happened to the call, not things said. */
  note(text) {
    this.update(() => this.root.append(el("p", "note", text)));
  }

  /**
   * One delegation, where in the conversation it happened: a single line,
   * "Snowflake → question · step · time", that opens to the steps and the
   * agent's full answer. Folded by default, so the conversation stays readable.
   */
  lookup() {
    const card = el("details", "lookup");
    card.dataset.status = "waiting";

    const row = el("summary", "lookup-row");
    const icon = el("span", "lookup-icon");
    icon.setAttribute("aria-hidden", "true");
    const title = el("span", "lookup-title", "Snowflake");
    const question = el("span", "lookup-q", "waiting for your question…");
    const stepLabel = el("span", "lookup-step");
    const meta = el("span", "lookup-meta");
    const chevron = el("span", "lookup-chevron");
    chevron.setAttribute("aria-hidden", "true");
    row.append(icon, title, el("span", "lookup-sep", "→"), question, stepLabel, meta, chevron);

    const body = el("div", "lookup-body");
    const steps = el("ol", "lookup-steps");
    const items = new Map(STEPS.map(([key, label]) => [key, steps.appendChild(el("li", "", label))]));
    const answer = el("p", "lookup-a");
    answer.hidden = true;
    body.append(steps, answer);
    card.append(row, body);
    this.update(() => this.root.append(card));

    let startedAt = 0;
    let current = null;
    const seconds = (digits) => `${((performance.now() - startedAt) / 1000).toFixed(digits)}s`;
    const showMeta = () => {
      stepLabel.textContent = startedAt ? (current ? STEP_LABEL.get(current) : "Starting") : "";
      meta.textContent = startedAt ? seconds(0) : "";
    };
    const markUpTo = (key, state) => {
      let before = true;
      for (const [k, li] of items) {
        if (k === key) {
          li.dataset.state = state;
          before = false;
        } else if (before) li.dataset.state = "done";
      }
    };
    const settle = (status, text) => {
      card.dataset.status = status;
      answer.textContent = text;
      answer.hidden = false;
    };

    return {
      question: (text) =>
        this.update(() => {
          question.textContent = text;
          question.title = text;
          card.dataset.status = "running";
          startedAt = performance.now();
          showMeta();
        }),
      step: (key) =>
        this.update(() => {
          if (!items.has(key)) return;
          current = key;
          markUpTo(key, "current");
          showMeta();
        }),
      tick: () => {
        if (card.dataset.status === "running") showMeta();
      },
      done: (text) =>
        this.update(() => {
          for (const li of items.values()) li.dataset.state = "done";
          stepLabel.textContent = "";
          meta.textContent = startedAt ? seconds(1) : "";
          settle("done", text);
        }),
      /** `noQuestion`: it failed because no question was heard, not for another reason. */
      fail: (text, { noQuestion = false } = {}) =>
        this.update(() => {
          if (current) markUpTo(current, "failed");
          title.textContent = "Lookup failed";
          stepLabel.textContent = "";
          if (!startedAt) question.textContent = noQuestion ? "no question heard" : "before the question was heard";
          meta.textContent = startedAt ? seconds(1) : "";
          settle("failed", text);
        }),
      get settled() {
        return card.dataset.status === "done" || card.dataset.status === "failed";
      },
      get answered() {
        return card.dataset.status === "done";
      },
    };
  }
}

/**
 * Loudness of the mic and of the assistant, 0 to 1, as CSS variables
 * (--mic, --out) on <body>, plus whether each is audible right now. Optional:
 * the call works without it.
 */
export class LevelMeter {
  constructor(onActivity) {
    this.onActivity = onActivity;
    this.ctx = new AudioContext();
    this.meters = new Map();
    this.frame = 0;
  }

  attach(name, stream) {
    if (this.meters.has(name) || this.ctx.state === "closed") return;
    const analyser = this.ctx.createAnalyser();
    analyser.fftSize = 512;
    this.ctx.createMediaStreamSource(stream).connect(analyser);
    this.meters.set(name, { analyser, data: new Float32Array(analyser.fftSize), level: 0, loudAt: 0, active: false });
    void this.ctx.resume();
    if (!this.frame) this.loop();
  }

  /**
   * Whether that side was audible a moment ago. Worked out now rather than
   * read from the last animation frame: frames stop in a background tab, and
   * a stale "speaking" would stick.
   */
  active(name) {
    const m = this.meters.get(name);
    return m !== undefined && performance.now() - m.loudAt < AUDIBLE_MS;
  }

  loop = () => {
    const now = performance.now();
    let changed = false;
    for (const [name, m] of this.meters) {
      m.analyser.getFloatTimeDomainData(m.data);
      let sum = 0;
      for (const v of m.data) sum += v * v;
      const level = Math.min(1, Math.sqrt(sum / m.data.length) * 5);
      // Fast attack, slow release, so the orb doesn't flicker between syllables.
      m.level = level > m.level ? level : m.level * 0.85 + level * 0.15;
      if (level > 0.06) m.loudAt = now;
      const active = now - m.loudAt < AUDIBLE_MS;
      if (active !== m.active) {
        m.active = active;
        changed = true;
      }
      document.body.style.setProperty(`--${name}`, m.level.toFixed(3));
    }
    if (changed) this.onActivity();
    this.frame = requestAnimationFrame(this.loop);
  };

  close() {
    cancelAnimationFrame(this.frame);
    this.frame = 0;
    for (const name of this.meters.keys()) document.body.style.removeProperty(`--${name}`);
    this.meters.clear();
    void this.ctx.close().catch(() => {});
  }
}
