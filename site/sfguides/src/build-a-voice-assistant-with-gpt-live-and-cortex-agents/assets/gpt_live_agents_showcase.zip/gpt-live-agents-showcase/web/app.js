// Browser side of the showcase: a voice call, with no typing.
//
// The call bar has the orb, a status line ("You're speaking", "Looking it up
// in Snowflake…", "Listening, your turn"), a timer, mute and end. Below it, a
// live transcript of both sides, with a row for each Snowflake lookup where
// it happened: the question it heard, its steps, and the answer.
//
// The server makes one call to the model provider: it creates the openai-gpt-live-1
// session and returns the SDP answer. From then on audio and the `oai-events`
// data channel run directly between this page and the provider.
//
// openai-gpt-live-1 has no tools. When it wants data it emits
// session.delegation.created, which carries only an id, with no question text.
// So this page keeps the transcript, sends it to /api/delegate, and forwards
// what comes back onto the data channel:
//   progress -> session.thinking.append    (quiet context, not spoken)
//   answer   -> session.commentary.append  (the model says it in its own words)

import { callStatus, formatDuration, startError } from "./callStatus.js";
import { SpeechGate } from "./speechGate.js";
import { TurnGate } from "./turnGate.js";
import { addTurn, lastRequest, needsNewTurn } from "./turns.js";
import { LevelMeter, Transcript } from "./view.js";

const EVENTS = {
  outputDelta: "session.output_transcript.delta",
  inputDelta: "session.input_transcript.delta",
  delegationCreated: "session.delegation.created",
  thinkingAppend: "session.thinking.append",
  commentaryAppend: "session.commentary.append",
};

// openai-gpt-live-1 has no turn-complete event, so a pause is the only turn boundary.
// 1.2 s: shorter splits a sentence at a thinking pause.
const TRANSCRIPT_IDLE_MS = 1200;
// While a delegation waits for its question, a shorter pause ends the turn.
// 600 ms, not less: gaps inside one transcription burst cut "How much did… Dr.
// Vantreese prescribe" in half, and only the first half would be looked up.
const DELEGATION_IDLE_MS = 600;
// A user turn this old, already answered, is not what a new delegation is about.
const STALE_TURN_MS = 6000;
// Transcription trails the audio: words said just before Mute arrive for a
// moment after it. Keep them; drop everything later (see inputDelta).
const MIC_OFF_GRACE_MS = 1500;
// Host candidates are ready at once; don't wait long for the rest.
const ICE_GATHER_MS = 3000;
// Turns sent with each delegation. The server windows again; this bounds memory.
const MAX_TURNS = 24;
const TRANSCRIPT_PREF = "showcase.transcript";

const $ = (id) => document.getElementById(id);
const ui = {
  call: $("call"),
  callLabel: $("call-label"),
  mute: $("mute"),
  muteLabel: $("mute-label"),
  status: $("status"),
  timer: $("timer"),
  hint: $("hint"),
  toggle: $("toggle-transcript"),
  panel: $("transcript-panel"),
  meta: $("meta"),
  audio: $("remote-audio"),
  announce: $("announce"),
};
const transcript = new Transcript($("transcript"), $("jump"), $("copy-transcript"));

let call = null;

let eventSeq = 0;
/** An id for an event sent to openai-gpt-live-1; its error, if any, names it in client_event_id. */
function nextEventId(kind) {
  eventSeq += 1;
  return `showcase_${kind}_${Date.now().toString(36)}_${eventSeq}`;
}

const PAGE_TITLE = document.title;

/**
 * One state for the whole page: drives the orb, the status line and the hint
 * under it (what the user can do now), the tab title and the buttons.
 */
function show(state, text, inCall, hint = "") {
  document.body.dataset.state = state;
  ui.status.textContent = text;
  ui.hint.textContent = hint;
  // A background tab still shows what the call is doing.
  document.title = inCall ? `${text} · Meeting prep` : PAGE_TITLE;
  ui.callLabel.textContent = inCall ? "End call" : state === "error" ? "Try again" : "Start call";
  ui.call.dataset.on = String(inCall);
  ui.mute.hidden = !inCall;
}

/**
 * Tell screen readers about the moments that matter. The status line changes
 * several times a second during a call, far too often to read out.
 */
function announce(text) {
  // Cleared first, so the same words twice in a row are still read twice.
  ui.announce.textContent = "";
  setTimeout(() => (ui.announce.textContent = text), 50);
}

/**
 * Wait for ICE candidates: there is one HTTP round trip and no channel to
 * trickle over. Capped at ICE_GATHER_MS; the offer then carries what is ready.
 */
function iceGatheringComplete(pc) {
  if (pc.iceGatheringState === "complete") return Promise.resolve();
  return new Promise((resolve) => {
    const done = () => {
      clearTimeout(timer);
      pc.removeEventListener("icegatheringstatechange", check);
      resolve();
    };
    const check = () => {
      if (pc.iceGatheringState === "complete") done();
    };
    const timer = setTimeout(done, ICE_GATHER_MS);
    pc.addEventListener("icegatheringstatechange", check);
  });
}

/** Read a text/event-stream response body, one parsed `data:` object at a time. */
async function* readEvents(response) {
  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const frames = buffer.split("\n\n");
    buffer = frames.pop();
    for (const frame of frames) {
      const data = frame
        .split("\n")
        .filter((l) => l.startsWith("data:"))
        .map((l) => l.slice(5).trim())
        .join("\n");
      if (data) yield JSON.parse(data);
    }
  }
}

class Call {
  constructor() {
    this.pc = null;
    this.channel = null;
    this.mic = null;
    this.meter = null;
    this.live = false;
    /** The connection dropped and may come back. */
    this.unstable = false;
    this.closed = false;
    this.muted = false;
    /** The mic is off (muted). */
    this.micOff = false;
    this.micOffAt = 0;
    /** Whether the transcript already says the voice service reported a problem. */
    this.reportedError = false;
    this.connectedAt = 0;
    this.turns = [];
    this.buffer = { user: "", assistant: "" };
    /** When each side's open turn began: closed turns are ordered by it. */
    this.began = { user: 0, assistant: 0 };
    /** Answers sent, by event_id, so a refused one can be replaced (see onError). */
    this.answers = new Map();
    this.timers = { user: null, assistant: null };
    /** Every delegation of this call: its card, and its request while one runs. */
    this.lookups = new Map();
    this.gate = new TurnGate();
    this.speech = new SpeechGate(
      (event) => this.send(event),
      () => Boolean(this.buffer.user.trim()),
    );
    this.ticker = setInterval(() => this.tick(), 500);
  }

  /** Lookups still waiting for their question or their answer. */
  get runningLookups() {
    let n = 0;
    for (const lookup of this.lookups.values()) if (!lookup.card.settled) n += 1;
    return n;
  }

  /** The mic is on unless muted. */
  updateMic() {
    const off = this.muted;
    if (off && !this.micOff) this.micOffAt = Date.now();
    this.micOff = off;
    this.mic?.getAudioTracks().forEach((track) => (track.enabled = !off));
  }

  /** Recompute what the page shows from the call's state. */
  render() {
    if (this.closed) return;
    if (this.unstable) return show("connecting", "Connection unstable, reconnecting…", true, "Hang on, or end the call and start again.");
    const { state, text, hint } = callStatus({
      connecting: !this.live,
      muted: this.muted,
      userSpeaking: Boolean(this.buffer.user.trim()) || (!this.micOff && Boolean(this.meter?.active("mic"))),
      assistantSpeaking: Boolean(this.buffer.assistant.trim()) || Boolean(this.meter?.active("out")),
      lookups: this.runningLookups,
      heldAnswer: this.speech.held > 0,
    });
    show(state, text, true, hint);
  }

  tick() {
    const now = performance.now();
    if (this.connectedAt) ui.timer.textContent = formatDuration(now - this.connectedAt);
    for (const lookup of this.lookups.values()) lookup.card.tick();
  }

  async start() {
    show("connecting", "Asking for the microphone…", true, "Allow it when the browser asks.");
    transcript.clear();
    ui.timer.textContent = "";
    // Before the first await, while still inside the click: Safari leaves an
    // AudioContext made later suspended, and the orb would never move.
    try {
      this.meter = new LevelMeter(() => this.render());
    } catch (error) {
      console.warn("No audio level meter", error);
      this.meter = null;
    }
    this.mic = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true } });
    if (this.closed) return this.mic.getTracks().forEach((track) => track.stop());
    for (const track of this.mic.getAudioTracks()) {
      // Unplugged, or permission revoked, mid-call: the call would go on in silence.
      track.onended = () => this.fail("The microphone was disconnected. Check it, then start again.");
    }
    // Mute may have been pressed during the microphone prompt.
    this.updateMic();
    this.meter?.attach("mic", this.mic);
    show("connecting", "Connecting…", true, "This takes a few seconds.");

    this.pc = new RTCPeerConnection();
    this.pc.ontrack = (event) => {
      const stream = event.streams[0] ?? new MediaStream([event.track]);
      ui.audio.srcObject = stream;
      this.meter?.attach("out", stream);
    };
    this.pc.onconnectionstatechange = () => {
      if (this.closed) return;
      const state = this.pc?.connectionState;
      if (state === "connected") {
        if (!this.live) {
          this.live = true;
          this.connectedAt = performance.now();
          announce("Call connected.");
        } else if (this.unstable) {
          transcript.note("Connection back.");
        }
        this.unstable = false;
        this.render();
      }
      // "disconnected" can recover on its own; "failed" doesn't.
      if (state === "disconnected" && this.live) {
        this.unstable = true;
        transcript.note("Connection unstable…");
        this.render();
      }
      if (state === "failed") {
        this.fail(
          this.live
            ? "The call dropped. Check your connection and start again."
            : "Couldn't connect the call. Check your connection and try again.",
        );
      }
    };
    this.mic.getAudioTracks().forEach((track) => this.pc.addTrack(track, this.mic));
    this.attachChannel(this.pc.createDataChannel("oai-events"));
    this.pc.ondatachannel = (event) => this.attachChannel(event.channel);

    await this.pc.setLocalDescription(await this.pc.createOffer());
    await iceGatheringComplete(this.pc);
    if (this.closed) return;

    const response = await fetch("/api/session", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ sdp: this.pc.localDescription.sdp }),
    });
    const body = await response.json().catch(() => ({}));
    // Hung up while the session was being created: the peer is already closed,
    // so the provider sees no media and drops the session.
    if (this.closed) return;
    if (!response.ok) throw new Error(body.error || `Session create failed (${response.status})`);
    await this.pc.setRemoteDescription({ type: "answer", sdp: body.sdp });
    // Without a briefing (the view is missing or failed), every question goes to the agent.
    if (body.briefed) transcript.note("Today's briefing is loaded: questions it covers are answered instantly.");
  }

  setMuted(muted) {
    if (this.closed || muted === this.muted) return;
    this.muted = muted;
    this.updateMic();
    // What the user was saying closes on its own pause, as usual: its last
    // words may still be on their way (MIC_OFF_GRACE_MS).
    ui.mute.dataset.on = String(muted);
    ui.muteLabel.textContent = muted ? "Unmute" : "Mute";
    // Not a transcript line: the call bar shows it, and a line in the middle
    // of the assistant's answer would split it in two.
    announce(muted ? "Microphone muted." : "Microphone on.");
    this.render();
  }

  attachChannel(channel) {
    this.channel = channel;
    channel.onmessage = (message) => {
      if (this.closed) return;
      try {
        this.onProviderEvent(JSON.parse(message.data));
      } catch (error) {
        console.warn("Unparseable data channel frame", error);
      }
    };
    channel.onclose = () => {
      // The transcript is shared by every call; a closed one must not touch it.
      if (this.closed) return;
      this.flushAll();
      // Closed by the voice service, not by hanging up here (stop() sets closed first).
      if (this.live) {
        transcript.note("The voice service ended the call.");
        this.fail("The call ended on the voice service's side. Start again to continue.");
      }
    };
  }

  send(event) {
    if (this.channel?.readyState === "open") this.channel.send(JSON.stringify(event));
  }

  onProviderEvent(event) {
    switch (event.type) {
      // Both sides can be open at once: the model is full duplex, and its
      // reply often starts before the user's last words are transcribed.
      // Each side's turn closes on its own pause, never because the other
      // side spoke, so overlapping "Okay, thank you" / "You're welcome" stay
      // two whole lines instead of four fragments.
      case EVENTS.outputDelta:
        this.appendDelta("assistant", event.delta);
        break;
      case EVENTS.inputDelta:
        // With the mic off, openai-gpt-live-1 still transcribes the silence it gets,
        // into words nobody said. Drop them, except the tail of what was said
        // just before the mic went off, whose transcript is still arriving.
        if (this.micOff && Date.now() - this.micOffAt > MIC_OFF_GRACE_MS) break;
        this.appendDelta("user", event.delta);
        break;
      case EVENTS.delegationCreated: {
        const delegation = event.delegation ?? {};
        this.onDelegation(delegation).catch((error) => {
          // A bug here would otherwise leave the card spinning and the model waiting.
          console.error("Delegation handling failed", delegation.id, error);
          const card = this.lookups.get(delegation.id)?.card;
          if (this.closed || !card || card.settled) return;
          card.fail(String(error?.message ?? error));
          this.say(delegation.id, "The lookup failed. Tell the rep you couldn't reach the data right now.");
          this.render();
        });
        break;
      }
      case "error":
        this.onError(event);
        break;
      default:
        break;
    }
    this.render();
  }

  appendDelta(side, delta) {
    if (!delta) return;
    if (!this.buffer[side]) this.began[side] = Date.now();
    this.buffer[side] += delta;
    transcript.partial(side, this.buffer[side]);
    this.scheduleFlush(side);
  }

  scheduleFlush(side) {
    const idleMs = side === "user" && this.gate.pending ? DELEGATION_IDLE_MS : TRANSCRIPT_IDLE_MS;
    clearTimeout(this.timers[side]);
    this.timers[side] = setTimeout(() => {
      this.flush(side);
      this.render();
    }, idleMs);
  }

  flush(side) {
    clearTimeout(this.timers[side]);
    this.timers[side] = null;
    const text = this.buffer[side].trim();
    this.buffer[side] = "";
    transcript.commit(side, text);
    if (!text) return;
    const now = Date.now();
    addTurn(this.turns, { role: side, text, began: this.began[side] || now, at: now }, MAX_TURNS);
    if (side === "user") {
      this.gate.userTurnLanded();
      // The user stopped talking: a held answer may be spoken now.
      this.speech.release();
    }
  }

  flushAll() {
    this.flush("user");
    this.flush("assistant");
  }

  /**
   * Every delegation must end in commentary: openai-gpt-live-1 waits on its id and
   * otherwise stalls. Each answer carries an event_id, so if openai-gpt-live-1 refuses
   * it, onError can send a short one in its place.
   */
  say(id, content, { replacement = false } = {}) {
    const eventId = nextEventId("answer");
    this.answers.set(eventId, { delegationId: id, replacement });
    this.speech.send({ type: EVENTS.commentaryAppend, event_id: eventId, delegation_id: id, content });
  }

  /**
   * openai-gpt-live-1 reported an error. If it refused an answer this page sent (too
   * long, or an unknown delegation), the model would otherwise keep waiting:
   * replace that answer once with a short one. Everything goes to the
   * console; the transcript says so once per call.
   */
  onError(event) {
    const eventId = event.client_event_id ?? event.error?.client_event_id;
    console.error("openai-gpt-live-1 error", eventId ?? "(not about an event this page sent)", event);
    if (!this.reportedError) {
      this.reportedError = true;
      transcript.note("The voice service reported a problem. Details are in the browser console.");
    }
    const answer = eventId ? this.answers.get(eventId) : undefined;
    if (!answer || answer.replacement) return;
    this.answers.delete(eventId);
    this.say(answer.delegationId, "The answer couldn't be delivered. Say briefly that you couldn't get it and offer to try again.", {
      replacement: true,
    });
  }

  async onDelegation({ id, target }) {
    // Only client-targeted delegations are this application's to run, and each once.
    if (!id || target !== "client" || this.lookups.has(id)) return;
    const lookup = { card: transcript.lookup(), controller: null };
    this.lookups.set(id, lookup);

    // The delegation can arrive before the transcript of the utterance behind
    // it. Wait for that turn rather than send the agent the previous question
    // (needsNewTurn says when).
    const transcribing = Boolean(this.buffer.user.trim());
    const waiting = this.gate.claim({
      awaitNext: needsNewTurn(this.turns, { transcribing, now: Date.now(), staleMs: STALE_TURN_MS }),
    });
    if (transcribing) this.scheduleFlush("user");
    this.render();
    const heard = await waiting;
    if (this.closed) return;
    if (!heard) {
      lookup.card.fail("No new question was heard, so nothing was looked up. The assistant will ask you to repeat it.", {
        noQuestion: true,
      });
      this.say(id, "The question wasn't heard clearly. Ask the rep to repeat it.");
      return this.render();
    }

    const turns = this.turns.slice();
    lookup.card.question(lastRequest(turns) || "(no question heard)");
    const controller = new AbortController();
    lookup.controller = controller;
    this.render();
    let settled = false;

    try {
      const response = await fetch("/api/delegate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ delegationId: id, turns: turns.map(({ role, text }) => ({ role, text })) }),
        signal: controller.signal,
      });
      if (!response.ok) {
        const body = await response.json().catch(() => ({}));
        throw new Error(body.error || `Delegation failed (${response.status})`);
      }
      for await (const event of readEvents(response)) {
        if (event.type === "progress") {
          const phase = String(event.text ?? "").match(/phase=(\S+)/)?.[1];
          if (phase) lookup.card.step(phase);
          this.speech.send({ type: EVENTS.thinkingAppend, event_id: nextEventId("progress"), delegation_id: id, content: event.text });
          this.render();
          continue;
        }
        if (event.type !== "answer" && event.type !== "error") continue;
        // Exactly one commentary per delegation: send it first, then mark it
        // sent, so nothing below can leave the model without one.
        this.say(id, event.text);
        settled = true;
        if (event.type === "answer") {
          lookup.card.done(event.text);
          announce("Found it in Snowflake.");
        } else {
          console.error("Lookup failed", id, event.detail);
          lookup.card.fail(event.detail);
        }
        break;
      }
      // The stream can end with no answer: a proxy timeout, or a server restart.
      if (!settled && !controller.signal.aborted) throw new Error("The lookup stream ended without an answer.");
    } catch (error) {
      // Already answered (the stream broke after the answer), or hung up.
      if (settled || controller.signal.aborted) return;
      this.say(id, "The lookup failed. Tell the rep you couldn't reach the data right now.");
      settled = true;
      console.error("Lookup failed", id, error);
      lookup.card.fail(String(error.message ?? error));
    } finally {
      // Stops the agent run on the server too, if anything is still going.
      controller.abort();
      lookup.controller = null;
      this.render();
    }
  }

  fail(message) {
    if (this.closed) return;
    this.stop({ quiet: true });
    show("error", message, false);
    announce(message);
  }

  /** `quiet`: fail() announces the error instead of "Call ended". */
  stop({ quiet = false } = {}) {
    if (this.closed) return;
    this.flushAll();
    this.closed = true;
    clearInterval(this.ticker);
    for (const side of ["user", "assistant"]) clearTimeout(this.timers[side]);
    this.gate.cancel();
    this.speech.clear();
    for (const lookup of this.lookups.values()) {
      lookup.controller?.abort();
      if (!lookup.card.settled) lookup.card.fail("The call ended before the answer came back.");
    }
    this.channel?.close();
    this.pc?.close();
    this.mic?.getTracks().forEach((track) => track.stop());
    this.meter?.close();
    ui.audio.srcObject = null;
    // The timer stays on what the call lasted.
    let answered = 0;
    for (const lookup of this.lookups.values()) if (lookup.card.answered) answered += 1;
    const summary = answered === 0 ? "Call ended" : `Call ended · ${answered} lookup${answered === 1 ? "" : "s"}`;
    show("idle", summary, false, this.live ? "The transcript stays here until your next call." : "");
    if (!quiet) announce("Call ended.");
    ui.mute.dataset.on = "false";
    ui.muteLabel.textContent = "Mute";
  }
}

/** Local runs sign in with Snowflake first; the server keeps the token. */
let needsSignIn = false;

async function startOrEnd() {
  if (needsSignIn) {
    window.location.assign("/oauth/login");
    return;
  }
  if (call && !call.closed) {
    call.stop();
    return;
  }
  call = new Call();
  const current = call;
  try {
    await current.start();
  } catch (error) {
    console.error("Call failed to start", error);
    if (!current.closed) current.fail(startError(error));
  }
}

ui.call.addEventListener("click", startOrEnd);
// The level meter pauses in a background tab: refresh the status on return.
document.addEventListener("visibilitychange", () => call?.render());
// Closing or reloading the tab mid-call: let go of the mic and the session.
window.addEventListener("pagehide", () => call?.stop());
ui.mute.addEventListener("click", () => call?.setMuted(!call.muted));

// M mutes and unmutes during a call.
document.addEventListener("keydown", (event) => {
  if ((event.key ?? "").toLowerCase() !== "m" || event.metaKey || event.ctrlKey || event.altKey || event.repeat) return;
  if (!call || call.closed) return;
  event.preventDefault();
  call.setMuted(!call.muted);
});

// Show or hide the transcript; remembered in this browser only.
function setTranscriptShown(shown) {
  ui.panel.hidden = !shown;
  if (shown) transcript.toLatest();
  ui.toggle.textContent = shown ? "Hide transcript" : "Show transcript";
  ui.toggle.setAttribute("aria-expanded", String(shown));
  try {
    localStorage.setItem(TRANSCRIPT_PREF, shown ? "shown" : "hidden");
  } catch {
    // Storage blocked: the choice just isn't remembered.
  }
}
ui.toggle.addEventListener("click", () => setTranscriptShown(ui.panel.hidden));
let savedPref = null;
try {
  savedPref = localStorage.getItem(TRANSCRIPT_PREF);
} catch {
  // Storage blocked: default to shown.
}
setTranscriptShown(savedPref !== "hidden");

fetch("/api/config")
  .then((r) => r.json())
  .then((c) => {
    ui.meta.textContent = `${c.model} · voice ${c.voice} · agent ${c.agent}${c.user ? ` · signed in as ${c.user}` : ""}`;
    needsSignIn = c.signedIn === false;
    if (needsSignIn) {
      const failed = new URLSearchParams(window.location.search).get("signin") === "failed";
      show("idle", failed ? "Sign-in didn't complete" : "Sign in to start", false, failed ? "Try again. Details are in the server logs." : "");
      ui.callLabel.textContent = "Sign in with Snowflake";
    }
  })
  .catch(() => (ui.meta.textContent = "Server not reachable"));
