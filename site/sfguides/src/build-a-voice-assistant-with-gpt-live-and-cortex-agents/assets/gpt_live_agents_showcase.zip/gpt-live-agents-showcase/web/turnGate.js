// Pairs each delegation with the user turn that caused it.
//
// session.delegation.created can arrive before the input transcript of the
// utterance that triggered it. Relaying straight away would send the agent the
// previous question. So a delegation waits until a user turn newer than the
// last one relayed has landed, or gives up after `waitMs` rather than answer a
// stale question.

export const INPUT_WAIT_MS = 4000;

export class TurnGate {
  constructor({ waitMs = INPUT_WAIT_MS, setTimer = setTimeout, clearTimer = clearTimeout } = {}) {
    this.waitMs = waitMs;
    // Wrapped, not stored: browsers throw "Illegal invocation" when
    // setTimeout is called as a method of another object. Node doesn't.
    this.setTimer = (fn, ms) => setTimer(fn, ms);
    this.clearTimer = (id) => clearTimer(id);
    this.landed = 0; // user turns flushed so far
    this.relayed = 0; // the newest user turn already given to a delegation
    this.waiters = new Set();
  }

  /** Call when a user turn has been flushed to the transcript. */
  userTurnLanded() {
    this.landed += 1;
    for (const wake of [...this.waiters]) wake(true);
  }

  /** How many delegations are waiting for their question. */
  get pending() {
    return this.waiters.size;
  }

  /**
   * Resolves true once there is a user turn no delegation has used yet, and
   * claims it; false if none lands within `waitMs`, or `cancel()` is called.
   * With `awaitNext` (user speech is still being transcribed), only a turn
   * that lands after this call counts: an older unused one, such as a
   * "thanks", isn't the question.
   */
  claim({ awaitNext = false } = {}) {
    const needed = Math.max(this.relayed, awaitNext ? this.landed : 0) + 1;
    if (this.landed >= needed) {
      this.relayed = this.landed;
      return Promise.resolve(true);
    }
    return new Promise((resolve) => {
      const wake = (ok) => {
        // Two delegations waiting on one turn: the first takes it, the other keeps waiting.
        if (ok && (this.landed < needed || this.landed <= this.relayed)) return;
        this.clearTimer(timer);
        this.waiters.delete(wake);
        if (ok) this.relayed = this.landed;
        resolve(ok);
      };
      const timer = this.setTimer(() => wake(false), this.waitMs);
      this.waiters.add(wake);
    });
  }

  /** Release every waiter with false, e.g. on hang-up. */
  cancel() {
    for (const wake of [...this.waiters]) wake(false);
  }
}
