# Contributing

Issues and pull requests are welcome, for example:

- a fix when the app stops working after an `openai-gpt-live-1` or Cortex release;
- a clearer explanation in the README or the quickstart guide;
- a different dataset, briefing or agent for another field-sales scenario.

Please keep changes in line with the quickstart:

- **Keep the data and the example answers together.** The sample data in `snowflake/setup.sql` and the example questions in the guide and `web/index.html` depend on each other; change both together.
- **Synthetic data only.** Never add customer data, credentials or account identifiers.
- Run `npm run check` and test a change end to end in a sandbox account; say in the pull request which steps you ran.

This is sample code maintained on a best-effort basis; there's no support SLA. By contributing, you agree that your contributions are licensed under the Apache License 2.0.

Participation is governed by the [Code of Conduct](CODE_OF_CONDUCT.md).
