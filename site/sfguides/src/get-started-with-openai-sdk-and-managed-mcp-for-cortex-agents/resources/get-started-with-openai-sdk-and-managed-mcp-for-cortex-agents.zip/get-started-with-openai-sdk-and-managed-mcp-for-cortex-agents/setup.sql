-- ============================================
-- COMPLETE SNOWFLAKE SETUP FOR EXTERNAL ACCESS
-- Run this entire script to set up everything needed
-- ============================================

-- ============================================
-- STEP 1: ENABLE CORTEX AI FEATURES
-- ============================================
USE ROLE ACCOUNTADMIN;

-- Enable cross-region inference for ALL regions (for GPT-5 and other models)
ALTER ACCOUNT SET CORTEX_ENABLED_CROSS_REGION = 'ANY_REGION';

-- ============================================
-- STEP 2: CREATE DATABASE AND SCHEMA
-- ============================================

-- Create database
CREATE OR REPLACE DATABASE SALES_INTELLIGENCE
    COMMENT = 'Database for sales intelligence demo with Cortex AI';

-- Create schema
CREATE OR REPLACE SCHEMA SALES_INTELLIGENCE.DATA
    COMMENT = 'Schema for sales data and AI models';

-- Create warehouse
CREATE OR REPLACE WAREHOUSE SALES_INTELLIGENCE_WH
    WAREHOUSE_SIZE = 'XSMALL'
    AUTO_SUSPEND = 60
    AUTO_RESUME = TRUE
    INITIALLY_SUSPENDED = TRUE
    COMMENT = 'Warehouse for sales intelligence workloads';

-- Use the context
USE WAREHOUSE SALES_INTELLIGENCE_WH;
USE DATABASE SALES_INTELLIGENCE;
USE SCHEMA DATA;

-- ============================================
-- STEP 3: CREATE TABLES
-- ============================================

-- Sales conversations table (unstructured data)
CREATE OR REPLACE TABLE sales_conversations (
    conversation_id VARCHAR,
    transcript_text TEXT,
    customer_name VARCHAR,
    deal_stage VARCHAR,
    sales_rep VARCHAR,
    conversation_date TIMESTAMP,
    deal_value FLOAT,
    product_line VARCHAR
);

-- Sales metrics table (structured data)
CREATE OR REPLACE TABLE sales_metrics (
    deal_id VARCHAR,
    customer_name VARCHAR,
    deal_value FLOAT,
    close_date DATE,
    sales_stage VARCHAR,
    win_status BOOLEAN,
    sales_rep VARCHAR,
    product_line VARCHAR
);

-- ============================================
-- STEP 4: INSERT SAMPLE DATA
-- ============================================

-- Insert sample sales conversations
INSERT INTO sales_conversations 
(conversation_id, transcript_text, customer_name, deal_stage, sales_rep, conversation_date, deal_value, product_line)
VALUES
('CONV001', 'Initial discovery call with TechCorp Inc''s IT Director and Solutions Architect. Client showed strong interest in our enterprise solution features, particularly the automated workflow capabilities. The main discussion centered around integration timeline and complexity. They currently use Legacy System X for their core operations and expressed concerns about potential disruption during migration. The team asked detailed questions about API compatibility and data migration tools.

Action items include providing a detailed integration timeline document, scheduling a technical deep-dive with their infrastructure team, and sharing case studies of similar Legacy System X migrations. The client mentioned a Q2 budget allocation for digital transformation initiatives. Overall, it was a positive engagement with clear next steps.', 'TechCorp Inc', 'Discovery', 'Sarah Johnson', '2024-01-15 10:30:00', 75000, 'Enterprise Suite'),

('CONV002', 'Follow-up call with SmallBiz Solutions'' Operations Manager and Finance Director. The primary focus was on pricing structure and ROI timeline. They compared our Basic Package pricing with Competitor Y''s small business offering. Key discussion points included monthly vs. annual billing options, user license limitations, and potential cost savings from process automation.

The client requested a detailed ROI analysis focusing on time saved in daily operations, resource allocation improvements, and projected efficiency gains. Budget constraints were clearly communicated, with a maximum budget of $30K for this year. They showed interest in starting with the basic package with room for a potential upgrade in Q4. Next steps include providing a competitive analysis and a customized ROI calculator by next week.', 'SmallBiz Solutions', 'Negotiation', 'Mike Chen', '2024-01-16 14:45:00', 25000, 'Basic Package'),

('CONV003', 'Strategy session with SecureBank Ltd''s CISO and Security Operations team. Extremely positive 90-minute deep dive into our Premium Security package. Customer emphasized immediate need for implementation due to recent industry compliance updates. Our advanced security features, especially multi-factor authentication and encryption protocols, were identified as perfect fits for their requirements. Technical team was particularly impressed with our zero-trust architecture approach and real-time threat monitoring capabilities. They''ve already secured budget approval and have executive buy-in. Compliance documentation is ready for review. Action items include: finalizing implementation timeline, scheduling security audit, and preparing necessary documentation for their risk assessment team. Client ready to move forward with contract discussions.', 'SecureBank Ltd', 'Closing', 'Rachel Torres', '2024-01-17 11:20:00', 150000, 'Premium Security'),

('CONV004', 'Comprehensive discovery call with GrowthStart Up''s CTO and Department Heads. Team of 500+ employees across 3 continents discussed current challenges with their existing solution. Major pain points identified: system crashes during peak usage, limited cross-department reporting capabilities, and poor scalability for remote teams. Deep dive into their current workflow revealed bottlenecks in data sharing and collaboration. Technical requirements gathered for each department. Platform demo focused on scalability features and global team management capabilities. Client particularly interested in our API ecosystem and custom reporting engine. Next steps: schedule department-specific workflow analysis and prepare detailed platform migration plan.', 'GrowthStart Up', 'Discovery', 'Sarah Johnson', '2024-01-18 09:15:00', 100000, 'Enterprise Suite'),

('CONV005', 'In-depth demo session with DataDriven Co''s Analytics team and Business Intelligence managers. Showcase focused on advanced analytics capabilities, custom dashboard creation, and real-time data processing features. Team was particularly impressed with our machine learning integration and predictive analytics models. Competitor comparison requested specifically against Market Leader Z and Innovative Start-up X. Price point falls within their allocated budget range, but team expressed interest in multi-year commitment with corresponding discount structure. Technical questions centered around data warehouse integration and custom visualization capabilities. Action items: prepare detailed competitor feature comparison matrix and draft multi-year pricing proposals with various discount scenarios.', 'DataDriven Co', 'Demo', 'James Wilson', '2024-01-19 13:30:00', 85000, 'Analytics Pro'),

('CONV006', 'Extended technical deep dive with HealthTech Solutions'' IT Security team, Compliance Officer, and System Architects. Four-hour session focused on API infrastructure, data security protocols, and compliance requirements. Team raised specific concerns about HIPAA compliance, data encryption standards, and API rate limiting. Detailed discussion of our security architecture, including: end-to-end encryption, audit logging, and disaster recovery protocols. Client requires extensive documentation on compliance certifications, particularly SOC 2 and HITRUST. Security team performed initial architecture review and requested additional information about: database segregation, backup procedures, and incident response protocols. Follow-up session scheduled with their compliance team next week.', 'HealthTech Solutions', 'Technical Review', 'Rachel Torres', '2024-01-20 15:45:00', 120000, 'Premium Security'),

('CONV007', 'Contract review meeting with LegalEase Corp''s General Counsel, Procurement Director, and IT Manager. Detailed analysis of SLA terms, focusing on uptime guarantees and support response times. Legal team requested specific modifications to liability clauses and data handling agreements. Procurement raised questions about payment terms and service credit structure. Key discussion points included: disaster recovery commitments, data retention policies, and exit clause specifications. IT Manager confirmed technical requirements are met pending final security assessment. Agreement reached on most terms, with only SLA modifications remaining for discussion. Legal team to provide revised contract language by end of week. Overall positive session with clear path to closing.', 'LegalEase Corp', 'Negotiation', 'Mike Chen', '2024-01-21 10:00:00', 95000, 'Enterprise Suite'),

('CONV008', 'Quarterly business review with GlobalTrade Inc''s current implementation team and potential expansion stakeholders. Current implementation in Finance department showcasing strong adoption rates and 40% improvement in processing times. Discussion focused on expanding solution to Operations and HR departments. Users highlighted positive experiences with customer support and platform stability. Challenges identified in current usage: need for additional custom reports and increased automation in workflow processes. Expansion requirements gathered from Operations Director: inventory management integration, supplier portal access, and enhanced tracking capabilities. HR team interested in recruitment and onboarding workflow automation. Next steps: prepare department-specific implementation plans and ROI analysis for expansion.', 'GlobalTrade Inc', 'Expansion', 'James Wilson', '2024-01-22 14:20:00', 45000, 'Basic Package'),

('CONV009', 'Emergency planning session with FastTrack Ltd''s Executive team and Project Managers. Critical need for rapid implementation due to current system failure. Team willing to pay premium for expedited deployment and dedicated support team. Detailed discussion of accelerated implementation timeline and resource requirements. Key requirements: minimal disruption to operations, phased data migration, and emergency support protocols. Technical team confident in meeting aggressive timeline with additional resources. Executive sponsor emphasized importance of going live within 30 days. Immediate next steps: finalize expedited implementation plan, assign dedicated support team, and begin emergency onboarding procedures. Team to reconvene daily for progress updates.', 'FastTrack Ltd', 'Closing', 'Sarah Johnson', '2024-01-23 16:30:00', 180000, 'Premium Security'),

('CONV010', 'Quarterly strategic review with UpgradeNow Corp''s Department Heads and Analytics team. Current implementation meeting basic needs but team requiring more sophisticated analytics capabilities. Deep dive into current usage patterns revealed opportunities for workflow optimization and advanced reporting needs. Users expressed strong satisfaction with platform stability and basic features, but requiring enhanced data visualization and predictive analytics capabilities. Analytics team presented specific requirements: custom dashboard creation, advanced data modeling tools, and integrated BI features. Discussion about upgrade path from current package to Analytics Pro tier. ROI analysis presented showing potential 60% improvement in reporting efficiency. Team to present upgrade proposal to executive committee next month.', 'UpgradeNow Corp', 'Expansion', 'Rachel Torres', '2024-01-24 11:45:00', 65000, 'Analytics Pro');

INSERT INTO sales_metrics
(deal_id, customer_name, deal_value, close_date, sales_stage, win_status, sales_rep, product_line)
VALUES
('DEAL001', 'TechCorp Inc', 75000, '2024-02-15', 'Closed', true, 'Sarah Johnson', 'Enterprise Suite'),

('DEAL002', 'SmallBiz Solutions', 25000, '2024-02-01', 'Lost', false, 'Mike Chen', 'Basic Package'),

('DEAL003', 'SecureBank Ltd', 150000, '2024-01-30', 'Closed', true, 'Rachel Torres', 'Premium Security'),

('DEAL004', 'GrowthStart Up', 100000, '2024-02-10', 'Pending', false, 'Sarah Johnson', 'Enterprise Suite'),

('DEAL005', 'DataDriven Co', 85000, '2024-02-05', 'Closed', true, 'James Wilson', 'Analytics Pro'),

('DEAL006', 'HealthTech Solutions', 120000, '2024-02-20', 'Pending', false, 'Rachel Torres', 'Premium Security'),

('DEAL007', 'LegalEase Corp', 95000, '2024-01-25', 'Closed', true, 'Mike Chen', 'Enterprise Suite'),

('DEAL008', 'GlobalTrade Inc', 45000, '2024-02-08', 'Closed', true, 'James Wilson', 'Basic Package'),

('DEAL009', 'FastTrack Ltd', 180000, '2024-02-12', 'Closed', true, 'Sarah Johnson', 'Premium Security'),

('DEAL010', 'UpgradeNow Corp', 65000, '2024-02-18', 'Pending', false, 'Rachel Torres', 'Analytics Pro');


-- Verify data insertion
SELECT 'Conversations Count' AS METRIC, COUNT(*)::VARCHAR AS VALUE FROM SALES_CONVERSATIONS
UNION ALL
SELECT 'Metrics Count', COUNT(*)::VARCHAR FROM SALES_METRICS;

-- ============================================
-- STEP 5: CREATE CORTEX SEARCH SERVICE
-- ============================================

-- Create stage for semantic model (needed for Cortex Analyst)
CREATE OR REPLACE STAGE MODELS
    DIRECTORY = (ENABLE = TRUE)
    COMMENT = 'Stage for semantic models and AI configurations';

-- Create Cortex Search Service for conversations
CREATE OR REPLACE CORTEX SEARCH SERVICE SALES_CONVERSATIONS_SEARCH
    ON transcript_text
    WAREHOUSE = SALES_INTELLIGENCE_WH
    TARGET_LAG = '1 minute'
    AS (
        SELECT 
            conversation_id,
            transcript_text,
            customer_name,
            deal_stage,
            sales_rep,
            conversation_date,
            deal_value,
            product_line
        FROM SALES_CONVERSATIONS
    );

create or replace network policy allow_all
  allowed_ip_list = ('0.0.0.0/0');

SET current_user_var = CURRENT_USER();
ALTER USER IDENTIFIER($current_user_var) SET NETWORK_POLICY = 'ALLOW_ALL';

-- ============================================
-- CREATE SEMANTIC VIEW FOR CORTEX ANALYST
-- ============================================

CALL SYSTEM$CREATE_SEMANTIC_VIEW_FROM_YAML(
  'SALES_INTELLIGENCE.DATA',
  $$
  name: SALES_METRICS_SEMANTIC_VIEW
  description: Semantic view for sales performance metrics and analytics
  tables:
    - name: SALES_METRICS
      description: Sales performance metrics by deal, customer, and sales rep
      base_table:
        database: SALES_INTELLIGENCE
        schema: DATA
        table: SALES_METRICS
      primary_key:
        columns:
          - DEAL_ID
      dimensions:
        - name: DEAL_ID
          synonyms:
            - deal
            - opportunity id
            - transaction id
          description: Unique identifier for each deal
          expr: DEAL_ID
          data_type: VARCHAR
        
        - name: CUSTOMER_NAME
          synonyms:
            - customer
            - client
            - account
            - company
          description: Name of the customer company
          expr: CUSTOMER_NAME
          data_type: VARCHAR
        
        - name: CLOSE_DATE
          synonyms:
            - date
            - closing date
            - when closed
            - completion date
          description: The date when the deal was closed or expected to close
          expr: CLOSE_DATE
          data_type: DATE
        
        - name: SALES_STAGE
          synonyms:
            - stage
            - pipeline stage
            - status
            - phase
          description: Current stage of the sales deal
          expr: SALES_STAGE
          data_type: VARCHAR
        
        - name: SALES_REP
          synonyms:
            - rep
            - sales person
            - representative
            - seller
            - account executive
          description: Name of the sales representative handling the deal
          expr: SALES_REP
          data_type: VARCHAR
        
        - name: PRODUCT_LINE
          synonyms:
            - product
            - solution
            - offering
            - package
          description: Product line or package being sold
          expr: PRODUCT_LINE
          data_type: VARCHAR
      
      metrics:
        - name: TOTAL_DEAL_VALUE
          synonyms:
            - total value
            - total revenue
            - sum of deals
            - total amount
          description: Sum of all deal values
          expr: SUM(DEAL_VALUE)
        
        - name: DEAL_COUNT
          synonyms:
            - number of deals
            - count of deals
            - total deals
          description: Total number of deals
          expr: COUNT(DEAL_ID)
        
        - name: AVG_DEAL_VALUE
          synonyms:
            - average deal
            - average value
            - typical deal size
            - mean deal value
          description: Average value of deals
          expr: AVG(DEAL_VALUE)
        
        - name: WIN_RATE
          synonyms:
            - success rate
            - close rate
            - conversion rate
            - win percentage
          description: Percentage of deals won
          expr: AVG(CASE WHEN WIN_STATUS THEN 100 ELSE 0 END)
        
        - name: WON_DEAL_COUNT
          synonyms:
            - won deals
            - successful deals
            - closed deals
          description: Number of deals that were won
          expr: COUNT(CASE WHEN WIN_STATUS THEN 1 END)
        
        - name: WON_DEAL_VALUE
          synonyms:
            - won revenue
            - closed revenue
            - revenue from won deals
          description: Total value of won deals
          expr: SUM(CASE WHEN WIN_STATUS THEN DEAL_VALUE ELSE 0 END)
  $$
);

-- Verify the semantic view was created
SHOW SEMANTIC VIEWS IN SCHEMA SALES_INTELLIGENCE.DATA;

CREATE ROLE IF NOT EXISTS SALES_INTELLIGENCE_ROLE;

-- Grant database and schema access
GRANT USAGE ON DATABASE SALES_INTELLIGENCE TO ROLE SALES_INTELLIGENCE_ROLE;
GRANT USAGE ON SCHEMA SALES_INTELLIGENCE.DATA TO ROLE SALES_INTELLIGENCE_ROLE;

-- Grant access to all tables in the schema
GRANT SELECT ON ALL TABLES IN SCHEMA SALES_INTELLIGENCE.DATA TO ROLE SALES_INTELLIGENCE_ROLE;
GRANT SELECT ON FUTURE TABLES IN SCHEMA SALES_INTELLIGENCE.DATA TO ROLE SALES_INTELLIGENCE_ROLE;

-- Grant access to Cortex Search Service
GRANT USAGE ON CORTEX SEARCH SERVICE SALES_INTELLIGENCE.DATA.SALES_CONVERSATIONS_SEARCH TO ROLE SALES_INTELLIGENCE_ROLE;

GRANT SELECT ON SEMANTIC VIEW SALES_METRICS_SEMANTIC_VIEW TO ROLE SALES_INTELLIGENCE_ROLE;

GRANT CREATE AGENTS TO ROLE SALES_INTELLIGENCE_ROLE;

-- Grant access to warehouse
GRANT USAGE ON WAREHOUSE SALES_INTELLIGENCE_WH TO ROLE SALES_INTELLIGENCE_ROLE;

GRANT CREATE AGENT ON SCHEMA SALES_INTELLIGENCE.DATA TO ROLE SALES_INTELLIGENCE_ROLE;

GRANT ROLE SALES_INTELLIGENCE_ROLE TO USER IDENTIFIER($current_user_var);

SHOW GRANTS TO USER IDENTIFIER($current_user_var);
ALTER USER IDENTIFIER($current_user_var) SET DEFAULT_ROLE = SALES_INTELLIGENCE_ROLE;

SELECT '✅ SETUP COMPLETE!' AS STATUS,
       'All tables, search service, and permissions are configured.' AS MESSAGE